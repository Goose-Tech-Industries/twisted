/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: twisted_rpg
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_player_notes`
--

DROP TABLE IF EXISTS `admin_player_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_player_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL,
  `author_name` varchar(64) NOT NULL,
  `flag` enum('none','watch','vip','trusted','suspicious') NOT NULL DEFAULT 'none',
  `body` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_apn_user` (`user_id`),
  KEY `idx_apn_flag` (`flag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_player_notes`
--

LOCK TABLES `admin_player_notes` WRITE;
/*!40000 ALTER TABLE `admin_player_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_player_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artifact_hunts`
--

DROP TABLE IF EXISTS `artifact_hunts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `artifact_hunts` (
  `hunt_id` varchar(64) NOT NULL,
  `artifact_id` varchar(64) NOT NULL,
  `hunter_id` int(10) unsigned NOT NULL,
  `target_id` int(10) unsigned DEFAULT NULL,
  `bounty_amount` int(11) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `status` enum('active','claimed','expired') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`hunt_id`),
  KEY `idx_hunts_artifact` (`artifact_id`),
  KEY `idx_hunts_hunter` (`hunter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artifact_hunts`
--

LOCK TABLES `artifact_hunts` WRITE;
/*!40000 ALTER TABLE `artifact_hunts` DISABLE KEYS */;
/*!40000 ALTER TABLE `artifact_hunts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artifact_lineage`
--

DROP TABLE IF EXISTS `artifact_lineage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `artifact_lineage` (
  `lineage_id` varchar(64) NOT NULL,
  `artifact_id` varchar(64) NOT NULL,
  `wielder_id` int(10) unsigned NOT NULL,
  `acquired_at` datetime NOT NULL,
  `ended_at` datetime DEFAULT NULL,
  `ended_reason` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`lineage_id`),
  KEY `idx_lineage_artifact` (`artifact_id`),
  KEY `idx_lineage_wielder` (`wielder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artifact_lineage`
--

LOCK TABLES `artifact_lineage` WRITE;
/*!40000 ALTER TABLE `artifact_lineage` DISABLE KEYS */;
/*!40000 ALTER TABLE `artifact_lineage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artifact_powers`
--

DROP TABLE IF EXISTS `artifact_powers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `artifact_powers` (
  `power_id` varchar(64) NOT NULL,
  `artifact_id` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `power_type` enum('passive','active','ultimate') NOT NULL DEFAULT 'passive',
  `unlock_kills` int(11) NOT NULL DEFAULT 0,
  `rank_max` int(11) NOT NULL DEFAULT 1,
  `effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`effect_json`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `quest_required_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`power_id`),
  KEY `idx_powers_artifact` (`artifact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artifact_powers`
--

LOCK TABLES `artifact_powers` WRITE;
/*!40000 ALTER TABLE `artifact_powers` DISABLE KEYS */;
/*!40000 ALTER TABLE `artifact_powers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artifact_pvp_kill_log`
--

DROP TABLE IF EXISTS `artifact_pvp_kill_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `artifact_pvp_kill_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `artifact_id` varchar(64) NOT NULL,
  `killer_id` int(10) unsigned NOT NULL,
  `victim_id` int(10) unsigned NOT NULL,
  `killed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pvplog_artifact` (`artifact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artifact_pvp_kill_log`
--

LOCK TABLES `artifact_pvp_kill_log` WRITE;
/*!40000 ALTER TABLE `artifact_pvp_kill_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `artifact_pvp_kill_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artifact_shrines`
--

DROP TABLE IF EXISTS `artifact_shrines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `artifact_shrines` (
  `shrine_id` varchar(64) NOT NULL,
  `artifact_id` varchar(64) NOT NULL,
  `character_id` int(10) unsigned NOT NULL,
  `zone_id` varchar(64) DEFAULT NULL,
  `title` varchar(128) NOT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`shrine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artifact_shrines`
--

LOCK TABLES `artifact_shrines` WRITE;
/*!40000 ALTER TABLE `artifact_shrines` DISABLE KEYS */;
/*!40000 ALTER TABLE `artifact_shrines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artifact_worship_log`
--

DROP TABLE IF EXISTS `artifact_worship_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `artifact_worship_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `artifact_id` varchar(64) NOT NULL,
  `character_id` int(10) unsigned NOT NULL,
  `shrine_id` varchar(64) DEFAULT NULL,
  `worshipped_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_worship_artifact` (`artifact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artifact_worship_log`
--

LOCK TABLES `artifact_worship_log` WRITE;
/*!40000 ALTER TABLE `artifact_worship_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `artifact_worship_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_listings`
--

DROP TABLE IF EXISTS `auction_listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auction_listings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seller_char_id` int(10) unsigned NOT NULL,
  `seller_name` varchar(64) NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `buyout_price` int(11) NOT NULL,
  `current_bid` int(11) NOT NULL DEFAULT 0,
  `min_bid` int(11) NOT NULL DEFAULT 0,
  `bidder_char_id` int(10) unsigned DEFAULT NULL,
  `bidder_name` varchar(64) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `status` enum('ACTIVE','SOLD_BUYOUT','SOLD_BID','EXPIRED','CANCELLED') NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_auction_status` (`status`),
  KEY `idx_auction_item` (`item_id`),
  KEY `idx_auction_seller` (`seller_char_id`),
  KEY `idx_auction_expires` (`expires_at`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_listings`
--

LOCK TABLES `auction_listings` WRITE;
/*!40000 ALTER TABLE `auction_listings` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_listings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_ability_scores`
--

DROP TABLE IF EXISTS `character_ability_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_ability_scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `ability_key` varchar(32) NOT NULL,
  `base_value` int(11) NOT NULL DEFAULT 8,
  `bonus_value` int(11) NOT NULL DEFAULT 0 COMMENT 'from race, birth sign, level ups',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_ability` (`character_id`,`ability_key`),
  KEY `idx_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_ability_scores`
--

LOCK TABLES `character_ability_scores` WRITE;
/*!40000 ALTER TABLE `character_ability_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_ability_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_achievements`
--

DROP TABLE IF EXISTS `character_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_achievements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `achievement_id` int(10) unsigned NOT NULL,
  `earned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_char_achiev` (`character_id`,`achievement_id`),
  KEY `idx_ca_char` (`character_id`),
  KEY `idx_ca_achiev` (`achievement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_achievements`
--

LOCK TABLES `character_achievements` WRITE;
/*!40000 ALTER TABLE `character_achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_companions`
--

DROP TABLE IF EXISTS `character_companions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_companions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `npc_id` int(10) unsigned NOT NULL,
  `recruited_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `tactics` enum('AGGRESSIVE','BALANCED','DEFENSIVE','SUPPORT') NOT NULL DEFAULT 'BALANCED',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_npc` (`character_id`,`npc_id`),
  KEY `idx_char_active` (`character_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_companions`
--

LOCK TABLES `character_companions` WRITE;
/*!40000 ALTER TABLE `character_companions` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_companions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_discovered_arts`
--

DROP TABLE IF EXISTS `character_discovered_arts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_discovered_arts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `character_id` int(11) NOT NULL,
  `art_id` int(11) NOT NULL,
  `times_used` int(11) NOT NULL DEFAULT 0,
  `discovered_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_art` (`character_id`,`art_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_discovered_arts`
--

LOCK TABLES `character_discovered_arts` WRITE;
/*!40000 ALTER TABLE `character_discovered_arts` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_discovered_arts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_discovered_recipes`
--

DROP TABLE IF EXISTS `character_discovered_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_discovered_recipes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `recipe_id` int(10) unsigned NOT NULL,
  `discovered_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_recipe` (`character_id`,`recipe_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_discovered_recipes`
--

LOCK TABLES `character_discovered_recipes` WRITE;
/*!40000 ALTER TABLE `character_discovered_recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_discovered_recipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_elemental_affinity`
--

DROP TABLE IF EXISTS `character_elemental_affinity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_elemental_affinity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `element` varchar(32) NOT NULL,
  `total_casts` int(10) unsigned NOT NULL DEFAULT 0,
  `current_tier` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_element` (`character_id`,`element`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_elemental_affinity`
--

LOCK TABLES `character_elemental_affinity` WRITE;
/*!40000 ALTER TABLE `character_elemental_affinity` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_elemental_affinity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_enchantments`
--

DROP TABLE IF EXISTS `character_enchantments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_enchantments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `enchantment_id` int(10) unsigned NOT NULL,
  `battles_remaining` int(11) NOT NULL DEFAULT 50,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_item` (`character_id`,`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_enchantments`
--

LOCK TABLES `character_enchantments` WRITE;
/*!40000 ALTER TABLE `character_enchantments` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_enchantments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_equipment`
--

DROP TABLE IF EXISTS `character_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_equipment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `slot_key` varchar(32) NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_char_slot` (`character_id`,`slot_key`),
  KEY `idx_equip_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_equipment`
--

LOCK TABLES `character_equipment` WRITE;
/*!40000 ALTER TABLE `character_equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_fighting_styles`
--

DROP TABLE IF EXISTS `character_fighting_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_fighting_styles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `character_id` int(11) NOT NULL,
  `style_id` int(11) NOT NULL,
  `current_rank` int(11) NOT NULL DEFAULT 1,
  `wins_at_rank` int(11) NOT NULL DEFAULT 0,
  `total_wins` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `learned_from_npc_id` int(11) DEFAULT NULL,
  `learned_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_style` (`character_id`,`style_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_fighting_styles`
--

LOCK TABLES `character_fighting_styles` WRITE;
/*!40000 ALTER TABLE `character_fighting_styles` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_fighting_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_flavor_history`
--

DROP TABLE IF EXISTS `character_flavor_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_flavor_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `character_id` int(11) NOT NULL,
  `flavor_text` text NOT NULL,
  `keywords_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'extracted keywords from this text' CHECK (json_valid(`keywords_json`)),
  `category` varchar(32) DEFAULT 'attack',
  `battle_id` int(11) DEFAULT NULL,
  `skill_id` int(11) DEFAULT NULL,
  `damage_dealt` int(11) DEFAULT 0,
  `used_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_char` (`character_id`),
  KEY `idx_char_time` (`character_id`,`used_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_flavor_history`
--

LOCK TABLES `character_flavor_history` WRITE;
/*!40000 ALTER TABLE `character_flavor_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_flavor_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_friends`
--

DROP TABLE IF EXISTS `character_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_friends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `requester_id` int(10) unsigned NOT NULL,
  `recipient_id` int(10) unsigned NOT NULL,
  `status` enum('pending','accepted','blocked') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_friendship` (`requester_id`,`recipient_id`),
  KEY `idx_friends_recipient` (`recipient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_friends`
--

LOCK TABLES `character_friends` WRITE;
/*!40000 ALTER TABLE `character_friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_items`
--

DROP TABLE IF EXISTS `character_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_char_item` (`character_id`,`item_id`),
  KEY `idx_items_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_items`
--

LOCK TABLES `character_items` WRITE;
/*!40000 ALTER TABLE `character_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_learned_recipes`
--

DROP TABLE IF EXISTS `character_learned_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_learned_recipes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `recipe_id` int(10) unsigned NOT NULL,
  `learned_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_char_recipe` (`character_id`,`recipe_id`),
  KEY `idx_learned_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_learned_recipes`
--

LOCK TABLES `character_learned_recipes` WRITE;
/*!40000 ALTER TABLE `character_learned_recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_learned_recipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_learned_spells`
--

DROP TABLE IF EXISTS `character_learned_spells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_learned_spells` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `skill_id` int(10) unsigned NOT NULL,
  `learned_from` enum('tome','master','quest','ogham','default') NOT NULL DEFAULT 'tome',
  `learned_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_skill` (`character_id`,`skill_id`),
  KEY `idx_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_learned_spells`
--

LOCK TABLES `character_learned_spells` WRITE;
/*!40000 ALTER TABLE `character_learned_spells` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_learned_spells` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_magic_affinity`
--

DROP TABLE IF EXISTS `character_magic_affinity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_magic_affinity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `school_id` int(10) unsigned NOT NULL,
  `affinity_level` int(11) NOT NULL DEFAULT 0,
  `total_casts` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_school` (`character_id`,`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_magic_affinity`
--

LOCK TABLES `character_magic_affinity` WRITE;
/*!40000 ALTER TABLE `character_magic_affinity` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_magic_affinity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_mail`
--

DROP TABLE IF EXISTS `character_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_mail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_char_id` int(10) unsigned NOT NULL,
  `sender_name` varchar(64) NOT NULL,
  `recipient_char_id` int(10) unsigned NOT NULL,
  `subject` varchar(120) NOT NULL DEFAULT 'No subject',
  `body` text NOT NULL,
  `gold_attachment` int(10) unsigned NOT NULL DEFAULT 0,
  `gold_collected` tinyint(1) NOT NULL DEFAULT 0,
  `item_attachment_id` int(10) unsigned DEFAULT NULL,
  `item_attachment_qty` int(10) unsigned NOT NULL DEFAULT 0,
  `item_collected` tinyint(1) NOT NULL DEFAULT 0,
  `cod_price` int(10) unsigned NOT NULL DEFAULT 0,
  `cod_paid` tinyint(1) NOT NULL DEFAULT 0,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `is_starred` tinyint(1) NOT NULL DEFAULT 0,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `reply_to_id` int(10) unsigned DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `sender_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mail_recipient` (`recipient_char_id`,`is_deleted`,`is_read`),
  KEY `idx_mail_sender` (`sender_char_id`),
  KEY `idx_mail_reply` (`reply_to_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_mail`
--

LOCK TABLES `character_mail` WRITE;
/*!40000 ALTER TABLE `character_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_ogham_shards`
--

DROP TABLE IF EXISTS `character_ogham_shards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_ogham_shards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `shard_id` int(10) unsigned NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_shard` (`character_id`,`shard_id`),
  KEY `idx_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_ogham_shards`
--

LOCK TABLES `character_ogham_shards` WRITE;
/*!40000 ALTER TABLE `character_ogham_shards` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_ogham_shards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_oghams`
--

DROP TABLE IF EXISTS `character_oghams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_oghams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `slot_index` int(11) NOT NULL DEFAULT 0,
  `ogham_id` int(10) unsigned NOT NULL,
  `current_rank` int(11) NOT NULL DEFAULT 1,
  `kill_count` int(11) NOT NULL DEFAULT 0,
  `corruption_points` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_char_item_slot` (`character_id`,`item_id`,`slot_index`),
  KEY `idx_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_oghams`
--

LOCK TABLES `character_oghams` WRITE;
/*!40000 ALTER TABLE `character_oghams` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_oghams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_parties`
--

DROP TABLE IF EXISTS `character_parties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_parties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `leader_id` int(10) unsigned NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `max_size` int(11) NOT NULL DEFAULT 4,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `disbanded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parties_leader` (`leader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_parties`
--

LOCK TABLES `character_parties` WRITE;
/*!40000 ALTER TABLE `character_parties` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_parties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_party_members`
--

DROP TABLE IF EXISTS `character_party_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_party_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `party_id` int(10) unsigned NOT NULL,
  `character_id` int(10) unsigned NOT NULL,
  `role` enum('LEADER','MEMBER') NOT NULL DEFAULT 'MEMBER',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `left_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_party_char` (`party_id`,`character_id`),
  KEY `idx_party_members_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_party_members`
--

LOCK TABLES `character_party_members` WRITE;
/*!40000 ALTER TABLE `character_party_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_party_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_passive_abilities`
--

DROP TABLE IF EXISTS `character_passive_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_passive_abilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `character_id` int(11) NOT NULL,
  `ability_id` int(11) NOT NULL,
  `slot_number` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_slot` (`character_id`,`slot_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_passive_abilities`
--

LOCK TABLES `character_passive_abilities` WRITE;
/*!40000 ALTER TABLE `character_passive_abilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_passive_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_pvp_teams`
--

DROP TABLE IF EXISTS `character_pvp_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_pvp_teams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `team_chars` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '[]' CHECK (json_valid(`team_chars`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_pvp_team_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_pvp_teams`
--

LOCK TABLES `character_pvp_teams` WRITE;
/*!40000 ALTER TABLE `character_pvp_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_pvp_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_sig_tech_abilities`
--

DROP TABLE IF EXISTS `character_sig_tech_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_sig_tech_abilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tech_id` int(11) NOT NULL,
  `ability_id` int(11) NOT NULL,
  `slot_number` int(11) NOT NULL DEFAULT 1,
  `unlocked_at_level` int(11) NOT NULL DEFAULT 3,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tech_slot` (`tech_id`,`slot_number`),
  KEY `ability_id` (`ability_id`),
  CONSTRAINT `character_sig_tech_abilities_ibfk_1` FOREIGN KEY (`tech_id`) REFERENCES `character_signature_techs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `character_sig_tech_abilities_ibfk_2` FOREIGN KEY (`ability_id`) REFERENCES `game_signature_abilities` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_sig_tech_abilities`
--

LOCK TABLES `character_sig_tech_abilities` WRITE;
/*!40000 ALTER TABLE `character_sig_tech_abilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_sig_tech_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_signature_techs`
--

DROP TABLE IF EXISTS `character_signature_techs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_signature_techs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `character_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `icon` varchar(16) DEFAULT '⚡',
  `description` text DEFAULT NULL,
  `tech_type` enum('ki_attack','physical','ki_heal') NOT NULL DEFAULT 'ki_attack',
  `current_level` int(11) NOT NULL DEFAULT 1,
  `current_xp` int(11) NOT NULL DEFAULT 0,
  `total_uses` int(11) NOT NULL DEFAULT 0,
  `daily_uses` int(11) NOT NULL DEFAULT 0 COMMENT 'for ki_heal: uses today',
  `daily_max` int(11) NOT NULL DEFAULT 1 COMMENT 'for ki_heal: max uses per day',
  `last_daily_reset` date DEFAULT NULL,
  `origin_text` text DEFAULT NULL COMMENT 'the flavor text pattern that spawned this technique',
  `origin_keywords` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'keyword cluster that triggered discovery' CHECK (json_valid(`origin_keywords`)),
  `element` varchar(32) DEFAULT NULL,
  `battle_text` varchar(255) DEFAULT NULL COMMENT 'custom battle announcement text',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_name` (`character_id`,`name`),
  KEY `idx_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_signature_techs`
--

LOCK TABLES `character_signature_techs` WRITE;
/*!40000 ALTER TABLE `character_signature_techs` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_signature_techs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_stats`
--

DROP TABLE IF EXISTS `character_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_stats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `stat_key` varchar(64) NOT NULL,
  `current_value` int(11) NOT NULL DEFAULT 0,
  `max_value` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_char_stat` (`character_id`,`stat_key`),
  KEY `idx_stats_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_stats`
--

LOCK TABLES `character_stats` WRITE;
/*!40000 ALTER TABLE `character_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_titles`
--

DROP TABLE IF EXISTS `character_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_titles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `title_id` int(10) unsigned NOT NULL,
  `earned_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_title` (`character_id`,`title_id`),
  KEY `idx_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_titles`
--

LOCK TABLES `character_titles` WRITE;
/*!40000 ALTER TABLE `character_titles` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_top_friends`
--

DROP TABLE IF EXISTS `character_top_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_top_friends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL COMMENT 'Owner of the top-friends list',
  `friend_char_id` int(10) unsigned NOT NULL COMMENT 'Character being featured',
  `slot` tinyint(3) unsigned NOT NULL COMMENT '1 through 8',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_tf_slot` (`character_id`,`slot`),
  UNIQUE KEY `uniq_tf_friend` (`character_id`,`friend_char_id`),
  KEY `idx_tf_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_top_friends`
--

LOCK TABLES `character_top_friends` WRITE;
/*!40000 ALTER TABLE `character_top_friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_top_friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_trade_log`
--

DROP TABLE IF EXISTS `character_trade_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_trade_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `trade_id` varchar(64) NOT NULL,
  `initiator_id` int(10) unsigned NOT NULL,
  `receiver_id` int(10) unsigned NOT NULL,
  `items_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`items_json`)),
  `gold_a` int(11) NOT NULL DEFAULT 0,
  `gold_b` int(11) NOT NULL DEFAULT 0,
  `completed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_trade_initiator` (`initiator_id`),
  KEY `idx_trade_receiver` (`receiver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_trade_log`
--

LOCK TABLES `character_trade_log` WRITE;
/*!40000 ALTER TABLE `character_trade_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_trade_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_training_log`
--

DROP TABLE IF EXISTS `character_training_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_training_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `character_id` int(11) NOT NULL,
  `training_type` varchar(32) NOT NULL,
  `partner_char_id` int(11) DEFAULT NULL,
  `master_npc_id` int(11) DEFAULT NULL,
  `stat_gains_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`stat_gains_json`)),
  `trained_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_training_log`
--

LOCK TABLES `character_training_log` WRITE;
/*!40000 ALTER TABLE `character_training_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_training_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_transformations`
--

DROP TABLE IF EXISTS `character_transformations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_transformations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `transformation_id` int(10) unsigned NOT NULL,
  `times_triggered` int(10) unsigned NOT NULL DEFAULT 0,
  `rp_triggers_completed` int(10) unsigned NOT NULL DEFAULT 0,
  `is_unlocked` tinyint(1) NOT NULL DEFAULT 0,
  `is_permanent` tinyint(1) NOT NULL DEFAULT 0,
  `unlocked_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_transform` (`character_id`,`transformation_id`),
  KEY `idx_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_transformations`
--

LOCK TABLES `character_transformations` WRITE;
/*!40000 ALTER TABLE `character_transformations` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_transformations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `characters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `class_id` int(10) unsigned NOT NULL DEFAULT 1,
  `race_id` int(10) unsigned NOT NULL DEFAULT 1,
  `background_id` int(10) unsigned NOT NULL DEFAULT 0,
  `feat_id` int(10) unsigned NOT NULL DEFAULT 0,
  `level` int(10) unsigned NOT NULL DEFAULT 1,
  `experience` int(10) unsigned NOT NULL DEFAULT 0,
  `current_hp` int(11) NOT NULL DEFAULT 100,
  `max_hp` int(11) NOT NULL DEFAULT 100,
  `current_mp` int(11) NOT NULL DEFAULT 50,
  `max_mp` int(11) NOT NULL DEFAULT 50,
  `atk` int(11) NOT NULL DEFAULT 10,
  `def` int(11) NOT NULL DEFAULT 5,
  `mo` int(11) NOT NULL DEFAULT 5,
  `md` int(11) NOT NULL DEFAULT 5,
  `speed` int(11) NOT NULL DEFAULT 10,
  `luck` int(11) NOT NULL DEFAULT 5,
  `map_id` int(10) unsigned NOT NULL DEFAULT 1,
  `x` int(11) NOT NULL DEFAULT 10,
  `y` int(11) NOT NULL DEFAULT 10,
  `limitbreak` float NOT NULL DEFAULT 0,
  `breaklevel` int(11) NOT NULL DEFAULT 1,
  `battle_record` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`battle_record`)),
  `status_effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`status_effects`)),
  `can_create_sig_tech` tinyint(1) NOT NULL DEFAULT 0,
  `master_training_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`master_training_json`)),
  `state_json` mediumtext DEFAULT NULL,
  `respawn_map_id` int(10) unsigned NOT NULL DEFAULT 1,
  `respawn_x` int(11) NOT NULL DEFAULT 10,
  `respawn_y` int(11) NOT NULL DEFAULT 10,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `equipped_title` varchar(64) DEFAULT NULL COMMENT 'The title shown in chat next to this character name',
  `profile_bio` text DEFAULT NULL COMMENT 'Player-written bio shown on profile page',
  `profile_color` varchar(7) NOT NULL DEFAULT '#bb86fc' COMMENT 'Accent color (hex)',
  `profile_banner_emoji` varchar(8) NOT NULL DEFAULT '⚔️' COMMENT 'Large decorative emoji on banner',
  `profile_favorite_quote` text DEFAULT NULL,
  `spotify_track_url` varchar(512) DEFAULT NULL COMMENT 'Spotify share URL — shown on profile',
  `spotify_track_name` varchar(256) DEFAULT NULL COMMENT 'Track display name',
  `spotify_artist_name` varchar(256) DEFAULT NULL COMMENT 'Artist display name',
  `presence_status` enum('online','away','busy','lfp','invisible') NOT NULL DEFAULT 'online',
  `away_message` text DEFAULT NULL COMMENT 'AIM-style personal away message',
  `profile_signature` text DEFAULT NULL COMMENT 'Forum-style signature shown on profile + chat hover',
  `profile_music_url` varchar(512) DEFAULT NULL,
  `profile_background` varchar(128) DEFAULT NULL,
  `profile_status` varchar(128) DEFAULT NULL,
  `profile_pinned_achievements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`profile_pinned_achievements`)),
  `show_profile_viewers` tinyint(1) NOT NULL DEFAULT 1,
  `profile_views` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'How many times profile page has been visited',
  `last_seen_at` timestamp NULL DEFAULT NULL COMMENT 'Last activity timestamp — updated server-side on actions',
  `death_count` int(11) NOT NULL DEFAULT 0,
  `current_afterlife_id` int(11) DEFAULT NULL,
  `afterlife_return_at` datetime DEFAULT NULL,
  `is_offline_visible` tinyint(1) NOT NULL DEFAULT 1,
  `current_ap` int(11) NOT NULL DEFAULT 6,
  `max_ap` int(11) NOT NULL DEFAULT 6,
  `is_reserve` tinyint(1) NOT NULL DEFAULT 0,
  `moves_today` int(10) unsigned NOT NULL DEFAULT 0,
  `moves_reset_at` timestamp NULL DEFAULT NULL,
  `appearance_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`appearance_json`)),
  `last_respec_at` timestamp NULL DEFAULT NULL,
  `mastery_xp` bigint(20) unsigned NOT NULL DEFAULT 0,
  `is_mastered` tinyint(1) NOT NULL DEFAULT 0,
  `secondary_class_id` int(10) unsigned DEFAULT NULL,
  `active_title_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_chars_user` (`user_id`),
  KEY `idx_chars_map` (`map_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES
(1,1,'Vengeance',3,1,3,0,1,0,110,110,70,70,14,8,8,10,18,20,1,11,10,0,1,NULL,NULL,0,NULL,'{\"tutorial_done\":true}',1,10,10,'2026-03-16 12:18:14',NULL,NULL,'#bb86fc','⚔️',NULL,NULL,NULL,NULL,'online',NULL,NULL,NULL,NULL,NULL,NULL,1,0,NULL,0,NULL,NULL,1,6,6,0,0,NULL,NULL,NULL,0,0,NULL,NULL),
(4,2,'Mado',1,1,1,0,1,0,170,170,30,30,18,12,5,8,12,10,1,10,10,0,1,NULL,NULL,0,NULL,'{\"tutorial_done\":true}',1,10,10,'2026-03-16 21:43:52',NULL,NULL,'#bb86fc','⚔️',NULL,NULL,NULL,NULL,'online',NULL,NULL,NULL,NULL,NULL,NULL,1,0,NULL,0,NULL,NULL,1,6,6,0,0,NULL,NULL,NULL,0,0,NULL,NULL),
(5,3,'Ronnie',1,1,1,0,1,0,170,170,30,30,18,12,5,8,12,10,1,10,10,0,1,NULL,NULL,0,NULL,'{\"tutorial_done\":true}',1,10,10,'2026-03-16 21:51:46',NULL,NULL,'#bb86fc','⚔️',NULL,NULL,NULL,NULL,'online',NULL,NULL,NULL,NULL,NULL,NULL,1,0,NULL,0,NULL,NULL,1,6,6,0,0,NULL,NULL,NULL,0,0,NULL,NULL),
(6,4,'zergsliver',4,2,1,0,1,0,130,130,110,110,8,8,14,14,13,13,1,13,10,0,1,NULL,NULL,0,NULL,'{\"tutorial_done\":true}',1,10,10,'2026-03-18 08:24:53',NULL,NULL,'#bb86fc','⚔️',NULL,NULL,NULL,NULL,'online',NULL,NULL,NULL,NULL,NULL,NULL,1,0,NULL,0,NULL,NULL,1,6,6,0,0,NULL,NULL,NULL,0,0,NULL,NULL),
(7,5,'AllenSam',1,1,1,0,1,0,170,170,30,30,18,12,5,8,12,10,1,10,10,0,1,NULL,NULL,0,NULL,'{\"tutorial_done\":true}',1,10,10,'2026-03-18 21:14:23',NULL,NULL,'#bb86fc','⚔️',NULL,NULL,NULL,NULL,'online',NULL,NULL,NULL,NULL,NULL,NULL,1,0,NULL,0,NULL,NULL,1,6,6,0,0,NULL,NULL,NULL,0,0,NULL,NULL);
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `codex_discoveries`
--

DROP TABLE IF EXISTS `codex_discoveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `codex_discoveries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `codex_entry_id` int(10) unsigned NOT NULL,
  `discovered_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_entry` (`character_id`,`codex_entry_id`),
  KEY `idx_disc_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `codex_discoveries`
--

LOCK TABLES `codex_discoveries` WRITE;
/*!40000 ALTER TABLE `codex_discoveries` DISABLE KEYS */;
/*!40000 ALTER TABLE `codex_discoveries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `codex_entries`
--

DROP TABLE IF EXISTS `codex_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `codex_entries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` enum('creatures','items','lore','locations','oghams') NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT NULL,
  `rarity` enum('common','uncommon','rare','epic','legendary') DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `element` varchar(64) DEFAULT NULL,
  `weakness` varchar(64) DEFAULT NULL,
  `drop_table_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`drop_table_json`)),
  `region` varchar(128) DEFAULT NULL,
  `min_level` int(11) DEFAULT NULL,
  `item_type` varchar(64) DEFAULT NULL,
  `stats_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`stats_json`)),
  `chapter` int(11) DEFAULT NULL,
  `ref_npc_id` int(10) unsigned DEFAULT NULL,
  `ref_item_id` int(10) unsigned DEFAULT NULL,
  `ref_map_id` int(10) unsigned DEFAULT NULL,
  `ref_ogham_id` int(10) unsigned DEFAULT NULL,
  `hidden` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_codex_cat` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `codex_entries`
--

LOCK TABLES `codex_entries` WRITE;
/*!40000 ALTER TABLE `codex_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `codex_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_modules`
--

DROP TABLE IF EXISTS `core_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `core_modules` (
  `module_key` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `config_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config_json`)),
  PRIMARY KEY (`module_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_modules`
--

LOCK TABLES `core_modules` WRITE;
/*!40000 ALTER TABLE `core_modules` DISABLE KEYS */;
INSERT INTO `core_modules` VALUES
('achievements','Achievements','Achievement tracking system.',0,NULL),
('artifacts','Artifacts','Legendary artifact system.',0,NULL),
('guilds','Guilds','Player-run guilds and guild management.',1,NULL),
('parties','Parties','Group up with other players.',1,NULL),
('pvp','PvP Combat','Player vs player battles.',1,NULL),
('quests','Quests','Quest log and progression system.',1,NULL),
('trade','Trading','Player-to-player item trading.',1,NULL),
('world_map','World Map','Fast travel between maps.',1,NULL);
/*!40000 ALTER TABLE `core_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factions`
--

DROP TABLE IF EXISTS `factions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '⚔️',
  `rival_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factions`
--

LOCK TABLES `factions` WRITE;
/*!40000 ALTER TABLE `factions` DISABLE KEYS */;
/*!40000 ALTER TABLE `factions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_ability_effects`
--

DROP TABLE IF EXISTS `game_ability_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_ability_effects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ability_id` int(10) unsigned NOT NULL,
  `stat_key` varchar(32) NOT NULL COMMENT 'e.g. atk, def, max_hp, dodge_chance, shop_discount',
  `bonus_per_point` decimal(5,2) NOT NULL DEFAULT 1.00 COMMENT 'bonus per point above 10',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ability` (`ability_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_ability_effects`
--

LOCK TABLES `game_ability_effects` WRITE;
/*!40000 ALTER TABLE `game_ability_effects` DISABLE KEYS */;
INSERT INTO `game_ability_effects` VALUES
(1,6,'luck',1.00,'Luck per point above 10'),
(2,6,'shop_discount',0.50,'Shop discount % per point above 10'),
(3,3,'max_hp',5.00,'HP per point above 10'),
(4,3,'bleed_resist',1.00,'Bleed resist per point above 10'),
(5,2,'speed',1.00,'Speed per point above 10'),
(6,2,'dodge_chance',0.50,'Dodge % per point above 10'),
(7,4,'mo',1.00,'Magic Offense per point above 10'),
(8,4,'craft_bonus',1.00,'Crafting quality per point above 10'),
(9,1,'atk',1.00,'ATK per point above 10'),
(10,1,'max_hp',2.00,'HP per point above 10'),
(11,5,'md',1.00,'Magic Defense per point above 10'),
(12,5,'perception',1.00,'Perception per point above 10');
/*!40000 ALTER TABLE `game_ability_effects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_ability_scores`
--

DROP TABLE IF EXISTS `game_ability_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_ability_scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key_name` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `celtic_name` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '⚡',
  `min_value` int(11) NOT NULL DEFAULT 8,
  `max_value` int(11) NOT NULL DEFAULT 15,
  `base_value` int(11) NOT NULL DEFAULT 8,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_ability_scores`
--

LOCK TABLES `game_ability_scores` WRITE;
/*!40000 ALTER TABLE `game_ability_scores` DISABLE KEYS */;
INSERT INTO `game_ability_scores` VALUES
(1,'strength','Strength','Neart','Physical power. Affects melee damage, carry weight, and intimidation.','💪',8,15,8,1),
(2,'dexterity','Dexterity','Lúth','Agility and reflexes. Affects speed, dodge, stealth, and lockpicking.','🏃',8,15,8,2),
(3,'constitution','Constitution','Cruas','Endurance and vitality. Affects HP, poison resistance, and stamina.','🛡️',8,15,8,3),
(4,'intellect','Intellect','Eagna','Knowledge and reasoning. Affects magic power, crafting, and trap detection.','📖',8,15,8,4),
(5,'wisdom','Wisdom','Fios','Perception and intuition. Affects magic defense, insight, and nature.','👁️',8,15,8,5),
(6,'charisma','Charisma','Draíocht','Force of personality. Affects luck, persuasion, shop prices, leadership.','✨',8,15,8,6);
/*!40000 ALTER TABLE `game_ability_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_achievements`
--

DROP TABLE IF EXISTS `game_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_achievements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key_name` varchar(64) NOT NULL,
  `title` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(16) NOT NULL DEFAULT '?',
  `category` enum('combat','social','exploration','progression','other') NOT NULL DEFAULT 'other',
  `trigger_type` enum('pvp_wins','pve_wins','quests_done','maps_visited','level_reached','manual','login_streak','gold_owned','battles_total') NOT NULL DEFAULT 'manual',
  `trigger_value` int(10) unsigned NOT NULL DEFAULT 1,
  `reward_gold` int(10) unsigned NOT NULL DEFAULT 0,
  `reward_title` varchar(64) DEFAULT NULL,
  `is_hidden` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `chain_group` varchar(64) DEFAULT NULL,
  `chain_tier` int(11) DEFAULT NULL,
  `chain_next_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_achievements`
--

LOCK TABLES `game_achievements` WRITE;
/*!40000 ALTER TABLE `game_achievements` DISABLE KEYS */;
INSERT INTO `game_achievements` VALUES
(1,'first_blood','First Blood','Win your first PvP battle.','🩸','combat','pvp_wins',1,100,'Bloodied',0,1,1,'2026-03-15 19:50:10',NULL,NULL,NULL),
(2,'centurion','Centurion','Win 100 PvP battles.','⚔️','combat','pvp_wins',100,500,'Centurion',0,1,2,'2026-03-15 19:50:10',NULL,NULL,NULL),
(3,'warlord','Warlord','Win 500 PvP battles.','🗡️','combat','pvp_wins',500,1000,'Warlord',0,1,3,'2026-03-15 19:50:10',NULL,NULL,NULL),
(4,'monster_slayer','Monster Slayer','Win 50 PvE battles.','👹','combat','pve_wins',50,200,'Slayer',0,1,4,'2026-03-15 19:50:10',NULL,NULL,NULL),
(5,'legend','Living Legend','Win 1000 PvE battles.','🌟','combat','pve_wins',1000,1000,'Legend',0,1,5,'2026-03-15 19:50:10',NULL,NULL,NULL),
(6,'wanderer','Wanderer','Discover 5 different maps.','🗺️','exploration','maps_visited',5,150,'Wanderer',0,1,6,'2026-03-15 19:50:10',NULL,NULL,NULL),
(7,'explorer','Grand Explorer','Discover 15 different maps.','🧭','exploration','maps_visited',15,400,'Explorer',0,1,7,'2026-03-15 19:50:10',NULL,NULL,NULL),
(8,'questling','Questling','Complete your first quest.','📜','progression','quests_done',1,50,NULL,0,1,8,'2026-03-15 19:50:10',NULL,NULL,NULL),
(9,'hero','Hero','Complete 25 quests.','🦸','progression','quests_done',25,300,'Hero',0,1,9,'2026-03-15 19:50:10',NULL,NULL,NULL),
(10,'max_level','Ascendant','Reach max level.','💎','progression','level_reached',99,2000,'Ascendant',0,1,10,'2026-03-15 19:50:10',NULL,NULL,NULL),
(11,'week_streak','Devoted','Log in 7 days in a row.','📅','social','login_streak',7,300,'Devoted',0,1,11,'2026-03-15 19:50:10',NULL,NULL,NULL),
(12,'rich','Gilded','Accumulate 10,000 gold.','💰','other','gold_owned',10000,0,'Gilded',0,1,12,'2026-03-15 19:50:10',NULL,NULL,NULL);
/*!40000 ALTER TABLE `game_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_action_commands`
--

DROP TABLE IF EXISTS `game_action_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_action_commands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `trigger_on` enum('attack','defend','skill','item','limit') NOT NULL DEFAULT 'attack',
  `timing_type` enum('single_press','multi_press','hold','rhythm') NOT NULL DEFAULT 'single_press',
  `window_ms` int(11) NOT NULL DEFAULT 500 COMMENT 'timing window in milliseconds',
  `perfect_window_ms` int(11) NOT NULL DEFAULT 100 COMMENT 'perfect timing window (smaller = harder)',
  `bonus_damage_pct` float NOT NULL DEFAULT 0.25 COMMENT 'bonus on successful timing',
  `perfect_bonus_pct` float NOT NULL DEFAULT 0.5 COMMENT 'bonus on perfect timing',
  `defense_reduction` float NOT NULL DEFAULT 0.25 COMMENT 'damage reduction on successful defend timing',
  `multi_press_count` int(11) NOT NULL DEFAULT 1 COMMENT 'for multi_press: how many presses needed',
  `skill_id` int(11) DEFAULT NULL COMMENT 'specific skill this applies to (NULL = all)',
  `description` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_trigger` (`trigger_on`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_action_commands`
--

LOCK TABLES `game_action_commands` WRITE;
/*!40000 ALTER TABLE `game_action_commands` DISABLE KEYS */;
INSERT INTO `game_action_commands` VALUES
(1,'Attack Timing','attack','single_press',600,150,0.25,0.5,0,1,NULL,'Press at impact for bonus damage!',1),
(2,'Defend Timing','defend','single_press',500,120,0,0,0.3,1,NULL,'Press as the attack hits to reduce damage!',1),
(3,'Skill Power-Up','skill','hold',800,200,0.2,0.4,0,1,NULL,'Hold and release at peak for bonus!',1),
(4,'Limit Burst','limit','multi_press',1000,300,0.3,0.6,0,1,NULL,'Mash rapidly during limit break for extra power!',1),
(5,'Item Mastery','item','single_press',700,180,0.3,0.5,0,1,NULL,'Time the use perfectly for enhanced effect!',1);
/*!40000 ALTER TABLE `game_action_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_afterlife_worlds`
--

DROP TABLE IF EXISTS `game_afterlife_worlds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_afterlife_worlds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `label` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `map_id` int(11) DEFAULT NULL,
  `type` enum('upper','lower','neutral') NOT NULL DEFAULT 'neutral',
  `alignment_min` int(11) DEFAULT NULL,
  `alignment_max` int(11) DEFAULT NULL,
  `stay_duration_days` int(11) NOT NULL DEFAULT 7,
  `training_bonus` float NOT NULL DEFAULT 0.01,
  `has_masters` tinyint(1) NOT NULL DEFAULT 0,
  `max_visits` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_afterlife_worlds`
--

LOCK TABLES `game_afterlife_worlds` WRITE;
/*!40000 ALTER TABLE `game_afterlife_worlds` DISABLE KEYS */;
INSERT INTO `game_afterlife_worlds` VALUES
(1,'The Upper Realm','Heaven','☁️',NULL,NULL,'upper',1,10,7,0.02,1,0,1),
(2,'The Lower Realm','Hell','????',NULL,NULL,'lower',-10,0,7,0.03,1,0,1),
(3,'The Between','Limbo','????️',NULL,NULL,'neutral',NULL,NULL,5,0.01,0,0,1);
/*!40000 ALTER TABLE `game_afterlife_worlds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_alignment_actions`
--

DROP TABLE IF EXISTS `game_alignment_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_alignment_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_key` varchar(64) NOT NULL COMMENT 'kill_innocent, heal_ally, spare_enemy, steal, etc.',
  `label` varchar(128) NOT NULL,
  `shift_amount` int(11) NOT NULL COMMENT 'positive = toward good, negative = toward evil',
  `description` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `action_key` (`action_key`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_alignment_actions`
--

LOCK TABLES `game_alignment_actions` WRITE;
/*!40000 ALTER TABLE `game_alignment_actions` DISABLE KEYS */;
INSERT INTO `game_alignment_actions` VALUES
(1,'spare_enemy','Spare a defeated enemy',5,'Show mercy after battle.',1),
(2,'release_ko','Release a knocked-out NPC',3,'Let them go free.',1),
(3,'heal_ally','Heal an injured ally',1,'Aid a friend in need.',1),
(4,'protect_innocent','Protect an innocent NPC',8,'Defend those who cannot fight.',1),
(5,'complete_good_quest','Complete a virtuous quest',10,'Do good work.',1),
(6,'kill_innocent','Kill an innocent NPC',-10,'Murder the defenseless.',1),
(7,'steal','Steal from someone',-3,'Take what isn\'t yours.',1),
(8,'torture_ko','Interrogate cruelly',-5,'Extract information through pain.',1),
(9,'finish_downed','Finish a downed PvP opponent',-8,'Kill when you could have spared.',1),
(10,'complete_evil_quest','Complete a villainous quest',-10,'Serve dark purposes.',1),
(11,'betray_ally','Betray an ally',-15,'The ultimate treachery.',1);
/*!40000 ALTER TABLE `game_alignment_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_alignment_tiers`
--

DROP TABLE IF EXISTS `game_alignment_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_alignment_tiers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL COMMENT 'paragon, guardian, neutral, corrupt, tyrant, etc.',
  `label` varchar(128) NOT NULL,
  `icon` varchar(16) DEFAULT '⚖️',
  `min_value` int(11) NOT NULL COMMENT 'alignment >= this',
  `max_value` int(11) NOT NULL COMMENT 'alignment <= this',
  `stat_bonuses` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"mo":0.10,"md":0.10} for light side, {"atk":0.10,"speed":0.05} for dark' CHECK (json_valid(`stat_bonuses`)),
  `skill_access` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"grant":[5,12],"block":[8,9]} — skills granted or blocked' CHECK (json_valid(`skill_access`)),
  `shop_price_mult` float NOT NULL DEFAULT 1 COMMENT 'NPC shop price modifier (evil = higher, good = lower)',
  `description` text DEFAULT NULL,
  `color` varchar(64) DEFAULT NULL COMMENT 'CSS color for UI display',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_alignment_tiers`
--

LOCK TABLES `game_alignment_tiers` WRITE;
/*!40000 ALTER TABLE `game_alignment_tiers` DISABLE KEYS */;
INSERT INTO `game_alignment_tiers` VALUES
(1,'paragon','Paragon','✨',75,100,'{\"mo\":0.15,\"md\":0.15,\"luck\":0.10}',NULL,0.85,'A beacon of virtue. Healing and protection amplified.','text-[oklch(0.70_0.15_210)]'),
(2,'guardian','Guardian','????️',40,74,'{\"mo\":0.08,\"md\":0.08,\"def\":0.05}',NULL,0.9,'Protector of the weak. Respected by most.','text-[oklch(0.60_0.15_210)]'),
(3,'virtuous','Virtuous','????',15,39,'{\"mo\":0.04,\"md\":0.04}',NULL,0.95,'Good-hearted. Minor bonuses to supportive abilities.','text-[oklch(0.55_0.12_210)]'),
(4,'neutral','Neutral','⚖️',-14,14,'{}',NULL,1,'Neither good nor evil. No alignment bonuses or penalties.','text-muted-foreground'),
(5,'dubious','Dubious','????',-39,-15,'{\"atk\":0.04,\"speed\":0.04}',NULL,1.05,'Morally grey. Minor bonuses to offensive abilities.','text-[oklch(0.55_0.12_25)]'),
(6,'corrupt','Corrupt','????',-74,-40,'{\"atk\":0.08,\"speed\":0.08,\"mo\":0.05}',NULL,1.1,'Embracing the darkness. Feared by many.','text-[oklch(0.60_0.15_25)]'),
(7,'tyrant','Tyrant','????',-100,-75,'{\"atk\":0.15,\"speed\":0.10,\"luck\":0.10,\"def\":-0.10}',NULL,1.2,'Pure malice. Devastating power at the cost of resilience.','text-destructive');
/*!40000 ALTER TABLE `game_alignment_tiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_arena_bets`
--

DROP TABLE IF EXISTS `game_arena_bets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_arena_bets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `match_id` bigint(20) unsigned NOT NULL,
  `bettor_char_id` int(10) unsigned NOT NULL,
  `bet_on_char_id` int(10) unsigned NOT NULL,
  `amount` int(10) unsigned NOT NULL,
  `payout` int(10) unsigned DEFAULT 0,
  `status` enum('pending','won','lost') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`id`),
  KEY `idx_match` (`match_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_arena_bets`
--

LOCK TABLES `game_arena_bets` WRITE;
/*!40000 ALTER TABLE `game_arena_bets` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_arena_bets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_arena_matches`
--

DROP TABLE IF EXISTS `game_arena_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_arena_matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `arena_id` int(10) unsigned NOT NULL,
  `tournament_id` int(10) unsigned DEFAULT NULL,
  `match_type` enum('pvp','ranked','training','boss','wave','team') NOT NULL DEFAULT 'pvp',
  `participants_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '[{"char_id":1,"team":1},{"char_id":2,"team":2}]' CHECK (json_valid(`participants_json`)),
  `winner_char_id` int(10) unsigned DEFAULT NULL,
  `winner_team` int(11) DEFAULT NULL,
  `waves_completed` int(11) DEFAULT 0,
  `duration_seconds` int(11) DEFAULT 0,
  `started_at` timestamp NULL DEFAULT current_timestamp(),
  `ended_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_arena` (`arena_id`),
  KEY `idx_tournament` (`tournament_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_arena_matches`
--

LOCK TABLES `game_arena_matches` WRITE;
/*!40000 ALTER TABLE `game_arena_matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_arena_matches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_arena_rankings`
--

DROP TABLE IF EXISTS `game_arena_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_arena_rankings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `arena_id` int(10) unsigned NOT NULL,
  `wins` int(10) unsigned NOT NULL DEFAULT 0,
  `losses` int(10) unsigned NOT NULL DEFAULT 0,
  `draws` int(10) unsigned NOT NULL DEFAULT 0,
  `rating` int(11) NOT NULL DEFAULT 1000 COMMENT 'ELO-style rating',
  `best_wave` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'highest wave reached in wave mode',
  `season` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_arena_season` (`character_id`,`arena_id`,`season`),
  KEY `idx_rating` (`arena_id`,`rating` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_arena_rankings`
--

LOCK TABLES `game_arena_rankings` WRITE;
/*!40000 ALTER TABLE `game_arena_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_arena_rankings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_arena_seasons`
--

DROP TABLE IF EXISTS `game_arena_seasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_arena_seasons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `arena_id` int(10) unsigned DEFAULT NULL COMMENT 'null=all arenas',
  `starts_at` timestamp NOT NULL,
  `ends_at` timestamp NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `prize_tiers_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"1":{"gold":5000,"title_id":1},"2":{"gold":2500},"3":{"gold":1000}}' CHECK (json_valid(`prize_tiers_json`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_arena_seasons`
--

LOCK TABLES `game_arena_seasons` WRITE;
/*!40000 ALTER TABLE `game_arena_seasons` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_arena_seasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_arenas`
--

DROP TABLE IF EXISTS `game_arenas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_arenas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `map_id` int(10) unsigned DEFAULT NULL,
  `x_min` int(11) NOT NULL DEFAULT 0,
  `y_min` int(11) NOT NULL DEFAULT 0,
  `x_max` int(11) NOT NULL DEFAULT 19,
  `y_max` int(11) NOT NULL DEFAULT 19,
  `type` varchar(32) NOT NULL DEFAULT 'OPEN_PVP',
  `min_level` int(11) NOT NULL DEFAULT 1,
  `max_level` int(11) NOT NULL DEFAULT 99,
  `entry_fee` int(11) NOT NULL DEFAULT 0,
  `reward_multiplier` float NOT NULL DEFAULT 1,
  `max_players` int(11) NOT NULL DEFAULT 0,
  `level_matching` tinyint(1) NOT NULL DEFAULT 1,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `scaling_factor` float NOT NULL DEFAULT 0.3,
  `allow_mid_battle_join` tinyint(1) NOT NULL DEFAULT 0,
  `allow_free_for_all` tinyint(1) NOT NULL DEFAULT 0,
  `allow_diplomacy` tinyint(1) NOT NULL DEFAULT 0,
  `allow_surrender` tinyint(1) NOT NULL DEFAULT 1,
  `allow_battle_chat` tinyint(1) NOT NULL DEFAULT 1,
  `max_teams` int(11) NOT NULL DEFAULT 2,
  `max_combatants` int(11) NOT NULL DEFAULT 8,
  `nonlethal` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=no death, losers respawn at entrance',
  `respawn_x` int(11) DEFAULT NULL,
  `respawn_y` int(11) DEFAULT NULL,
  `spectator_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `betting_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `wave_mode` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=Gold Saucer style wave battles',
  `heal_between_waves` tinyint(1) NOT NULL DEFAULT 1,
  `boss_can_kill` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'boss battles CAN result in death',
  `override_limb_targeting` enum('default','on','off') DEFAULT 'default',
  `override_active_defense` enum('default','on','off') DEFAULT 'default',
  `override_nonlethal` enum('default','on','off') DEFAULT 'default',
  `override_diminishing_returns` enum('default','on','off') DEFAULT 'default',
  `override_ki_channeling` enum('default','on','off') DEFAULT 'default',
  `override_summons` enum('default','on','off') DEFAULT 'default',
  `override_signature_techs` enum('default','on','off') DEFAULT 'default',
  `wave_config_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`wave_config_json`)),
  `wave_reward_per_wave` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`wave_reward_per_wave`)),
  `battle_condition_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_arenas`
--

LOCK TABLES `game_arenas` WRITE;
/*!40000 ALTER TABLE `game_arenas` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_arenas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_artifact_rivalries`
--

DROP TABLE IF EXISTS `game_artifact_rivalries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_artifact_rivalries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `artifact_a_id` int(10) unsigned NOT NULL,
  `artifact_b_id` int(10) unsigned NOT NULL,
  `relation` enum('allied','rival','neutral') NOT NULL DEFAULT 'rival',
  `effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"allied":{"atk_bonus":10},"rival":{"atk_penalty":-5,"clash_damage":true}}' CHECK (json_valid(`effect_json`)),
  `lore_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pair` (`artifact_a_id`,`artifact_b_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_artifact_rivalries`
--

LOCK TABLES `game_artifact_rivalries` WRITE;
/*!40000 ALTER TABLE `game_artifact_rivalries` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_artifact_rivalries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_assets`
--

DROP TABLE IF EXISTS `game_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_path` varchar(512) NOT NULL,
  `file_url` varchar(512) NOT NULL,
  `file_type` enum('sprite','portrait','tileset','icon','background','sound','music','effect','ui') NOT NULL DEFAULT 'sprite',
  `mime_type` varchar(64) DEFAULT NULL,
  `file_size` int(11) NOT NULL DEFAULT 0,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `category` varchar(64) DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_type` (`file_type`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_assets`
--

LOCK TABLES `game_assets` WRITE;
/*!40000 ALTER TABLE `game_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_auto_mod_rules`
--

DROP TABLE IF EXISTS `game_auto_mod_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_auto_mod_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `trigger_type` enum('chat_spam','reports_threshold','login_attempts','custom') NOT NULL DEFAULT 'chat_spam',
  `trigger_threshold` int(11) NOT NULL DEFAULT 10,
  `trigger_window_seconds` int(11) NOT NULL DEFAULT 30,
  `action_type` enum('mute','warn','flag','temp_ban','kick') NOT NULL DEFAULT 'mute',
  `action_duration_minutes` int(11) NOT NULL DEFAULT 5,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_auto_mod_rules`
--

LOCK TABLES `game_auto_mod_rules` WRITE;
/*!40000 ALTER TABLE `game_auto_mod_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_auto_mod_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_autotile_groups`
--

DROP TABLE IF EXISTS `game_autotile_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_autotile_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `base_tile` int(11) NOT NULL DEFAULT 0,
  `tile_map` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '{"0":base,"1":N,"2":E,...,"15":NESW} — 16 entries mapping bitmask to tile index' CHECK (json_valid(`tile_map`)),
  `tileset_url` varchar(255) DEFAULT NULL COMMENT 'if null, uses the map tileset',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_autotile_groups`
--

LOCK TABLES `game_autotile_groups` WRITE;
/*!40000 ALTER TABLE `game_autotile_groups` DISABLE KEYS */;
INSERT INTO `game_autotile_groups` VALUES
(1,'Water','????',NULL,10,'{\"0\":10,\"1\":26,\"2\":11,\"3\":27,\"4\":18,\"5\":34,\"6\":19,\"7\":35,\"8\":9,\"9\":25,\"10\":8,\"11\":24,\"12\":17,\"13\":33,\"14\":16,\"15\":32}',NULL,1),
(2,'Wall','????',NULL,20,'{\"0\":20,\"1\":36,\"2\":21,\"3\":37,\"4\":28,\"5\":44,\"6\":29,\"7\":45,\"8\":19,\"9\":35,\"10\":18,\"11\":34,\"12\":27,\"13\":43,\"14\":26,\"15\":42}',NULL,1),
(3,'Grass','????',NULL,30,'{\"0\":30,\"1\":46,\"2\":31,\"3\":47,\"4\":38,\"5\":54,\"6\":39,\"7\":55,\"8\":29,\"9\":45,\"10\":28,\"11\":44,\"12\":37,\"13\":53,\"14\":36,\"15\":52}',NULL,1),
(4,'Path','????',NULL,40,'{\"0\":40,\"1\":56,\"2\":41,\"3\":57,\"4\":48,\"5\":64,\"6\":49,\"7\":65,\"8\":39,\"9\":55,\"10\":38,\"11\":54,\"12\":47,\"13\":63,\"14\":46,\"15\":62}',NULL,1);
/*!40000 ALTER TABLE `game_autotile_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_background_ability_bonuses`
--

DROP TABLE IF EXISTS `game_background_ability_bonuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_background_ability_bonuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `background_id` int(10) unsigned NOT NULL,
  `ability_id` int(10) unsigned NOT NULL,
  `bonus` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bg_ability` (`background_id`,`ability_id`),
  KEY `idx_bg` (`background_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_background_ability_bonuses`
--

LOCK TABLES `game_background_ability_bonuses` WRITE;
/*!40000 ALTER TABLE `game_background_ability_bonuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_background_ability_bonuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_backgrounds`
--

DROP TABLE IF EXISTS `game_backgrounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_backgrounds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '?',
  `lore` text DEFAULT NULL,
  `bonus_hp` int(11) NOT NULL DEFAULT 0,
  `bonus_mp` int(11) NOT NULL DEFAULT 0,
  `bonus_atk` int(11) NOT NULL DEFAULT 0,
  `bonus_def` int(11) NOT NULL DEFAULT 0,
  `bonus_mo` int(11) NOT NULL DEFAULT 0,
  `bonus_md` int(11) NOT NULL DEFAULT 0,
  `bonus_speed` int(11) NOT NULL DEFAULT 0,
  `bonus_luck` int(11) NOT NULL DEFAULT 0,
  `bonus_str` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_backgrounds`
--

LOCK TABLES `game_backgrounds` WRITE;
/*!40000 ALTER TABLE `game_backgrounds` DISABLE KEYS */;
INSERT INTO `game_backgrounds` VALUES
(1,'Soldier','Trained in the army. Extra HP from physical conditioning.','📖',NULL,20,0,0,0,0,0,0,0,'+20 HP'),
(2,'Scholar','Years of study grant extra MP and magical insight.','📖',NULL,0,20,0,0,0,0,0,0,'+20 MP'),
(3,'Street Rat','Surviving on the streets taught resourcefulness.','📖',NULL,10,10,0,0,0,0,0,0,'+10 HP/MP'),
(4,'Noble','A privileged upbringing. No stat bonus but high standing.','📖',NULL,0,0,0,0,0,0,0,0,'None');
/*!40000 ALTER TABLE `game_backgrounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_commands`
--

DROP TABLE IF EXISTS `game_battle_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_commands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '⚔️',
  `description` text DEFAULT NULL,
  `action_type` enum('attack','defend','skills','items','run','limit','custom') NOT NULL DEFAULT 'attack',
  `target_type` varchar(32) NOT NULL DEFAULT 'ENEMY',
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `class_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`class_ids`)),
  `effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`effects`)),
  `combo_chance` float NOT NULL DEFAULT 0 COMMENT '0-1 probability of extra attack',
  `combo_max_chain` int(11) NOT NULL DEFAULT 1 COMMENT 'max extra hits from combo',
  `is_defense` tinyint(1) NOT NULL DEFAULT 0,
  `defense_type` enum('dodge','block','counter') DEFAULT NULL,
  `sfx_asset_id` int(11) DEFAULT NULL,
  `can_interrupt` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'this attack can interrupt others',
  `is_interruptible` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'this action can be interrupted',
  `interrupt_priority` int(11) NOT NULL DEFAULT 0 COMMENT 'higher = interrupts more things',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_commands`
--

LOCK TABLES `game_battle_commands` WRITE;
/*!40000 ALTER TABLE `game_battle_commands` DISABLE KEYS */;
INSERT INTO `game_battle_commands` VALUES
(1,'Attack','⚔️','Deal physical damage to the enemy.','attack','ENEMY',1,1,NULL,'{\"damage\":{\"formula\":\"ATK*2-DEF\",\"randomize\":0.15},\"apply_weapon_elements\":true,\"apply_weapon_status\":true,\"log\":\"{name} attacks!\"}',0.2,1,0,NULL,NULL,0,1,0),
(2,'Defend','🛡️','Brace yourself — take half damage this turn.','defend','SELF',1,2,NULL,'{\"set_status\":{\"target\":\"self\",\"statuses\":{\"Defending\":1}},\"log\":\"{name} defends!\"}',0,1,0,NULL,NULL,0,1,0),
(3,'Skills','✨','Open the skill menu.','skills','MENU',1,3,NULL,'{\"open_menu\":\"skills\"}',0,1,0,NULL,NULL,0,1,0),
(4,'Items','🎒','Use a consumable item.','items','MENU',1,4,NULL,'{\"open_menu\":\"items\"}',0,1,0,NULL,NULL,0,1,0),
(5,'Limit','💥','Unleash your limit break (bar must be full).','limit','MENU',1,5,NULL,'{\"open_menu\":\"limits\"}',0,1,0,NULL,NULL,0,1,0),
(6,'Run','🏃','Attempt to flee the battle.','run','NONE',1,6,NULL,'{\"flee\":{\"formula\":\"SPEED+LUCK*0.5-ENEMY_SPEED\",\"log_success\":\"{name} escapes!\",\"log_fail\":\"{name} couldn\'t escape!\"}}',0,1,0,NULL,NULL,0,1,0),
(10,'Dodge','????','Attempt to evade.','attack','ENEMY',0,10,NULL,'{\"defense\":\"dodge\"}',0,1,1,'dodge',NULL,0,1,0),
(11,'Block','????️','Brace for impact.','attack','ENEMY',0,11,NULL,'{\"defense\":\"block\"}',0,1,1,'block',NULL,0,1,0),
(12,'Counter','↩️','Turn the attack back.','attack','ENEMY',0,12,NULL,'{\"defense\":\"counter\"}',0,1,1,'counter',NULL,0,1,0),
(13,'Channel Ki','????','Surge to full power.','attack','ENEMY',0,13,NULL,'{\"ki_channel\":true}',0,1,0,NULL,NULL,0,1,0),
(14,'Taunt','????','Draw enemy attention.','attack','ENEMY',0,14,NULL,'{\"rp_command\":\"taunt\",\"aggro_duration\":1,\"self_damage_bonus\":0.10,\"bonus_duration\":1}',0,1,0,NULL,NULL,0,1,0),
(15,'Intimidate','????️','Shake the enemy.','attack','ENEMY',0,15,NULL,'{\"rp_command\":\"intimidate\",\"base_chance\":0.50,\"atk_reduction\":0.15,\"accuracy_reduction\":0.10,\"duration\":2}',0,1,0,NULL,NULL,0,1,0),
(16,'Rally','????','Inspire allies.','attack','ENEMY',0,16,NULL,'{\"rp_command\":\"rally\",\"atk_bonus\":0.10,\"speed_bonus\":0.10,\"duration\":2}',0,1,0,NULL,NULL,0,1,0),
(17,'Summon','????','Call forth a spirit.','attack','ENEMY',0,17,NULL,'{\"summon\":true}',0,1,0,NULL,NULL,0,1,0),
(18,'Stealth','????','Attempt to hide.','attack','ENEMY',0,18,NULL,'{\"stealth\":true}',0,1,0,NULL,NULL,0,1,0),
(19,'Transform','⭐','Unleash inner power!','attack','ENEMY',0,19,NULL,'{\"transform\":true}',0,1,0,NULL,NULL,0,1,0),
(20,'Swap Gear','????','Change equipped weapon.','attack','ENEMY',0,20,NULL,'{\"equip_swap\":true}',0,1,0,NULL,NULL,0,1,0),
(21,'Steal','🖐','Attempt to steal an item from the target. Chance based on Luck and Speed.','attack','ENEMY',1,50,NULL,'{\"steal\":true}',0,1,0,NULL,NULL,0,1,0);
/*!40000 ALTER TABLE `game_battle_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_conditions`
--

DROP TABLE IF EXISTS `game_battle_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_conditions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '⚡',
  `description` text DEFAULT NULL,
  `effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '{"damage_mult":2.0,"no_magic":true,"turn_limit":10,"all_hp":1}' CHECK (json_valid(`effect_json`)),
  `condition_type` enum('random','arena','event','admin') NOT NULL DEFAULT 'arena',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_conditions`
--

LOCK TABLES `game_battle_conditions` WRITE;
/*!40000 ALTER TABLE `game_battle_conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_battle_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_items`
--

DROP TABLE IF EXISTS `game_battle_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL COMMENT 'links to game_items',
  `effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '{"heal_pct":50} or {"damage":100} or {"status_cure":true}' CHECK (json_valid(`effect_json`)),
  `uses_per_battle` int(11) NOT NULL DEFAULT 1,
  `cooldown_turns` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_items`
--

LOCK TABLES `game_battle_items` WRITE;
/*!40000 ALTER TABLE `game_battle_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_battle_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_knockouts`
--

DROP TABLE IF EXISTS `game_battle_knockouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_knockouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `battle_id` int(11) NOT NULL,
  `npc_char_id` int(11) NOT NULL,
  `npc_name` varchar(128) DEFAULT '',
  `knocked_out_by` int(11) NOT NULL,
  `ko_method` varchar(32) DEFAULT 'nonlethal',
  `interaction` varchar(32) DEFAULT NULL,
  `interaction_result` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`interaction_result`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_knockouts`
--

LOCK TABLES `game_battle_knockouts` WRITE;
/*!40000 ALTER TABLE `game_battle_knockouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_battle_knockouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_limb_state`
--

DROP TABLE IF EXISTS `game_battle_limb_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_limb_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `battle_id` int(11) NOT NULL,
  `character_id` int(11) NOT NULL,
  `limb_hp_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`limb_hp_json`)),
  `wound_levels_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`wound_levels_json`)),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_battle_char` (`battle_id`,`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_limb_state`
--

LOCK TABLES `game_battle_limb_state` WRITE;
/*!40000 ALTER TABLE `game_battle_limb_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_battle_limb_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_narrations`
--

DROP TABLE IF EXISTS `game_battle_narrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_narrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_type` varchar(32) NOT NULL,
  `weapon_type` varchar(32) DEFAULT NULL,
  `element` varchar(32) DEFAULT NULL,
  `terrain` varchar(32) DEFAULT NULL,
  `target_zone` varchar(32) DEFAULT NULL,
  `text_template` text NOT NULL,
  `weight` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_narrations`
--

LOCK TABLES `game_battle_narrations` WRITE;
/*!40000 ALTER TABLE `game_battle_narrations` DISABLE KEYS */;
INSERT INTO `game_battle_narrations` VALUES
(1,'attack','sword',NULL,NULL,NULL,'{actor} lunges forward, blade singing through the air, and carves a vicious arc across {target}!',2,1),
(2,'attack','axe',NULL,NULL,NULL,'{actor} heaves the axe overhead and brings it crashing down on {target}!',2,1),
(3,'attack','fist',NULL,NULL,NULL,'{actor} surges forward and drives a thunderous fist into {target}!',2,1),
(4,'attack',NULL,NULL,NULL,NULL,'{actor} strikes at {target} with practiced precision!',1,1),
(5,'crit',NULL,NULL,NULL,NULL,'The blow lands with devastating force — {target} staggers!',3,1),
(6,'dodge',NULL,NULL,NULL,NULL,'{target} reads the attack and sidesteps at the last instant!',2,1),
(7,'block',NULL,NULL,NULL,NULL,'{target} raises their guard — the impact jars their arms but holds!',2,1),
(8,'miss',NULL,NULL,NULL,NULL,'{actor}\'s strike goes wide, cutting only air!',2,1),
(9,'kill',NULL,NULL,NULL,NULL,'{target} crumples, the light fading from their eyes. It is done.',3,1),
(10,'ko',NULL,NULL,NULL,NULL,'{target} slumps to the ground, unconscious but breathing.',2,1),
(11,'heal',NULL,NULL,NULL,NULL,'Warm light flows from {actor}\'s hands, knitting flesh and easing pain.',2,1),
(12,'combo',NULL,NULL,NULL,NULL,'{actor} presses the advantage — another strike follows!',2,1);
/*!40000 ALTER TABLE `game_battle_narrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_participants`
--

DROP TABLE IF EXISTS `game_battle_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_participants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `battle_id` int(10) unsigned NOT NULL,
  `character_id` int(10) unsigned NOT NULL,
  `team` tinyint(4) NOT NULL COMMENT '1=players, 2=enemies',
  `is_ai` tinyint(1) NOT NULL DEFAULT 0,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_battle_char` (`battle_id`,`character_id`),
  KEY `idx_bp_battle` (`battle_id`),
  KEY `idx_bp_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_participants`
--

LOCK TABLES `game_battle_participants` WRITE;
/*!40000 ALTER TABLE `game_battle_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_battle_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_replays`
--

DROP TABLE IF EXISTS `game_battle_replays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_replays` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `battle_id` varchar(64) NOT NULL,
  `participants_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`participants_json`)),
  `turns_json` mediumtext NOT NULL COMMENT 'full turn-by-turn log',
  `winner_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`winner_json`)),
  `battle_type` enum('pve','pvp','arena','tournament','boss') NOT NULL DEFAULT 'pve',
  `arena_id` int(10) unsigned DEFAULT NULL,
  `tournament_id` int(10) unsigned DEFAULT NULL,
  `duration_seconds` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_battle` (`battle_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_replays`
--

LOCK TABLES `game_battle_replays` WRITE;
/*!40000 ALTER TABLE `game_battle_replays` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_battle_replays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_rules`
--

DROP TABLE IF EXISTS `game_battle_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 0 COMMENT 'higher = evaluated first',
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `scope` enum('global','map','arena','encounter','quest') NOT NULL DEFAULT 'global',
  `scope_id` int(11) DEFAULT NULL COMMENT 'map_id, arena_id, etc. NULL for global',
  `trigger_event` enum('turn_start','turn_end','battle_start','battle_end','on_damage_dealt','on_damage_taken','on_kill','on_ko','on_heal','on_status_applied','on_status_removed','on_phase_change','on_move','on_flee_attempt','hp_threshold','mp_threshold','turn_number','combatant_count') NOT NULL DEFAULT 'turn_start',
  `target_filter` enum('all','all_players','all_enemies','all_allies','active_combatant','target_combatant','lowest_hp','highest_hp','random_enemy','random_ally','boss','summoned','transformed','stealthed') NOT NULL DEFAULT 'all',
  `condition_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'conditions to check' CHECK (json_valid(`condition_json`)),
  `effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'effects to apply' CHECK (json_valid(`effect_json`)),
  `max_triggers` int(11) NOT NULL DEFAULT 0 COMMENT '0 = unlimited, N = max N times per battle',
  `cooldown_turns` int(11) NOT NULL DEFAULT 0 COMMENT 'turns between triggers',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_scope` (`scope`,`scope_id`),
  KEY `idx_trigger` (`trigger_event`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_rules`
--

LOCK TABLES `game_battle_rules` WRITE;
/*!40000 ALTER TABLE `game_battle_rules` DISABLE KEYS */;
INSERT INTO `game_battle_rules` VALUES
(1,'Low HP Enrage','When any enemy drops below 25% HP, they enrage (+20% ATK for 3 turns).',10,1,'global',NULL,'on_damage_taken','target_combatant','{\"stat\":\"hp_pct\",\"operator\":\"<\",\"value\":0.25,\"target_is\":\"enemy\"}','{\"apply_status\":\"ATK Up\",\"duration\":3,\"announce\":\"{name} flies into a rage!\"}',0,0,'2026-03-18 09:32:21'),
(2,'Overtime Pressure','After turn 15, all combatants take 5% max HP damage per turn.',5,1,'global',NULL,'turn_start','all','{\"stat\":\"turn_number\",\"operator\":\">=\",\"value\":15}','{\"damage\":{\"formula\":\"MAXHP*0.05\",\"type\":\"neutral\"},\"announce\":\"The battlefield grows hostile!\"}',0,0,'2026-03-18 09:32:21'),
(3,'Last Stand','When only 1 ally remains, they get +30% to all stats.',8,1,'global',NULL,'on_kill','all_players','{\"combatant_count\":\"allies\",\"operator\":\"<=\",\"value\":1}','{\"stat_mod\":{\"atk\":0.30,\"def\":0.30,\"speed\":0.30},\"duration\":99,\"announce\":\"{name} fights with the fury of the fallen!\"}',0,0,'2026-03-18 09:32:21'),
(4,'Dark Alignment Aura','Characters with evil alignment (-50 or lower) radiate dark damage to adjacent enemies each turn.',3,1,'global',NULL,'turn_start','active_combatant','{\"stat\":\"alignment\",\"operator\":\"<\",\"value\":-50}','{\"aoe_damage\":{\"formula\":\"MO*0.1\",\"radius\":1,\"type\":\"dark\"},\"announce\":\"Dark energy radiates from {name}!\"}',0,0,'2026-03-18 09:32:21');
/*!40000 ALTER TABLE `game_battle_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_templates`
--

DROP TABLE IF EXISTS `game_battle_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `label` varchar(128) NOT NULL,
  `icon` varchar(8) DEFAULT '⚔️',
  `description` text DEFAULT NULL,
  `author` varchar(64) DEFAULT 'Twisted Engine',
  `version` varchar(16) DEFAULT '1.0',
  `settings_json` mediumtext NOT NULL,
  `terminology_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`terminology_json`)),
  `sample_commands_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sample_commands_json`)),
  `sample_ki_moves_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sample_ki_moves_json`)),
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `installed` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_templates`
--

LOCK TABLES `game_battle_templates` WRITE;
/*!40000 ALTER TABLE `game_battle_templates` DISABLE KEYS */;
INSERT INTO `game_battle_templates` VALUES
(1,'classic_turn','Classic Turn-Based','⚔️','Traditional JRPG combat. Take turns, select commands, use items and skills. Inspired by Final Fantasy and Dragon Quest.','Twisted Engine','1.0','{\"enable_dice_rolls\":\"false\",\"ki_equals_hp\":\"false\",\"enable_formations\":\"true\",\"enable_counter_attacks\":\"true\",\"enable_auto_battle\":\"true\",\"battle_turn_delay_ms\":\"1500\"}','{\"hp\":\"HP\",\"mp\":\"MP\",\"atk\":\"STR\",\"def\":\"VIT\",\"mo\":\"MAG\",\"md\":\"SPR\",\"speed\":\"AGI\",\"luck\":\"LCK\"}','[{\"name\":\"Attack\",\"icon\":\"⚔️\"},{\"name\":\"Defend\",\"icon\":\"🛡️\"},{\"name\":\"Magic\",\"icon\":\"✨\"},{\"name\":\"Item\",\"icon\":\"🎒\"},{\"name\":\"Flee\",\"icon\":\"🏃\"}]',NULL,1,0),
(2,'sim_battle','Sim Battle (RP Combat)','🎲','Dice-roll RP combat. Ki = HP, moves drain life force. Planet Mado style. Best for RP-heavy games.','Twisted Engine','1.0','{\"enable_dice_rolls\":\"true\",\"dice_attack_formula\":\"1d20+ATK\",\"dice_defense_formula\":\"1d20+DEF\",\"dice_dodge_formula\":\"1d20+SPEED\",\"dice_crit_threshold\":\"18\",\"dice_show_rolls_in_chat\":\"true\",\"ki_equals_hp\":\"true\",\"ki_moves_use_hp\":\"true\",\"ki_label\":\"Ki\",\"enable_beam_clash\":\"true\",\"beam_clash_formula\":\"ATK+1d20\",\"beam_clash_damage_mult\":\"3.0\",\"enable_interrupts\":\"true\",\"enable_counter_attacks\":\"true\",\"counter_base_chance\":\"15\",\"enable_mentor_system\":\"true\",\"enable_magic_duels\":\"true\",\"battle_turn_delay_ms\":\"2000\",\"enable_auto_battle\":\"false\",\"enable_formations\":\"false\"}','{\"hp\":\"Ki\",\"mp\":\"Focus\",\"atk\":\"Power Level\",\"def\":\"Endurance\",\"mo\":\"Ki Control\",\"md\":\"Ki Defense\",\"speed\":\"Speed\",\"luck\":\"Instinct\"}','[{\"name\":\"Strike\",\"icon\":\"👊\"},{\"name\":\"Block\",\"icon\":\"🛡️\"},{\"name\":\"Ki Charge\",\"icon\":\"⚡\"},{\"name\":\"Sense\",\"icon\":\"👁️\"},{\"name\":\"Flee\",\"icon\":\"💨\"}]','[{\"name\":\"Ki Blast\",\"icon\":\"💥\",\"move_type\":\"blast\",\"hp_cost_pct\":5,\"damage_formula\":\"ATK*2\",\"charge_turns\":0},{\"name\":\"Kamehameha\",\"icon\":\"🌊\",\"move_type\":\"beam\",\"hp_cost_pct\":15,\"damage_formula\":\"ATK*4+MO*2\",\"charge_turns\":2,\"brunt_mode\":1},{\"name\":\"Solar Flare\",\"icon\":\"☀️\",\"move_type\":\"special\",\"hp_cost_pct\":3,\"damage_formula\":\"0\"},{\"name\":\"Spirit Bomb\",\"icon\":\"💫\",\"move_type\":\"beam\",\"hp_cost_pct\":30,\"damage_formula\":\"ATK*8\",\"charge_turns\":3,\"brunt_mode\":1},{\"name\":\"Destructo Disc\",\"icon\":\"💿\",\"move_type\":\"blast\",\"hp_cost_pct\":10,\"damage_formula\":\"ATK*3\",\"charge_turns\":1}]',0,0),
(3,'tactical_grid','Tactical Grid Combat','♟️','Position-matters grid combat with formations, flanking, and terrain. Inspired by Fire Emblem and BG3.','Twisted Engine','1.0','{\"enable_dice_rolls\":\"true\",\"dice_attack_formula\":\"1d20+ATK\",\"dice_crit_threshold\":\"20\",\"dice_show_rolls_in_chat\":\"true\",\"enable_formations\":\"true\",\"back_row_damage_reduction\":\"40\",\"back_row_melee_penalty\":\"60\",\"enable_counter_attacks\":\"true\",\"counter_base_chance\":\"20\",\"counter_dex_scaling\":\"1.0\",\"enable_interrupts\":\"true\",\"interrupt_speed_threshold\":\"3\",\"enable_aggro_system\":\"true\",\"aggro_decay_per_turn\":\"15\",\"taunt_duration_turns\":\"2\",\"enable_auto_battle\":\"false\",\"battle_turn_delay_ms\":\"1000\"}','{\"hp\":\"Health\",\"mp\":\"Mana\",\"atk\":\"Might\",\"def\":\"Armor\",\"mo\":\"Arcane\",\"md\":\"Warding\",\"speed\":\"Initiative\",\"luck\":\"Fortune\"}','[{\"name\":\"Attack\",\"icon\":\"⚔️\"},{\"name\":\"Defend\",\"icon\":\"🛡️\"},{\"name\":\"Move\",\"icon\":\"🏃\"},{\"name\":\"Skill\",\"icon\":\"✨\"},{\"name\":\"Item\",\"icon\":\"🎒\"},{\"name\":\"Taunt\",\"icon\":\"😤\"}]',NULL,0,0);
/*!40000 ALTER TABLE `game_battle_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_terrain`
--

DROP TABLE IF EXISTS `game_battle_terrain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_terrain` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `stat_modifiers_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"speed":-2,"dodge_chance":-5}' CHECK (json_valid(`stat_modifiers_json`)),
  `movement_cost_mult` decimal(3,1) NOT NULL DEFAULT 1.0,
  `type_advantages_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"flying":1.2,"earth":0.8}' CHECK (json_valid(`type_advantages_json`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_terrain`
--

LOCK TABLES `game_battle_terrain` WRITE;
/*!40000 ALTER TABLE `game_battle_terrain` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_battle_terrain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battle_traps`
--

DROP TABLE IF EXISTS `game_battle_traps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battle_traps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `damage_formula` varchar(255) DEFAULT 'ATK*1.5',
  `trigger_type` enum('step','proximity','timed') NOT NULL DEFAULT 'step',
  `trigger_radius` int(11) NOT NULL DEFAULT 0,
  `duration_turns` int(11) NOT NULL DEFAULT 0,
  `status_apply` varchar(32) DEFAULT NULL,
  `visible_to_enemy` tinyint(1) NOT NULL DEFAULT 0,
  `uses` int(11) NOT NULL DEFAULT 1,
  `skill_id` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battle_traps`
--

LOCK TABLES `game_battle_traps` WRITE;
/*!40000 ALTER TABLE `game_battle_traps` DISABLE KEYS */;
INSERT INTO `game_battle_traps` VALUES
(1,'Spike Trap','????',NULL,'ATK*1.0','step',0,0,NULL,0,1,NULL,1),
(2,'Fire Rune','????',NULL,'MO*1.5','step',0,0,'Burning',0,1,NULL,1),
(3,'Frost Snare','❄️',NULL,'MO*0.5','proximity',0,0,'Stun',0,1,NULL,1),
(4,'Poison Cloud','☁️',NULL,'0','proximity',0,0,'Poison',0,1,NULL,1);
/*!40000 ALTER TABLE `game_battle_traps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_battles`
--

DROP TABLE IF EXISTS `game_battles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_battles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `p1_char_id` int(10) unsigned NOT NULL,
  `p2_char_id` int(10) unsigned NOT NULL,
  `p1_user_id` int(10) unsigned NOT NULL,
  `p2_user_id` int(10) unsigned NOT NULL,
  `turn_char_id` int(10) unsigned DEFAULT NULL,
  `battle_mode` enum('1v1','PARTY') NOT NULL DEFAULT '1v1',
  `status` enum('pending','active','complete','cancelled') NOT NULL DEFAULT 'pending',
  `winner_char_id` int(10) unsigned DEFAULT NULL,
  `battle_log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`battle_log`)),
  `access_token` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_battles_p1` (`p1_char_id`),
  KEY `idx_battles_p2` (`p2_char_id`),
  KEY `idx_battles_token` (`access_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_battles`
--

LOCK TABLES `game_battles` WRITE;
/*!40000 ALTER TABLE `game_battles` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_battles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_bleed_tiers`
--

DROP TABLE IF EXISTS `game_bleed_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_bleed_tiers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `label` varchar(64) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `duration_turns` int(11) NOT NULL DEFAULT 2,
  `damage_pct` float NOT NULL DEFAULT 0.03,
  `description` text DEFAULT NULL,
  `color` varchar(32) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_bleed_tiers`
--

LOCK TABLES `game_bleed_tiers` WRITE;
/*!40000 ALTER TABLE `game_bleed_tiers` DISABLE KEYS */;
INSERT INTO `game_bleed_tiers` VALUES
(1,'light','Light Bleed','????',2,0.03,NULL,'text-[oklch(0.65_0.15_25)]','2026-03-18 09:45:21'),
(2,'moderate','Moderate Bleed','????',4,0.03,NULL,'text-[oklch(0.55_0.20_25)]','2026-03-18 09:45:21'),
(3,'heavy','Heavy Bleed','????',5,0.03,NULL,'text-destructive','2026-03-18 09:45:21');
/*!40000 ALTER TABLE `game_bleed_tiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_body_types`
--

DROP TABLE IF EXISTS `game_body_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_body_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `label` varchar(128) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_body_types`
--

LOCK TABLES `game_body_types` WRITE;
/*!40000 ALTER TABLE `game_body_types` DISABLE KEYS */;
INSERT INTO `game_body_types` VALUES
(1,'humanoid','Humanoid','Standard bipedal','🧍','2026-03-18 09:36:54'),
(2,'beast','Beast','Four-legged creature','🐺','2026-03-18 09:36:54'),
(3,'serpent','Serpent','Elongated body','🐍','2026-03-18 09:36:54'),
(4,'amorphous','Amorphous','Formless','🫧','2026-03-18 09:36:54');
/*!40000 ALTER TABLE `game_body_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_boss_phases`
--

DROP TABLE IF EXISTS `game_boss_phases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_boss_phases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `npc_id` int(11) NOT NULL COMMENT 'game_npcs.id that this phase belongs to',
  `phase_number` int(11) NOT NULL DEFAULT 1,
  `trigger_type` enum('hp_pct','turn','manual') NOT NULL DEFAULT 'hp_pct',
  `trigger_value` float NOT NULL DEFAULT 0.5 COMMENT 'hp_pct: 0.50=at 50% HP. turn: turn number.',
  `name` varchar(128) DEFAULT NULL COMMENT 'Phase name: "Enraged", "Final Form"',
  `description` text DEFAULT NULL,
  `icon` varchar(16) DEFAULT '⚡',
  `battle_text` text DEFAULT NULL COMMENT 'Announced when phase triggers: "The dragon roars and flames erupt!"',
  `stat_changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"atk":0.30,"speed":0.20} — multiplier bonuses applied on transition' CHECK (json_valid(`stat_changes`)),
  `new_skill_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[5,12] — skill IDs unlocked in this phase' CHECK (json_valid(`new_skill_ids`)),
  `remove_skill_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[3] — skill IDs removed in this phase' CHECK (json_valid(`remove_skill_ids`)),
  `heal_pct` float NOT NULL DEFAULT 0 COMMENT '0.20 = heal 20% of maxHp on transition',
  `summon_npc_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[7,8] — NPC IDs to summon as adds on transition' CHECK (json_valid(`summon_npc_ids`)),
  `element_shift` varchar(32) DEFAULT NULL COMMENT 'boss changes element on phase shift',
  `terrain_change` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"type":"fire","radius":2} — change terrain around boss' CHECK (json_valid(`terrain_change`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_npc_phase` (`npc_id`,`phase_number`),
  KEY `idx_npc` (`npc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_boss_phases`
--

LOCK TABLES `game_boss_phases` WRITE;
/*!40000 ALTER TABLE `game_boss_phases` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_boss_phases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_class_ability_bonuses`
--

DROP TABLE IF EXISTS `game_class_ability_bonuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_class_ability_bonuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(10) unsigned NOT NULL,
  `ability_id` int(10) unsigned NOT NULL,
  `bonus` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_class_ability` (`class_id`,`ability_id`),
  KEY `idx_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_class_ability_bonuses`
--

LOCK TABLES `game_class_ability_bonuses` WRITE;
/*!40000 ALTER TABLE `game_class_ability_bonuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_class_ability_bonuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_class_mastery`
--

DROP TABLE IF EXISTS `game_class_mastery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_class_mastery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(10) unsigned NOT NULL,
  `mastery_xp_required` bigint(20) unsigned NOT NULL DEFAULT 1000000,
  `title` varchar(64) NOT NULL DEFAULT 'Master',
  `title_color` varchar(7) DEFAULT '#ffd700',
  `glow_effect` varchar(32) DEFAULT 'gold_shimmer',
  `bonus_stats_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"atk":10,"speed":5}' CHECK (json_valid(`bonus_stats_json`)),
  `mastery_skills_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[skill_id, skill_id]' CHECK (json_valid(`mastery_skills_json`)),
  PRIMARY KEY (`id`),
  KEY `idx_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_class_mastery`
--

LOCK TABLES `game_class_mastery` WRITE;
/*!40000 ALTER TABLE `game_class_mastery` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_class_mastery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_class_skills`
--

DROP TABLE IF EXISTS `game_class_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_class_skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(10) unsigned NOT NULL,
  `skill_id` int(10) unsigned NOT NULL,
  `learn_level` int(11) NOT NULL DEFAULT 1,
  `mp_cost` int(11) DEFAULT NULL,
  `alt_name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_class_skill` (`class_id`,`skill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_class_skills`
--

LOCK TABLES `game_class_skills` WRITE;
/*!40000 ALTER TABLE `game_class_skills` DISABLE KEYS */;
INSERT INTO `game_class_skills` VALUES
(1,1,1,1,8,NULL),
(2,1,2,5,12,NULL),
(3,1,3,10,15,NULL),
(4,2,4,1,10,NULL),
(5,2,7,3,8,NULL),
(6,2,5,6,12,NULL),
(7,2,6,12,18,NULL),
(8,3,8,1,6,NULL),
(9,3,9,4,8,NULL),
(10,3,10,8,10,NULL),
(11,4,11,1,10,NULL),
(12,4,13,4,12,NULL),
(13,4,12,6,14,NULL),
(14,4,14,10,16,NULL);
/*!40000 ALTER TABLE `game_class_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_classes`
--

DROP TABLE IF EXISTS `game_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_classes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '⚔️',
  `base_hp` int(11) NOT NULL DEFAULT 100,
  `base_mp` int(11) NOT NULL DEFAULT 50,
  `base_atk` int(11) NOT NULL DEFAULT 10,
  `base_def` int(11) NOT NULL DEFAULT 5,
  `base_mo` int(11) NOT NULL DEFAULT 5,
  `base_md` int(11) NOT NULL DEFAULT 5,
  `base_speed` int(11) NOT NULL DEFAULT 10,
  `base_luck` int(11) NOT NULL DEFAULT 5,
  `battle_cmds` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`battle_cmds`)),
  `hidden` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `base_ap` int(11) NOT NULL DEFAULT 6,
  `portrait_asset_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_classes`
--

LOCK TABLES `game_classes` WRITE;
/*!40000 ALTER TABLE `game_classes` DISABLE KEYS */;
INSERT INTO `game_classes` VALUES
(1,'Warrior','Masters of physical combat. High HP and ATK, low magic.','⚔️',150,30,18,12,5,8,12,5,NULL,0,0,6,NULL),
(2,'Mage','Wielders of arcane power. High MP and MO, fragile body.','🔮',80,120,6,5,20,15,9,8,NULL,0,0,6,NULL),
(3,'Rogue','Swift and deadly. High speed and luck, moderate stats.','🗡️',100,60,14,8,8,10,18,15,NULL,0,0,6,NULL),
(4,'Cleric','Holy warriors who heal and defend. Balanced magic/phys.','✝️',120,90,10,10,14,14,10,10,NULL,0,0,6,NULL);
/*!40000 ALTER TABLE `game_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_combo_arts`
--

DROP TABLE IF EXISTS `game_combo_arts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_combo_arts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `input_sequence` varchar(64) NOT NULL COMMENT 'e.g. H,H,L or L,R,L,R or U,D,U',
  `ap_cost` int(11) NOT NULL DEFAULT 3 COMMENT 'how many AP inputs this uses',
  `damage_formula` varchar(255) NOT NULL DEFAULT 'ATK*3',
  `element` varchar(32) DEFAULT NULL,
  `status_apply` varchar(32) DEFAULT NULL,
  `battle_text` varchar(255) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL COMMENT 'NULL = any class can discover',
  `level_required` int(11) NOT NULL DEFAULT 1,
  `is_hidden` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'must be discovered by inputting the sequence',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sequence` (`input_sequence`,`class_id`),
  KEY `idx_class` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_combo_arts`
--

LOCK TABLES `game_combo_arts` WRITE;
/*!40000 ALTER TABLE `game_combo_arts` DISABLE KEYS */;
INSERT INTO `game_combo_arts` VALUES
(1,'Cross Cut','⚔️','Basic two-strike combo.','H,H',2,'ATK*2',NULL,NULL,'{name} delivers a swift Cross Cut!',NULL,1,1,1),
(2,'Somersault','????','Rising kick into overhead slash.','H,H,L',3,'ATK*3',NULL,NULL,'{name} flips and strikes with Somersault!',NULL,1,1,1),
(3,'Tornado Dance','????️','Rapid alternating strikes.','L,R,L,R',4,'ATK*3.5',NULL,NULL,'{name} unleashes the Tornado Dance!',NULL,1,1,1),
(4,'Rising Upper','????','Low strikes into devastating uppercut.','L,L,H',3,'ATK*2.5',NULL,NULL,'{name} launches a Rising Upper!',NULL,1,1,1),
(5,'Hyper Elbow','????','Fake high, go low, strike high.','H,L,H',3,'ATK*2.8',NULL,NULL,'{name} charges with Hyper Elbow!',NULL,1,1,1),
(6,'Power Punch','????','Triple high strike, maximum force.','H,H,H',3,'ATK*3.2',NULL,NULL,'{name} unleashes a Power Punch!',NULL,1,1,1),
(7,'Sweep Combo','????','Low strikes to topple the opponent.','L,L,L',3,'ATK*2.5',NULL,NULL,'{name} executes a Sweep Combo!',NULL,1,1,1),
(8,'Hurricane Kick','????','Devastating 5-hit combo. Rare discovery.','L,R,L,R,H',5,'ATK*4.5',NULL,NULL,'{name} roars with Hurricane Kick!',NULL,1,1,1),
(9,'Mystic Arte','✨','Ultimate combo. Mixes physical and magical.','H,L,H,L,H',5,'ATK*5+MO*2',NULL,NULL,'{name} channels the Mystic Arte!',NULL,1,1,1),
(10,'Thunder Fist','⚡','Relentless high barrage.','H,H,H,H',4,'ATK*4',NULL,NULL,'{name} rains Thunder Fists!',NULL,1,1,1);
/*!40000 ALTER TABLE `game_combo_arts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_combo_chains`
--

DROP TABLE IF EXISTS `game_combo_chains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_combo_chains` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `sequence_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '[cmd_id_1, cmd_id_2, cmd_id_3]' CHECK (json_valid(`sequence_json`)),
  `bonus_damage_mult` decimal(3,1) NOT NULL DEFAULT 2.0,
  `bonus_effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"stun":true,"duration":1}' CHECK (json_valid(`bonus_effect_json`)),
  `class_id` int(10) unsigned DEFAULT NULL COMMENT 'null=any class',
  `style_id` int(10) unsigned DEFAULT NULL COMMENT 'null=any style',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_combo_chains`
--

LOCK TABLES `game_combo_chains` WRITE;
/*!40000 ALTER TABLE `game_combo_chains` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_combo_chains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_config_profiles`
--

DROP TABLE IF EXISTS `game_config_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_config_profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `settings_json` mediumtext NOT NULL,
  `modules_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`modules_json`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_config_profiles`
--

LOCK TABLES `game_config_profiles` WRITE;
/*!40000 ALTER TABLE `game_config_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_config_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_config_snapshots`
--

DROP TABLE IF EXISTS `game_config_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_config_snapshots` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `snapshot_json` mediumtext NOT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_config_snapshots`
--

LOCK TABLES `game_config_snapshots` WRITE;
/*!40000 ALTER TABLE `game_config_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_config_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_craft_recipes`
--

DROP TABLE IF EXISTS `game_craft_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_craft_recipes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `category` varchar(32) NOT NULL DEFAULT 'MISC',
  `result_item_id` int(10) unsigned NOT NULL,
  `result_qty` int(11) NOT NULL DEFAULT 1,
  `level_req` int(11) NOT NULL DEFAULT 1,
  `skill_req` varchar(64) DEFAULT NULL,
  `ingredients_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`ingredients_json`)),
  `unlock_mode` enum('ALWAYS','LEARNED') NOT NULL DEFAULT 'ALWAYS',
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '?',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `hidden` tinyint(1) NOT NULL DEFAULT 0,
  `discovery_method` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_recipe_category` (`category`),
  KEY `idx_recipe_result` (`result_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_craft_recipes`
--

LOCK TABLES `game_craft_recipes` WRITE;
/*!40000 ALTER TABLE `game_craft_recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_craft_recipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_death_penalties`
--

DROP TABLE IF EXISTS `game_death_penalties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_death_penalties` (
  `death_count` int(11) NOT NULL,
  `base_stat_loss_pct` float NOT NULL DEFAULT 0.05,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`death_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_death_penalties`
--

LOCK TABLES `game_death_penalties` WRITE;
/*!40000 ALTER TABLE `game_death_penalties` DISABLE KEYS */;
INSERT INTO `game_death_penalties` VALUES
(1,0.05,NULL),
(2,0.1,NULL),
(3,0.2,NULL),
(4,0.4,NULL),
(5,0.4,NULL);
/*!40000 ALTER TABLE `game_death_penalties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_elemental_affinities`
--

DROP TABLE IF EXISTS `game_elemental_affinities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_elemental_affinities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `element` varchar(32) NOT NULL,
  `tier` int(11) NOT NULL DEFAULT 1,
  `casts_required` int(10) unsigned NOT NULL COMMENT 'total casts to reach this tier',
  `title` varchar(64) NOT NULL COMMENT 'Fire Touched, Fire Adept, Fire Master',
  `passive_bonus_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '{"fire_damage_pct":10,"water_damage_pct":-5}' CHECK (json_valid(`passive_bonus_json`)),
  `visual_effect` varchar(32) DEFAULT NULL COMMENT 'flame_aura, frost_glow',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_element_tier` (`element`,`tier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_elemental_affinities`
--

LOCK TABLES `game_elemental_affinities` WRITE;
/*!40000 ALTER TABLE `game_elemental_affinities` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_elemental_affinities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_elemental_reactions`
--

DROP TABLE IF EXISTS `game_elemental_reactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_elemental_reactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `element_a` varchar(32) NOT NULL,
  `element_b` varchar(32) NOT NULL,
  `reaction_name` varchar(64) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `damage_bonus` float NOT NULL DEFAULT 0.3,
  `aoe_radius` int(11) NOT NULL DEFAULT 0,
  `apply_status` varchar(32) DEFAULT NULL,
  `remove_elements` tinyint(1) NOT NULL DEFAULT 1,
  `battle_text` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_elements` (`element_a`,`element_b`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_elemental_reactions`
--

LOCK TABLES `game_elemental_reactions` WRITE;
/*!40000 ALTER TABLE `game_elemental_reactions` DISABLE KEYS */;
INSERT INTO `game_elemental_reactions` VALUES
(1,'water','lightning','Electro-Charged','⚡',NULL,0.4,1,'Stun',1,'Lightning arcs through the water!',1),
(2,'water','ice','Frozen','????',NULL,0.1,0,'Stun',1,'The target is Frozen solid!',1),
(3,'water','fire','Vaporize','????',NULL,0.5,0,NULL,1,'A massive Vaporize explosion!',1),
(4,'fire','ice','Melt','????',NULL,0.4,0,NULL,1,'The ice Melts under searing flame!',1),
(5,'fire','earth','Magma','????',NULL,0.25,1,'Burning',1,'The ground erupts into Magma!',1),
(6,'ice','lightning','Superconduct','❄️',NULL,0.2,0,'DEF Down',1,'The frozen shell shatters!',1),
(7,'dark','light','Annihilation','✨',NULL,0.6,1,NULL,1,'Dark and light Annihilate each other!',1);
/*!40000 ALTER TABLE `game_elemental_reactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_elements`
--

DROP TABLE IF EXISTS `game_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `color` varchar(16) DEFAULT '#ff6600',
  `strengths_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`strengths_json`)),
  `weaknesses_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`weaknesses_json`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_elements`
--

LOCK TABLES `game_elements` WRITE;
/*!40000 ALTER TABLE `game_elements` DISABLE KEYS */;
INSERT INTO `game_elements` VALUES
(1,'Fire','🔥','#ff4400','[\"Ice\",\"Wind\"]','[\"Water\",\"Earth\"]'),
(2,'Water','💧','#0088ff','[\"Fire\",\"Earth\"]','[\"Lightning\",\"Wind\"]'),
(3,'Earth','🌍','#884400','[\"Lightning\",\"Fire\"]','[\"Wind\",\"Water\"]'),
(4,'Wind','💨','#88cc88','[\"Water\",\"Earth\"]','[\"Ice\",\"Lightning\"]'),
(5,'Lightning','⚡','#ffcc00','[\"Water\",\"Wind\"]','[\"Earth\",\"Ice\"]'),
(6,'Ice','❄️','#88ccff','[\"Wind\",\"Water\"]','[\"Fire\",\"Lightning\"]'),
(7,'Light','✨','#ffffaa','[\"Dark\"]','[\"Dark\"]'),
(8,'Dark','🌑','#440044','[\"Light\"]','[\"Light\"]'),
(9,'None','⭕','#888888','[]','[]');
/*!40000 ALTER TABLE `game_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_enchantments`
--

DROP TABLE IF EXISTS `game_enchantments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_enchantments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '✨',
  `description` text DEFAULT NULL,
  `ogham_cost_id` int(10) unsigned DEFAULT NULL COMMENT 'ogham consumed as fuel',
  `effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '{"fire_damage":10,"speed":2}' CHECK (json_valid(`effect_json`)),
  `duration_battles` int(11) NOT NULL DEFAULT 50,
  `applicable_to` enum('weapon','armor','accessory','any') NOT NULL DEFAULT 'any',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_enchantments`
--

LOCK TABLES `game_enchantments` WRITE;
/*!40000 ALTER TABLE `game_enchantments` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_enchantments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_enemy_scaling`
--

DROP TABLE IF EXISTS `game_enemy_scaling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_enemy_scaling` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `npc_id` int(10) unsigned NOT NULL,
  `scale_mode` enum('player_level','party_size','both') NOT NULL DEFAULT 'player_level',
  `stat_scale_pct` decimal(5,2) NOT NULL DEFAULT 10.00 COMMENT 'percent per level above base',
  `hp_scale_pct` decimal(5,2) NOT NULL DEFAULT 15.00,
  `max_level_cap` int(11) DEFAULT NULL,
  `min_level` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_npc` (`npc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_enemy_scaling`
--

LOCK TABLES `game_enemy_scaling` WRITE;
/*!40000 ALTER TABLE `game_enemy_scaling` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_enemy_scaling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_equip_slots`
--

DROP TABLE IF EXISTS `game_equip_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_equip_slots` (
  `slot_key` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `icon` varchar(8) DEFAULT '?',
  `allows_types` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`slot_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_equip_slots`
--

LOCK TABLES `game_equip_slots` WRITE;
/*!40000 ALTER TABLE `game_equip_slots` DISABLE KEYS */;
INSERT INTO `game_equip_slots` VALUES
('boots','Boots',6,'👢','BOOTS'),
('chest','Chest',4,'🥋','ARMOR'),
('helmet','Helmet',3,'⛑️','HELMET'),
('legs','Legs',5,'👖','ARMOR'),
('necklace','Necklace',8,'📿','ACCESSORY'),
('offhand','Off-Hand',2,'🛡️','ARMOR,WEAPON'),
('ring','Ring',7,'💍','ACCESSORY'),
('weapon','Weapon',1,'⚔️','WEAPON');
/*!40000 ALTER TABLE `game_equip_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_event_log`
--

DROP TABLE IF EXISTS `game_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_event_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_type` varchar(32) NOT NULL,
  `actor_id` int(10) unsigned DEFAULT NULL,
  `actor_name` varchar(128) DEFAULT NULL,
  `target_id` int(10) unsigned DEFAULT NULL,
  `target_name` varchar(128) DEFAULT NULL,
  `detail_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`detail_json`)),
  `map_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_elog_type` (`event_type`),
  KEY `idx_elog_actor` (`actor_id`),
  KEY `idx_elog_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_event_log`
--

LOCK TABLES `game_event_log` WRITE;
/*!40000 ALTER TABLE `game_event_log` DISABLE KEYS */;
INSERT INTO `game_event_log` VALUES
(1,'gm_role_change',1,'GM',5,'AllenSam','{\"role\":\"ADMIN\"}',NULL,'2026-03-18 22:04:49'),
(2,'gm_delete_char',1,'GM',2,'John','{\"userId\":1}',NULL,'2026-03-19 02:00:58'),
(3,'gm_delete_char',1,'GM',3,'Joel','{\"userId\":1}',NULL,'2026-03-19 02:01:02');
/*!40000 ALTER TABLE `game_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_feats`
--

DROP TABLE IF EXISTS `game_feats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_feats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '?',
  `type` varchar(32) DEFAULT 'passive',
  `effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`effect_json`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_feats`
--

LOCK TABLES `game_feats` WRITE;
/*!40000 ALTER TABLE `game_feats` DISABLE KEYS */;
INSERT INTO `game_feats` VALUES
(1,'Iron Skin','Your skin is tougher than it looks. Start with more DEF.','🎯','passive','{\"bonus_def\": 3}'),
(2,'Quick Feet','Born with unnatural speed. +3 SPEED.','🎯','passive','{\"bonus_speed\": 3}'),
(3,'Lucky Strike','Fortune favours you. +5 LUCK.','🎯','passive','{\"bonus_luck\": 5}'),
(4,'Arcane Gift','Natural magic affinity. +10 MP.','🎯','passive','{\"bonus_mp\": 10}');
/*!40000 ALTER TABLE `game_feats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_fighting_style_ranks`
--

DROP TABLE IF EXISTS `game_fighting_style_ranks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_fighting_style_ranks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `style_id` int(11) NOT NULL,
  `rank_num` int(11) NOT NULL,
  `label` varchar(64) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `wins_required` int(11) NOT NULL DEFAULT 5,
  `stat_bonuses` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`stat_bonuses`)),
  `unlocked_move_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`unlocked_move_ids`)),
  `passive_effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`passive_effects`)),
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_style_rank` (`style_id`,`rank_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_fighting_style_ranks`
--

LOCK TABLES `game_fighting_style_ranks` WRITE;
/*!40000 ALTER TABLE `game_fighting_style_ranks` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_fighting_style_ranks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_fighting_styles`
--

DROP TABLE IF EXISTS `game_fighting_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_fighting_styles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `label` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `lore_text` text DEFAULT NULL,
  `style_type` enum('offensive','defensive','balanced','support','glass_cannon') NOT NULL DEFAULT 'balanced',
  `max_rank` int(11) NOT NULL DEFAULT 10,
  `passive_effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`passive_effects`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_fighting_styles`
--

LOCK TABLES `game_fighting_styles` WRITE;
/*!40000 ALTER TABLE `game_fighting_styles` DISABLE KEYS */;
INSERT INTO `game_fighting_styles` VALUES
(1,'iron_fist','Iron Fist','????',NULL,NULL,'offensive',10,NULL,'2026-03-18 09:45:21'),
(2,'shadow_step','Shadow Step','????',NULL,NULL,'defensive',10,NULL,'2026-03-18 09:45:21'),
(3,'stone_wall','Stone Wall','????️',NULL,NULL,'defensive',10,NULL,'2026-03-18 09:45:21'),
(4,'druids_way','Druid\'s Way','????',NULL,NULL,'support',10,NULL,'2026-03-18 09:45:21'),
(5,'berserker_rage','Berserker Rage','????',NULL,NULL,'glass_cannon',10,NULL,'2026-03-18 09:45:21');
/*!40000 ALTER TABLE `game_fighting_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_finishing_moves`
--

DROP TABLE IF EXISTS `game_finishing_moves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_finishing_moves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `style_id` int(10) unsigned DEFAULT NULL,
  `hp_threshold_pct` int(11) NOT NULL DEFAULT 20 COMMENT 'enemy HP must be below this %',
  `damage_formula` varchar(128) DEFAULT 'ATK*5',
  `xp_bonus_pct` int(11) NOT NULL DEFAULT 50,
  `drop_bonus_pct` int(11) NOT NULL DEFAULT 25,
  `battle_text` varchar(255) DEFAULT NULL,
  `level_required` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_finishing_moves`
--

LOCK TABLES `game_finishing_moves` WRITE;
/*!40000 ALTER TABLE `game_finishing_moves` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_finishing_moves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_flavor_keywords`
--

DROP TABLE IF EXISTS `game_flavor_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_flavor_keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(64) NOT NULL,
  `bonus_pct` float NOT NULL DEFAULT 0.02 COMMENT '0.02 = +2% per keyword match',
  `category` varchar(32) NOT NULL DEFAULT 'general' COMMENT 'terrain, weapon, element, general',
  `terrain_match` varchar(32) DEFAULT NULL COMMENT 'if set, keyword only gives bonus on this terrain type',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_keyword` (`keyword`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_flavor_keywords`
--

LOCK TABLES `game_flavor_keywords` WRITE;
/*!40000 ALTER TABLE `game_flavor_keywords` DISABLE KEYS */;
INSERT INTO `game_flavor_keywords` VALUES
(1,'wall',0.02,'terrain','cover',1),
(2,'tree',0.02,'terrain','forest',1),
(3,'trees',0.02,'terrain','forest',1),
(4,'flames',0.02,'terrain','fire',1),
(5,'fire',0.02,'terrain','fire',1),
(6,'water',0.02,'terrain','water',1),
(7,'high ground',0.02,'terrain','high_ground',1),
(8,'above',0.02,'terrain','high_ground',1),
(9,'flank',0.02,'general',NULL,1),
(10,'behind',0.02,'general',NULL,1),
(11,'overhead',0.02,'general',NULL,1),
(12,'charge',0.02,'general',NULL,1),
(13,'leap',0.02,'general',NULL,1),
(14,'spin',0.02,'general',NULL,1),
(15,'feint',0.02,'general',NULL,1),
(16,'roar',0.01,'taunt',NULL,1),
(17,'scream',0.01,'taunt',NULL,1);
/*!40000 ALTER TABLE `game_flavor_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_flavor_texts`
--

DROP TABLE IF EXISTS `game_flavor_texts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_flavor_texts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `skill_id` int(11) DEFAULT NULL COMMENT 'NULL = works for any skill/attack',
  `command_id` int(11) DEFAULT NULL COMMENT 'NULL = works for any command',
  `text` text NOT NULL,
  `bonus_pct` float NOT NULL DEFAULT 0.05 COMMENT '0.05 = 5% damage bonus',
  `category` enum('attack','defense','heal','movement','taunt') NOT NULL DEFAULT 'attack',
  `min_length` int(11) NOT NULL DEFAULT 0 COMMENT 'minimum char length to qualify (0 = this template only)',
  `is_template` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = admin-created, 0 = player submission',
  `created_by_char_id` int(11) DEFAULT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'player submissions need approval',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_skill` (`skill_id`),
  KEY `idx_cmd` (`command_id`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_flavor_texts`
--

LOCK TABLES `game_flavor_texts` WRITE;
/*!40000 ALTER TABLE `game_flavor_texts` DISABLE KEYS */;
INSERT INTO `game_flavor_texts` VALUES
(1,NULL,1,'lunges forward with a powerful overhead strike',0.07,'attack',0,1,NULL,1,1,'2026-03-18 09:32:21'),
(2,NULL,1,'feints left then delivers a crushing blow from the right',0.08,'attack',0,1,NULL,1,1,'2026-03-18 09:32:21'),
(3,NULL,1,'drops low and sweeps upward in a vicious arc',0.06,'attack',0,1,NULL,1,1,'2026-03-18 09:32:21'),
(4,NULL,1,'channels their rage into a devastating two-handed swing',0.08,'attack',0,1,NULL,1,1,'2026-03-18 09:32:21'),
(5,NULL,1,'dashes forward with blinding speed and strikes',0.07,'attack',0,1,NULL,1,1,'2026-03-18 09:32:21'),
(6,NULL,NULL,'locks eyes with the enemy before unleashing a precise strike',0.06,'attack',0,1,NULL,1,1,'2026-03-18 09:32:21'),
(7,NULL,NULL,'lets out a battle cry and brings their weapon down with full force',0.07,'attack',0,1,NULL,1,1,'2026-03-18 09:32:21'),
(8,NULL,NULL,'uses the terrain to their advantage, striking from an unexpected angle',0.09,'attack',0,1,NULL,1,1,'2026-03-18 09:32:21');
/*!40000 ALTER TABLE `game_flavor_texts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_fusions`
--

DROP TABLE IF EXISTS `game_fusions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_fusions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `fusion_type` enum('dance','item','potara','technique') NOT NULL DEFAULT 'dance',
  `required_item_id` int(10) unsigned DEFAULT NULL,
  `stat_formula` enum('add','average','multiply') NOT NULL DEFAULT 'add' COMMENT 'how to combine stats',
  `stat_multiplier` decimal(3,1) NOT NULL DEFAULT 1.5,
  `duration_turns` int(11) NOT NULL DEFAULT 5,
  `cooldown_battles` int(11) NOT NULL DEFAULT 3,
  `level_required` int(11) NOT NULL DEFAULT 1,
  `race_required_id` int(10) unsigned DEFAULT NULL,
  `fused_appearance_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fused_appearance_json`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_fusions`
--

LOCK TABLES `game_fusions` WRITE;
/*!40000 ALTER TABLE `game_fusions` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_fusions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_item_curses`
--

DROP TABLE IF EXISTS `game_item_curses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_item_curses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `bonus_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '{"atk":20,"speed":10}' CHECK (json_valid(`bonus_json`)),
  `penalty_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '{"max_hp":-50,"luck":-10}' CHECK (json_valid(`penalty_json`)),
  `removal_type` enum('purify_item','purify_quest','purify_gold','unremovable') NOT NULL DEFAULT 'purify_item',
  `removal_item_id` int(10) unsigned DEFAULT NULL,
  `removal_quest_id` int(10) unsigned DEFAULT NULL,
  `removal_gold_cost` int(10) unsigned DEFAULT 0,
  `lore_text` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_item_curses`
--

LOCK TABLES `game_item_curses` WRITE;
/*!40000 ALTER TABLE `game_item_curses` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_item_curses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_item_sets`
--

DROP TABLE IF EXISTS `game_item_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_item_sets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '?️',
  `bonuses_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"2":{"def":5},"3":{"def":10,"max_hp":50},"4":{"def":20,"max_hp":100}}' CHECK (json_valid(`bonuses_json`)),
  `item_ids_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[1,2,3,4]' CHECK (json_valid(`item_ids_json`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_item_sets`
--

LOCK TABLES `game_item_sets` WRITE;
/*!40000 ALTER TABLE `game_item_sets` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_item_sets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_items`
--

DROP TABLE IF EXISTS `game_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('WEAPON','ARMOR','HELMET','BOOTS','ACCESSORY','CONSUMABLE','QUEST','MISC') NOT NULL DEFAULT 'MISC',
  `icon` varchar(8) DEFAULT '?',
  `slot` varchar(32) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT 0,
  `bonus_hp` int(11) NOT NULL DEFAULT 0,
  `bonus_mp` int(11) NOT NULL DEFAULT 0,
  `bonus_atk` int(11) NOT NULL DEFAULT 0,
  `bonus_def` int(11) NOT NULL DEFAULT 0,
  `bonus_mo` int(11) NOT NULL DEFAULT 0,
  `bonus_md` int(11) NOT NULL DEFAULT 0,
  `bonus_speed` int(11) NOT NULL DEFAULT 0,
  `bonus_luck` int(11) NOT NULL DEFAULT 0,
  `level_req` int(11) NOT NULL DEFAULT 1,
  `elements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`elements`)),
  `set_status` varchar(64) DEFAULT NULL,
  `stats_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`stats_json`)),
  `alignment_required` int(11) DEFAULT NULL COMMENT 'min alignment to equip (positive = good required, negative = evil required)',
  `weapon_type` varchar(32) DEFAULT NULL,
  `icon_asset_id` int(11) DEFAULT NULL,
  `curse_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_items`
--

LOCK TABLES `game_items` WRITE;
/*!40000 ALTER TABLE `game_items` DISABLE KEYS */;
INSERT INTO `game_items` VALUES
(1,'Iron Sword','A reliable iron sword. Standard issue.','WEAPON','⚔️','weapon',50,0,0,8,0,0,0,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(2,'Leather Armor','Basic leather armor. Better than nothing.','ARMOR','🥋','chest',40,0,0,0,5,0,0,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(3,'Health Potion','Restores 50 HP when used.','CONSUMABLE','🧪',NULL,30,0,0,0,0,0,0,0,0,1,NULL,NULL,'{\"heal_hp\": 50}',NULL,NULL,NULL,NULL),
(4,'Mana Potion','Restores 30 MP when used.','CONSUMABLE','💙',NULL,25,0,0,0,0,0,0,0,0,1,NULL,NULL,'{\"restore_mp\": 30}',NULL,NULL,NULL,NULL),
(5,'Bronze Shield','A round bronze shield. Absorbs some damage.','ARMOR','🛡️','offhand',60,0,0,0,8,0,0,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(6,'Wizard Staff','A gnarled staff pulsing with arcane energy.','WEAPON','🪄','weapon',80,0,20,3,0,0,0,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(7,'Iron Helmet','Protects your head. Slightly uncomfortable.','HELMET','⛑️','helmet',35,10,0,0,4,0,0,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(8,'Ring of Vitality','A warm ring. Glows faintly. +20 HP.','ACCESSORY','💍','ring',120,20,0,0,0,0,0,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(9,'Breath of Danu','A shimmering vial containing the essence of the mother goddess. Revives a fallen character at half health.','CONSUMABLE','🌬️',NULL,500,0,0,0,0,0,0,0,0,1,NULL,NULL,'{\"revival\": true, \"revival_pct\": 50}',NULL,NULL,NULL,NULL),
(10,'Tear of Brigid','A crystallized tear from the goddess of healing herself. Revives a fallen character at full health with a temporary blessing.','CONSUMABLE','💧',NULL,2000,0,0,0,0,0,0,0,0,1,NULL,NULL,'{\"revival\": true, \"revival_pct\": 100}',NULL,NULL,NULL,NULL),
(11,'Stone of Rebirth','A rare crystalline stone that allows you to reallocate your ability scores. Consumed on use.','CONSUMABLE','💎',NULL,5000,0,0,0,0,0,0,0,0,1,NULL,NULL,'{\"respec\": true}',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `game_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_ki_moves`
--

DROP TABLE IF EXISTS `game_ki_moves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_ki_moves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `style_id` int(10) unsigned DEFAULT NULL,
  `move_type` enum('blast','beam','aura','rush','special') NOT NULL DEFAULT 'blast',
  `hp_cost_pct` decimal(5,2) NOT NULL DEFAULT 5.00 COMMENT 'percent of max HP to use',
  `hp_cost_flat` int(11) NOT NULL DEFAULT 0,
  `charge_turns` int(11) NOT NULL DEFAULT 0 COMMENT '0=instant, 1-3=charge time',
  `charge_damage_mult` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"1":1.0,"2":1.5,"3":2.5}' CHECK (json_valid(`charge_damage_mult`)),
  `interruptible` tinyint(1) NOT NULL DEFAULT 1,
  `damage_formula` varchar(128) DEFAULT 'ATK*2',
  `range_type` enum('melee','ranged','aoe') NOT NULL DEFAULT 'ranged',
  `status_effect_id` int(10) unsigned DEFAULT NULL,
  `level_required` int(11) NOT NULL DEFAULT 1,
  `cooldown_turns` int(11) NOT NULL DEFAULT 0,
  `battle_text` varchar(255) DEFAULT NULL COMMENT '{name} fires a massive ki blast!',
  `brunt_mode` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=take full damage but keep charging',
  `brunt_damage_mult` decimal(3,1) NOT NULL DEFAULT 1.0 COMMENT 'damage multiplier when taking hits while charging (1.0=normal, 1.5=extra vulnerable)',
  `magic_school_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_ki_moves`
--

LOCK TABLES `game_ki_moves` WRITE;
/*!40000 ALTER TABLE `game_ki_moves` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_ki_moves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_limb_zones`
--

DROP TABLE IF EXISTS `game_limb_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_limb_zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body_type_id` int(11) NOT NULL,
  `zone_key` varchar(32) NOT NULL,
  `label` varchar(64) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `hp_pct` float NOT NULL DEFAULT 0.2,
  `called_shot_penalty` float NOT NULL DEFAULT 0,
  `bleed_through` float NOT NULL DEFAULT 0.6,
  `wound_effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`wound_effects`)),
  `disable_effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`disable_effects`)),
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_body_zone` (`body_type_id`,`zone_key`),
  CONSTRAINT `game_limb_zones_ibfk_1` FOREIGN KEY (`body_type_id`) REFERENCES `game_body_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_limb_zones`
--

LOCK TABLES `game_limb_zones` WRITE;
/*!40000 ALTER TABLE `game_limb_zones` DISABLE KEYS */;
INSERT INTO `game_limb_zones` VALUES
(1,1,'head','Head','🗣️',0.25,0.2,0.7,'{\"light\":{\"accuracy\":-0.10},\"heavy\":{\"accuracy\":-0.25,\"stun_chance_on_hit\":0.15}}','{\"knockout\":true}',1),
(2,1,'torso','Torso','🫁',0.4,0,1,'{\"light\":{\"def\":-0.10},\"heavy\":{\"def\":-0.20,\"maxHp\":-0.10}}','{\"def\":-0.40,\"maxHp\":-0.20}',2),
(3,1,'left_arm','Left Arm','💪',0.15,0.1,0.6,'{\"light\":{\"atk\":-0.15},\"heavy\":{\"atk\":-0.30,\"cant_dual_wield\":true}}','{\"atk\":-0.50,\"cant_dual_wield\":true,\"cant_two_hand\":true}',3),
(4,1,'right_arm','Right Arm','🤚',0.15,0.1,0.6,'{\"light\":{\"mo\":-0.15},\"heavy\":{\"mo\":-0.30,\"cant_use_items\":true}}','{\"mo\":-0.50,\"cant_use_items\":true}',4),
(5,1,'legs','Legs','🦵',0.2,0.1,0.6,'{\"light\":{\"speed\":-0.15,\"move_range\":-1},\"heavy\":{\"speed\":-0.30,\"move_range\":-2,\"cant_flee\":true}}','{\"prone\":true,\"speed\":-0.50,\"move_range\":-99,\"cant_flee\":true,\"cant_move\":true}',5),
(6,4,'core','Core','🫧',1,0,1,NULL,NULL,1);
/*!40000 ALTER TABLE `game_limb_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_limit_breaks`
--

DROP TABLE IF EXISTS `game_limit_breaks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_limit_breaks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `break_level` int(11) NOT NULL DEFAULT 1,
  `char_level_req` int(11) NOT NULL DEFAULT 1,
  `target_type` varchar(32) NOT NULL DEFAULT 'ENEMY',
  `icon` varchar(8) DEFAULT '?',
  `effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`effects`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_limit_breaks`
--

LOCK TABLES `game_limit_breaks` WRITE;
/*!40000 ALTER TABLE `game_limit_breaks` DISABLE KEYS */;
INSERT INTO `game_limit_breaks` VALUES
(1,'Blade Rush','A desperate flurry of strikes dealing massive physical damage.',1,1,1,'ENEMY','⚔️','{\"damage\":{\"formula\":\"ATK*5-DEF\",\"randomize\":0.15},\"log\":\"{name} unleashes Blade Rush!\"}'),
(2,'Earthquake','Slams the ground with incredible force, ignoring all defense.',1,2,15,'ENEMY','🌍','{\"damage\":{\"formula\":\"ATK*7\",\"randomize\":0.1},\"log\":\"{name} strikes the earth with Earthquake!\"}'),
(3,'Arcane Explosion','A supernova of raw magic that obliterates defenses.',2,1,1,'ENEMY','🔮','{\"damage\":{\"formula\":\"MO*6-MD*0.5\",\"randomize\":0.1},\"elements\":[\"arcane\"],\"log\":\"{name} detonates an Arcane Explosion!\"}'),
(4,'Meltdown','Solar flare magic that Burns the target for 4 turns.',2,2,15,'ENEMY','☀️','{\"damage\":{\"formula\":\"MO*5\",\"randomize\":0.1},\"elements\":[\"fire\"],\"set_status\":{\"target\":\"enemy\",\"chance\":100,\"statuses\":{\"Burn\":4}},\"log\":\"{name} triggers a Meltdown!\"}'),
(5,'Shadow Storm','A storm of shadow strikes too fast to defend against.',3,1,1,'ENEMY','🌑','{\"damage\":{\"formula\":\"ATK*4+LUCK*3\",\"randomize\":0.2},\"log\":\"{name} unleashes Shadow Storm!\"}'),
(6,'Death Mark','Marks the enemy — poisons and blinds them.',3,2,15,'ENEMY','💀','{\"damage\":{\"formula\":\"ATK*3+LUCK*2\",\"randomize\":0.15},\"set_status\":{\"target\":\"enemy\",\"chance\":100,\"statuses\":{\"Poison\":5,\"Blind\":3}},\"log\":\"{name} places a Death Mark!\"}'),
(7,'Divine Intervention','A burst of holy light heals you and smites the enemy.',4,1,1,'ENEMY','✝️','{\"damage\":{\"formula\":\"(ATK+MO)*3\",\"randomize\":0.1},\"elements\":[\"holy\"],\"heal\":{\"formula\":\"MAXHP*0.3\"},\"log\":\"{name} calls for Divine Intervention!\"}'),
(8,'Apocalypse','Rains divine judgment — massive holy damage.',4,2,15,'ENEMY','☁️','{\"damage\":{\"formula\":\"MO*6+ATK*2\",\"randomize\":0.08},\"elements\":[\"holy\"],\"log\":\"{name} calls down Apocalypse!\"}');
/*!40000 ALTER TABLE `game_limit_breaks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_link_attacks`
--

DROP TABLE IF EXISTS `game_link_attacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_link_attacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `initiator_class_id` int(11) DEFAULT NULL,
  `partner_class_id` int(11) DEFAULT NULL,
  `initiator_skill_id` int(11) DEFAULT NULL,
  `damage_formula` varchar(255) NOT NULL DEFAULT 'ATK*2',
  `element` varchar(32) DEFAULT NULL,
  `effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`effects`)),
  `battle_text` text DEFAULT NULL,
  `min_affinity` int(11) NOT NULL DEFAULT 0,
  `cooldown_turns` int(11) NOT NULL DEFAULT 3,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_link_attacks`
--

LOCK TABLES `game_link_attacks` WRITE;
/*!40000 ALTER TABLE `game_link_attacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_link_attacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_loot_tables`
--

DROP TABLE IF EXISTS `game_loot_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_loot_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `npc_id` int(10) unsigned DEFAULT NULL,
  `items_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[{"item_id":1,"weight":10,"min_qty":1,"max_qty":3}]' CHECK (json_valid(`items_json`)),
  `gold_min` int(10) unsigned DEFAULT 0,
  `gold_max` int(10) unsigned DEFAULT 0,
  `xp_min` int(10) unsigned DEFAULT 0,
  `xp_max` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_loot_tables`
--

LOCK TABLES `game_loot_tables` WRITE;
/*!40000 ALTER TABLE `game_loot_tables` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_loot_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_magic_resistances`
--

DROP TABLE IF EXISTS `game_magic_resistances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_magic_resistances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source_type` enum('race','class','item') NOT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `element` varchar(32) NOT NULL,
  `resistance_pct` int(11) NOT NULL DEFAULT 0 COMMENT 'positive=resist, negative=weakness',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_source_element` (`source_type`,`source_id`,`element`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_magic_resistances`
--

LOCK TABLES `game_magic_resistances` WRITE;
/*!40000 ALTER TABLE `game_magic_resistances` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_magic_resistances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_magic_schools`
--

DROP TABLE IF EXISTS `game_magic_schools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_magic_schools` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `cost_reduction_per_level` decimal(3,1) NOT NULL DEFAULT 1.0 COMMENT 'MP/HP cost reduction % per affinity level',
  `damage_bonus_per_level` decimal(3,1) NOT NULL DEFAULT 0.5 COMMENT 'damage bonus % per affinity level',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_magic_schools`
--

LOCK TABLES `game_magic_schools` WRITE;
/*!40000 ALTER TABLE `game_magic_schools` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_magic_schools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_map_hazards`
--

DROP TABLE IF EXISTS `game_map_hazards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_map_hazards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `map_id` int(10) unsigned NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  `hazard_type` varchar(32) NOT NULL COMMENT 'poison_swamp, lava, healing_spring, ice',
  `damage_per_step` int(11) DEFAULT 0,
  `heal_per_step` int(11) DEFAULT 0,
  `status_effect_id` int(10) unsigned DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_map` (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_map_hazards`
--

LOCK TABLES `game_map_hazards` WRITE;
/*!40000 ALTER TABLE `game_map_hazards` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_map_hazards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_map_spawns`
--

DROP TABLE IF EXISTS `game_map_spawns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_map_spawns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `map_id` int(10) unsigned NOT NULL,
  `npc_char_id` int(10) unsigned NOT NULL,
  `x` int(11) NOT NULL DEFAULT 5,
  `y` int(11) NOT NULL DEFAULT 5,
  `respawn_seconds` int(11) NOT NULL DEFAULT 30,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `world_flag_conditions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'e.g. [{"flag":"war_started","op":"==","value":"true"}] — all must pass' CHECK (json_valid(`world_flag_conditions`)),
  `name` varchar(128) DEFAULT NULL,
  `x_min` int(11) NOT NULL DEFAULT 0,
  `y_min` int(11) NOT NULL DEFAULT 0,
  `x_max` int(11) NOT NULL DEFAULT 19,
  `y_max` int(11) NOT NULL DEFAULT 19,
  `encounter_rate` int(11) NOT NULL DEFAULT 10,
  `encounter_table` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`encounter_table`)),
  `min_level` int(11) NOT NULL DEFAULT 1,
  `max_level` int(11) NOT NULL DEFAULT 99,
  `required_flag` varchar(128) DEFAULT NULL,
  `scaling_factor` float NOT NULL DEFAULT 0.3,
  PRIMARY KEY (`id`),
  KEY `idx_spawns_map` (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_map_spawns`
--

LOCK TABLES `game_map_spawns` WRITE;
/*!40000 ALTER TABLE `game_map_spawns` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_map_spawns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_maps`
--

DROP TABLE IF EXISTS `game_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_maps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 20,
  `height` int(11) NOT NULL DEFAULT 20,
  `tiles_json` mediumtext DEFAULT NULL,
  `collisions_json` mediumtext DEFAULT NULL,
  `objects_json` mediumtext DEFAULT NULL,
  `anims_json` mediumtext DEFAULT NULL,
  `tileset_url` varchar(500) DEFAULT NULL,
  `ambient_dark` float NOT NULL DEFAULT 0,
  `fast_travel_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `min_level` int(11) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `region_id` int(10) unsigned DEFAULT NULL,
  `bgm_asset_id` int(11) DEFAULT NULL,
  `ambient_asset_id` int(11) DEFAULT NULL,
  `terrain_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_maps`
--

LOCK TABLES `game_maps` WRITE;
/*!40000 ALTER TABLE `game_maps` DISABLE KEYS */;
INSERT INTO `game_maps` VALUES
(1,'Town Square','The central meeting place of the starting town. A fountain bubbles in the middle.',20,20,'[1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,2,2,2,0,0,2,2,2,0,0,0,0,0,1,1,0,0,0,0,0,2,3,2,0,0,2,3,2,0,0,0,0,0,1,1,0,0,0,0,0,2,2,2,0,0,2,2,2,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,2,2,2,0,0,2,2,2,0,0,0,0,0,1,1,0,0,0,0,0,2,3,2,0,0,2,3,2,0,0,0,0,0,1,1,0,0,0,0,0,2,2,2,0,0,2,2,2,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1]','[]','[{\"x\":17,\"y\":1,\"preset\":\"CRATE\",\"icon\":\"📦\",\"label\":\"Crate\",\"type\":\"PROP\",\"blocking\":true,\"light\":null},{\"x\":18,\"y\":1,\"preset\":\"CRATE\",\"icon\":\"📦\",\"label\":\"Crate\",\"type\":\"PROP\",\"blocking\":true,\"light\":null},{\"x\":18,\"y\":2,\"preset\":\"CRATE\",\"icon\":\"📦\",\"label\":\"Crate\",\"type\":\"PROP\",\"blocking\":true,\"light\":null},{\"x\":17,\"y\":2,\"preset\":\"CRATE\",\"icon\":\"📦\",\"label\":\"Crate\",\"type\":\"PROP\",\"blocking\":true,\"light\":null}]','[]',NULL,0,1,1,1,'2026-03-15 19:50:10',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `game_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_master_training_log`
--

DROP TABLE IF EXISTS `game_master_training_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_master_training_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `character_id` int(11) NOT NULL,
  `npc_id` int(11) NOT NULL,
  `training_type` enum('stat_train','learn_skill','learn_sig_tech','unlock_creation') NOT NULL,
  `result_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`result_json`)),
  `trained_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_master_training_log`
--

LOCK TABLES `game_master_training_log` WRITE;
/*!40000 ALTER TABLE `game_master_training_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_master_training_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_npc_patrols`
--

DROP TABLE IF EXISTS `game_npc_patrols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_npc_patrols` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `npc_id` int(10) unsigned NOT NULL,
  `map_id` int(10) unsigned NOT NULL,
  `waypoints` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '[{"x":5,"y":3,"pause":2},{"x":10,"y":3,"pause":0}]' CHECK (json_valid(`waypoints`)),
  `speed` decimal(3,1) NOT NULL DEFAULT 1.0 COMMENT 'tiles per second',
  `loop_type` enum('loop','pingpong','once') NOT NULL DEFAULT 'loop',
  `active_hours` varchar(32) DEFAULT NULL COMMENT '6-18 = daytime only',
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_npc` (`npc_id`),
  KEY `idx_map` (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_npc_patrols`
--

LOCK TABLES `game_npc_patrols` WRITE;
/*!40000 ALTER TABLE `game_npc_patrols` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_npc_patrols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_npc_schedules`
--

DROP TABLE IF EXISTS `game_npc_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_npc_schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `npc_id` int(10) unsigned NOT NULL,
  `start_hour` int(11) NOT NULL DEFAULT 0,
  `end_hour` int(11) NOT NULL DEFAULT 24,
  `map_id` int(10) unsigned NOT NULL,
  `x` int(11) NOT NULL DEFAULT 5,
  `y` int(11) NOT NULL DEFAULT 5,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_npc` (`npc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_npc_schedules`
--

LOCK TABLES `game_npc_schedules` WRITE;
/*!40000 ALTER TABLE `game_npc_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_npc_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_npcs`
--

DROP TABLE IF EXISTS `game_npcs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_npcs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `persona` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `map_id` int(10) unsigned DEFAULT NULL,
  `x` int(11) NOT NULL DEFAULT 5,
  `y` int(11) NOT NULL DEFAULT 5,
  `icon` varchar(8) DEFAULT '?',
  `script_key` varchar(128) DEFAULT NULL,
  `is_enemy` tinyint(1) NOT NULL DEFAULT 0,
  `char_id` int(10) unsigned DEFAULT NULL,
  `quest_offers_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`quest_offers_json`)),
  `move_type` enum('STATIONARY','WANDER','PATROL') NOT NULL DEFAULT 'WANDER',
  `wander_radius` int(11) NOT NULL DEFAULT 3,
  `schedule_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`schedule_json`)),
  `shop_id` int(10) unsigned DEFAULT NULL,
  `drop_table_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`drop_table_json`)),
  `mood` enum('happy','fearful','angry','grieving','excited') DEFAULT NULL,
  `is_dead` tinyint(1) NOT NULL DEFAULT 0,
  `predecessor_name` varchar(128) DEFAULT NULL,
  `death_cause` varchar(255) DEFAULT NULL,
  `patrol_path_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Array of {x,y,pause_ticks?} waypoints for PATROL move_type' CHECK (json_valid(`patrol_path_json`)),
  `is_recruitable` tinyint(1) NOT NULL DEFAULT 0,
  `recruit_rep_req` int(11) NOT NULL DEFAULT 50,
  `recruit_quest_req` int(10) unsigned DEFAULT NULL,
  `body_type_id` int(11) NOT NULL DEFAULT 1,
  `shield_points` int(11) NOT NULL DEFAULT 0,
  `shield_weaknesses` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`shield_weaknesses`)),
  `stagger_threshold` int(11) NOT NULL DEFAULT 0,
  `stagger_duration` int(11) NOT NULL DEFAULT 3,
  `stagger_damage_mult` float NOT NULL DEFAULT 1.5,
  `sprite_asset_id` int(11) DEFAULT NULL,
  `portrait_asset_id` int(11) DEFAULT NULL,
  `is_master` tinyint(1) NOT NULL DEFAULT 0,
  `teaches_style_id` int(10) unsigned DEFAULT NULL,
  `teaches_sig_tech_id` int(10) unsigned DEFAULT NULL,
  `unlocks_sig_tech_creation` tinyint(1) NOT NULL DEFAULT 0,
  `training_gain_pct` decimal(5,2) DEFAULT 1.00,
  `hidden` tinyint(1) NOT NULL DEFAULT 0,
  `hidden_until_flag` varchar(64) DEFAULT NULL COMMENT 'world flag that reveals this NPC',
  `hidden_until_quest_id` int(10) unsigned DEFAULT NULL,
  `hidden_until_rep` int(11) DEFAULT NULL COMMENT 'faction rep threshold',
  `hidden_faction_id` int(10) unsigned DEFAULT NULL,
  `teaches_skill_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[1,2,3] skill IDs this master teaches' CHECK (json_valid(`teaches_skill_ids`)),
  `teach_gold_cost` int(10) unsigned DEFAULT 0,
  `teach_level_req` int(11) DEFAULT NULL,
  `teach_quest_req_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_npcs`
--

LOCK TABLES `game_npcs` WRITE;
/*!40000 ALTER TABLE `game_npcs` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_npcs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_ogham_awakenings`
--

DROP TABLE IF EXISTS `game_ogham_awakenings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_ogham_awakenings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ogham_id` int(10) unsigned NOT NULL,
  `kill_milestone` int(10) unsigned NOT NULL COMMENT '50, 100, 500, etc',
  `dialogue_text` text DEFAULT NULL COMMENT 'the ogham speaks to the player',
  `buff_effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"atk":10,"duration_battles":5}' CHECK (json_valid(`buff_effect_json`)),
  `permanent_stat_bonus_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"atk":2}' CHECK (json_valid(`permanent_stat_bonus_json`)),
  `lore_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ogham` (`ogham_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_ogham_awakenings`
--

LOCK TABLES `game_ogham_awakenings` WRITE;
/*!40000 ALTER TABLE `game_ogham_awakenings` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_ogham_awakenings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_ogham_corruption_tiers`
--

DROP TABLE IF EXISTS `game_ogham_corruption_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_ogham_corruption_tiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `threshold` int(11) NOT NULL COMMENT 'corruption points to reach this tier',
  `bonus_stat_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"atk":5}' CHECK (json_valid(`bonus_stat_json`)),
  `curse_effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"max_hp_reduction":10}' CHECK (json_valid(`curse_effect_json`)),
  `name` varchar(64) DEFAULT NULL COMMENT 'Tainted, Corrupted, Abyssal',
  `icon` varchar(8) DEFAULT '?',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_ogham_corruption_tiers`
--

LOCK TABLES `game_ogham_corruption_tiers` WRITE;
/*!40000 ALTER TABLE `game_ogham_corruption_tiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_ogham_corruption_tiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_ogham_families`
--

DROP TABLE IF EXISTS `game_ogham_families`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_ogham_families` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `set_bonus_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`set_bonus_json`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_ogham_families`
--

LOCK TABLES `game_ogham_families` WRITE;
/*!40000 ALTER TABLE `game_ogham_families` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_ogham_families` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_ogham_fusions`
--

DROP TABLE IF EXISTS `game_ogham_fusions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_ogham_fusions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ogham_a_id` int(10) unsigned NOT NULL,
  `ogham_b_id` int(10) unsigned NOT NULL,
  `result_ogham_id` int(10) unsigned NOT NULL,
  `gold_cost` int(10) unsigned NOT NULL DEFAULT 100,
  `material_item_id` int(10) unsigned DEFAULT NULL,
  `fail_chance_pct` int(11) NOT NULL DEFAULT 0 COMMENT '0-100, chance to destroy one ogham',
  PRIMARY KEY (`id`),
  KEY `idx_combo` (`ogham_a_id`,`ogham_b_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_ogham_fusions`
--

LOCK TABLES `game_ogham_fusions` WRITE;
/*!40000 ALTER TABLE `game_ogham_fusions` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_ogham_fusions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_ogham_shards`
--

DROP TABLE IF EXISTS `game_ogham_shards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_ogham_shards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `family_id` int(10) unsigned DEFAULT NULL,
  `element` varchar(32) DEFAULT NULL,
  `shard_type` enum('offensive','defensive','utility','wild') NOT NULL DEFAULT 'offensive',
  `drop_chance_pct` decimal(5,2) NOT NULL DEFAULT 5.00 COMMENT 'base drop chance from enemies',
  `rarity` enum('common','uncommon','rare','epic') NOT NULL DEFAULT 'common',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_ogham_shards`
--

LOCK TABLES `game_ogham_shards` WRITE;
/*!40000 ALTER TABLE `game_ogham_shards` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_ogham_shards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_oghams`
--

DROP TABLE IF EXISTS `game_oghams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_oghams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `lore_text` text DEFAULT NULL,
  `rank` int(11) NOT NULL DEFAULT 1,
  `base_ogham_id` int(10) unsigned DEFAULT NULL,
  `grant_skill_id` int(10) unsigned DEFAULT NULL,
  `element_attack` varchar(64) DEFAULT NULL,
  `stat_bonus_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`stat_bonus_json`)),
  `on_hit_status` varchar(64) DEFAULT NULL,
  `on_hit_chance` int(11) DEFAULT 20,
  `kills_to_rank_up` int(11) DEFAULT 50,
  `family_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_base` (`base_ogham_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_oghams`
--

LOCK TABLES `game_oghams` WRITE;
/*!40000 ALTER TABLE `game_oghams` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_oghams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_passive_abilities`
--

DROP TABLE IF EXISTS `game_passive_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_passive_abilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `label` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`effects`)),
  `slot_type` enum('innate','equippable','class','race') NOT NULL DEFAULT 'equippable',
  `class_id` int(11) DEFAULT NULL,
  `race_id` int(11) DEFAULT NULL,
  `max_equip` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_passive_abilities`
--

LOCK TABLES `game_passive_abilities` WRITE;
/*!40000 ALTER TABLE `game_passive_abilities` DISABLE KEYS */;
INSERT INTO `game_passive_abilities` VALUES
(1,'iron_will','Iron Will','????️','Reduces all incoming damage by 5%.','{\"damage_reduction\":0.05}','equippable',NULL,NULL,1,1),
(2,'quick_feet','Quick Feet','????','+10% dodge chance.','{\"dodge_bonus\":0.10}','equippable',NULL,NULL,1,1),
(3,'heavy_hitter','Heavy Hitter','????','+10% physical damage.','{\"atk_bonus\":0.10}','equippable',NULL,NULL,1,1),
(4,'mana_flow','Mana Flow','????','Regenerate 3% MP per turn.','{\"mp_regen_pct\":0.03}','equippable',NULL,NULL,1,1),
(5,'last_stand','Last Stand','????','+25% ATK when below 25% HP.','{\"low_hp_atk_bonus\":0.25,\"threshold\":0.25}','equippable',NULL,NULL,1,1),
(6,'lucky_strike','Lucky Strike','????','+5% crit chance.','{\"crit_bonus\":0.05}','equippable',NULL,NULL,1,1),
(7,'elemental_body','Elemental Body','????','Nullify one elemental hit per battle.','{\"element_nullify_once\":true}','equippable',NULL,NULL,1,1),
(8,'counter_stance','Counter Stance','↩️','+15% counter chance.','{\"counter_bonus\":0.15}','equippable',NULL,NULL,1,1),
(9,'shield_master','Shield Master','????️','Block always reduces at least 25% damage.','{\"guaranteed_block\":0.25}','equippable',NULL,NULL,1,1),
(10,'berserker_soul','Berserker Soul','????','+20% ATK but -10% DEF permanently.','{\"atk_bonus\":0.20,\"def_penalty\":-0.10}','equippable',NULL,NULL,1,1);
/*!40000 ALTER TABLE `game_passive_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_premade_sig_techs`
--

DROP TABLE IF EXISTS `game_premade_sig_techs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_premade_sig_techs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tech_type` enum('ki_attack','physical','ki_heal') NOT NULL DEFAULT 'ki_attack',
  `element` varchar(32) DEFAULT NULL,
  `battle_text` varchar(255) DEFAULT NULL,
  `preset_abilities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`preset_abilities`)),
  `lore_text` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_premade_sig_techs`
--

LOCK TABLES `game_premade_sig_techs` WRITE;
/*!40000 ALTER TABLE `game_premade_sig_techs` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_premade_sig_techs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_quest_battle_overrides`
--

DROP TABLE IF EXISTS `game_quest_battle_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_quest_battle_overrides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quest_id` varchar(64) NOT NULL,
  `map_id` int(11) DEFAULT NULL,
  `npc_id` int(11) DEFAULT NULL,
  `win_condition_id` int(11) NOT NULL,
  `inject_protect_char_id` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_quest_battle_overrides`
--

LOCK TABLES `game_quest_battle_overrides` WRITE;
/*!40000 ALTER TABLE `game_quest_battle_overrides` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_quest_battle_overrides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_quest_board`
--

DROP TABLE IF EXISTS `game_quest_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_quest_board` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL,
  `description` text DEFAULT NULL,
  `quest_type` enum('BOARD','EVENT','FACTION','REGIONAL') NOT NULL DEFAULT 'BOARD',
  `region_id` int(10) unsigned DEFAULT NULL,
  `faction` varchar(64) DEFAULT NULL,
  `requires_flags_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`requires_flags_json`)),
  `requires_region_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`requires_region_json`)),
  `objectives_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`objectives_json`)),
  `rewards_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`rewards_json`)),
  `expires_at` datetime DEFAULT NULL,
  `max_completions` int(10) unsigned DEFAULT NULL,
  `times_completed` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_board_region` (`region_id`),
  KEY `idx_board_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_quest_board`
--

LOCK TABLES `game_quest_board` WRITE;
/*!40000 ALTER TABLE `game_quest_board` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_quest_board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_quests`
--

DROP TABLE IF EXISTS `game_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_quests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `objectives_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`objectives_json`)),
  `rewards_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`rewards_json`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `condition_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`condition_json`)),
  `region_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_quests`
--

LOCK TABLES `game_quests` WRITE;
/*!40000 ALTER TABLE `game_quests` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_quests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_race_ability_bonuses`
--

DROP TABLE IF EXISTS `game_race_ability_bonuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_race_ability_bonuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `race_id` int(10) unsigned NOT NULL,
  `ability_id` int(10) unsigned NOT NULL,
  `bonus` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_race_ability` (`race_id`,`ability_id`),
  KEY `idx_race` (`race_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_race_ability_bonuses`
--

LOCK TABLES `game_race_ability_bonuses` WRITE;
/*!40000 ALTER TABLE `game_race_ability_bonuses` DISABLE KEYS */;
INSERT INTO `game_race_ability_bonuses` VALUES
(1,1,6,1),
(2,2,3,-1),
(3,2,2,2),
(4,2,4,1),
(5,3,3,2),
(6,3,2,-1),
(7,3,1,1),
(8,4,3,1),
(9,4,4,-1),
(10,4,1,2),
(11,4,5,-1);
/*!40000 ALTER TABLE `game_race_ability_bonuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_race_class_access`
--

DROP TABLE IF EXISTS `game_race_class_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_race_class_access` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `race_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_race_class` (`race_id`,`class_id`),
  KEY `idx_race` (`race_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_race_class_access`
--

LOCK TABLES `game_race_class_access` WRITE;
/*!40000 ALTER TABLE `game_race_class_access` DISABLE KEYS */;
INSERT INTO `game_race_class_access` VALUES
(1,1,1),
(2,1,2),
(3,1,3),
(4,1,4),
(5,2,1),
(6,2,2),
(7,2,3),
(8,2,4),
(9,3,1),
(10,3,2),
(11,3,3),
(12,3,4),
(13,4,1),
(14,4,2),
(15,4,3),
(16,4,4);
/*!40000 ALTER TABLE `game_race_class_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_races`
--

DROP TABLE IF EXISTS `game_races`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_races` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '?',
  `lore` text DEFAULT NULL,
  `bonus_hp` int(11) NOT NULL DEFAULT 0,
  `bonus_mp` int(11) NOT NULL DEFAULT 0,
  `bonus_atk` int(11) NOT NULL DEFAULT 0,
  `bonus_def` int(11) NOT NULL DEFAULT 0,
  `bonus_mo` int(11) NOT NULL DEFAULT 0,
  `bonus_md` int(11) NOT NULL DEFAULT 0,
  `bonus_speed` int(11) NOT NULL DEFAULT 0,
  `bonus_luck` int(11) NOT NULL DEFAULT 0,
  `passive_ability` varchar(64) DEFAULT NULL,
  `passive_desc` varchar(255) DEFAULT NULL,
  `hidden` tinyint(1) NOT NULL DEFAULT 0,
  `portrait_asset_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_races`
--

LOCK TABLES `game_races` WRITE;
/*!40000 ALTER TABLE `game_races` DISABLE KEYS */;
INSERT INTO `game_races` VALUES
(1,'Human','Adaptable and determined. Balanced across all stats.','👤',NULL,0,0,0,0,0,0,0,5,NULL,NULL,0,NULL),
(2,'Elf','Graceful and intelligent. Bonus MP and speed.','🧝',NULL,-10,20,-2,-2,0,0,3,3,NULL,NULL,0,NULL),
(3,'Dwarf','Sturdy and tough. Bonus HP and DEF, reduced speed.','🪨',NULL,20,-10,3,5,0,0,-3,0,NULL,NULL,0,NULL),
(4,'Orc','Savage and powerful. High ATK and HP, low MD and luck.','👹',NULL,30,-20,5,2,0,0,-2,-5,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `game_races` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_racial_abilities`
--

DROP TABLE IF EXISTS `game_racial_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_racial_abilities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `race_id` int(10) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '✨',
  `ability_type` enum('passive','active') NOT NULL DEFAULT 'passive',
  `effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"stat":"speed","bonus":2}' CHECK (json_valid(`effect_json`)),
  `cooldown_turns` int(11) DEFAULT NULL,
  `unlock_level` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_race` (`race_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_racial_abilities`
--

LOCK TABLES `game_racial_abilities` WRITE;
/*!40000 ALTER TABLE `game_racial_abilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_racial_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_referrals`
--

DROP TABLE IF EXISTS `game_referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_referrals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `referrer_user_id` int(10) unsigned NOT NULL COMMENT 'the user who shared the code',
  `referred_user_id` int(10) unsigned NOT NULL COMMENT 'the new user who used the code',
  `referral_code` varchar(16) NOT NULL,
  `status` enum('pending','qualified','rewarded','expired') NOT NULL DEFAULT 'pending',
  `referred_level` int(10) unsigned NOT NULL DEFAULT 0,
  `reward_gold` int(10) unsigned NOT NULL DEFAULT 0,
  `reward_item_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `qualified_at` timestamp NULL DEFAULT NULL,
  `rewarded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_referred` (`referred_user_id`),
  KEY `idx_referrer` (`referrer_user_id`),
  KEY `idx_code` (`referral_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_referrals`
--

LOCK TABLES `game_referrals` WRITE;
/*!40000 ALTER TABLE `game_referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_region_rep_gates`
--

DROP TABLE IF EXISTS `game_region_rep_gates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_region_rep_gates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `region_id` int(10) unsigned NOT NULL,
  `faction_id` int(10) unsigned NOT NULL,
  `min_reputation` int(11) NOT NULL DEFAULT 0 COMMENT 'min rep to enter',
  `max_reputation` int(11) DEFAULT NULL COMMENT 'max rep allowed (null = no cap)',
  `deny_message` varchar(255) DEFAULT 'You are not welcome here.',
  PRIMARY KEY (`id`),
  KEY `idx_region` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_region_rep_gates`
--

LOCK TABLES `game_region_rep_gates` WRITE;
/*!40000 ALTER TABLE `game_region_rep_gates` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_region_rep_gates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_region_weather`
--

DROP TABLE IF EXISTS `game_region_weather`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_region_weather` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `region_id` int(10) unsigned NOT NULL,
  `weather_type` varchar(32) NOT NULL COMMENT 'rain, snow, fog, blood_moon, ash_fall, clear',
  `weight` int(11) NOT NULL DEFAULT 1 COMMENT 'higher = more likely',
  `duration_minutes` int(11) NOT NULL DEFAULT 30,
  `stat_modifiers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"dodge_chance":-5, "accuracy":-10}' CHECK (json_valid(`stat_modifiers`)),
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_region` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_region_weather`
--

LOCK TABLES `game_region_weather` WRITE;
/*!40000 ALTER TABLE `game_region_weather` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_region_weather` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_regions`
--

DROP TABLE IF EXISTS `game_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_regions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '?️',
  `danger_level` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `corruption_level` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `faction_control` varchar(64) DEFAULT NULL,
  `weather_override` varchar(32) DEFAULT NULL,
  `xp_mult` decimal(4,2) NOT NULL DEFAULT 1.00,
  `gold_mult` decimal(4,2) NOT NULL DEFAULT 1.00,
  `loot_mult` decimal(4,2) NOT NULL DEFAULT 1.00,
  `spawn_rate_mult` decimal(4,2) NOT NULL DEFAULT 1.00,
  `shop_price_mult` decimal(4,2) NOT NULL DEFAULT 1.00,
  `pvp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `is_sanctuary` tinyint(1) NOT NULL DEFAULT 0,
  `movement_penalty` tinyint(1) NOT NULL DEFAULT 0,
  `active_tags_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`active_tags_json`)),
  `auto_rules_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`auto_rules_json`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_regions`
--

LOCK TABLES `game_regions` WRITE;
/*!40000 ALTER TABLE `game_regions` DISABLE KEYS */;
INSERT INTO `game_regions` VALUES
(1,'Starter Lands','The peaceful starting area. Safe, low rewards.','🌿',1,0,NULL,NULL,1.00,1.00,1.00,1.00,1.00,0,0,0,NULL,NULL,1,'2026-03-15 19:50:10','2026-03-15 19:50:10'),
(2,'Ashwood Frontier','Dangerous frontier. High risk, high reward.','🌑',1,0,NULL,NULL,1.00,1.00,1.00,1.00,1.00,0,0,0,NULL,NULL,1,'2026-03-15 19:50:10','2026-03-15 19:50:10');
/*!40000 ALTER TABLE `game_regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_rituals`
--

DROP TABLE IF EXISTS `game_rituals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_rituals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `min_participants` int(11) NOT NULL DEFAULT 2,
  `max_participants` int(11) NOT NULL DEFAULT 4,
  `required_elements_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '["fire","water","earth"]' CHECK (json_valid(`required_elements_json`)),
  `channel_turns` int(11) NOT NULL DEFAULT 3,
  `effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '{"aoe_damage":"MO*5","party_heal_pct":50}' CHECK (json_valid(`effect_json`)),
  `cooldown_battles` int(11) NOT NULL DEFAULT 5,
  `level_required` int(11) NOT NULL DEFAULT 10,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_rituals`
--

LOCK TABLES `game_rituals` WRITE;
/*!40000 ALTER TABLE `game_rituals` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_rituals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_scheduled_tasks`
--

DROP TABLE IF EXISTS `game_scheduled_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_scheduled_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `task_type` enum('SHOP_RESTOCK','SPAWN_RESPAWN','DUNGEON_RESET','SET_WORLD_FLAG','SET_REGION_STATE','GIVE_XP_ALL','BROADCAST') NOT NULL,
  `schedule_type` enum('HOURLY','DAILY','WEEKLY','INTERVAL_MINUTES') NOT NULL DEFAULT 'DAILY',
  `run_at_hour` tinyint(3) unsigned DEFAULT 0,
  `run_at_day` tinyint(3) unsigned DEFAULT 1,
  `interval_minutes` int(10) unsigned DEFAULT 60,
  `target_id` int(10) unsigned DEFAULT NULL,
  `config_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config_json`)),
  `last_run_at` datetime DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sched_enabled` (`is_enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_scheduled_tasks`
--

LOCK TABLES `game_scheduled_tasks` WRITE;
/*!40000 ALTER TABLE `game_scheduled_tasks` DISABLE KEYS */;
INSERT INTO `game_scheduled_tasks` VALUES
(1,'Daily Shop Restock','SHOP_RESTOCK','DAILY',6,1,60,NULL,NULL,'2026-03-24 06:00:07',1,'2026-03-15 19:50:10'),
(2,'Midnight Dungeon Reset','DUNGEON_RESET','DAILY',0,1,60,NULL,NULL,'2026-03-25 00:00:08',1,'2026-03-15 19:50:10');
/*!40000 ALTER TABLE `game_scheduled_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_scheduler_log`
--

DROP TABLE IF EXISTS `game_scheduler_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_scheduler_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `task_name` varchar(64) NOT NULL,
  `result` enum('success','error') NOT NULL DEFAULT 'success',
  `message` text DEFAULT NULL,
  `ran_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_task` (`task_id`),
  KEY `idx_ran` (`ran_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_scheduler_log`
--

LOCK TABLES `game_scheduler_log` WRITE;
/*!40000 ALTER TABLE `game_scheduler_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_scheduler_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_scripts`
--

DROP TABLE IF EXISTS `game_scripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_scripts` (
  `script_key` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `script_json` mediumtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`script_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_scripts`
--

LOCK TABLES `game_scripts` WRITE;
/*!40000 ALTER TABLE `game_scripts` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_scripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_settings`
--

DROP TABLE IF EXISTS `game_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(20) DEFAULT 'string',
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_settings`
--

LOCK TABLES `game_settings` WRITE;
/*!40000 ALTER TABLE `game_settings` DISABLE KEYS */;
INSERT INTO `game_settings` VALUES
('ai_api_key','AIzaSyDnl63Qt8nDee9wnk5nu8QXEzrx1PBIyr0','string','2026-03-17 11:52:05'),
('ai_base_url','','string','2026-03-17 11:52:05'),
('ai_max_tokens','300','string','2026-03-17 11:52:05'),
('ai_model','gemini-2.0-flash','string','2026-03-17 12:26:19'),
('ai_provider','gemini','string','2026-03-17 11:52:05'),
('ai_temperature','0.85','string','2026-03-17 11:52:05');
/*!40000 ALTER TABLE `game_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_shard_recipes`
--

DROP TABLE IF EXISTS `game_shard_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_shard_recipes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `shard_1_id` int(10) unsigned NOT NULL,
  `shard_2_id` int(10) unsigned NOT NULL,
  `shard_3_id` int(10) unsigned NOT NULL,
  `result_type` enum('ogham','spell','wild_magic') NOT NULL DEFAULT 'spell',
  `result_ogham_id` int(10) unsigned DEFAULT NULL,
  `result_skill_id` int(10) unsigned DEFAULT NULL,
  `result_item_id` int(10) unsigned DEFAULT NULL,
  `wild_effect_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'random effects for wild_magic results' CHECK (json_valid(`wild_effect_json`)),
  `gold_cost` int(10) unsigned NOT NULL DEFAULT 50,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_shard_recipes`
--

LOCK TABLES `game_shard_recipes` WRITE;
/*!40000 ALTER TABLE `game_shard_recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_shard_recipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_shop_supplies`
--

DROP TABLE IF EXISTS `game_shop_supplies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_shop_supplies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `buy_price` int(11) NOT NULL DEFAULT 100,
  `sell_price` int(11) NOT NULL DEFAULT 50,
  `stock` int(11) NOT NULL DEFAULT -1,
  `world_flag_conditions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Item hidden from shop unless all conditions pass' CHECK (json_valid(`world_flag_conditions`)),
  `flag_price_modifiers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'e.g. [{"flag":"festival_active","multiplier":0.8}] — multiplies buy price' CHECK (json_valid(`flag_price_modifiers`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_shop_item` (`shop_id`,`item_id`),
  KEY `idx_supply_shop` (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_shop_supplies`
--

LOCK TABLES `game_shop_supplies` WRITE;
/*!40000 ALTER TABLE `game_shop_supplies` DISABLE KEYS */;
INSERT INTO `game_shop_supplies` VALUES
(1,1,3,30,50,-1,NULL,NULL),
(2,1,4,25,50,-1,NULL,NULL),
(3,1,1,50,50,10,NULL,NULL),
(4,1,2,40,50,10,NULL,NULL);
/*!40000 ALTER TABLE `game_shop_supplies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_shops`
--

DROP TABLE IF EXISTS `game_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_shops` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '?',
  `map_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_shops`
--

LOCK TABLES `game_shops` WRITE;
/*!40000 ALTER TABLE `game_shops` DISABLE KEYS */;
INSERT INTO `game_shops` VALUES
(1,'General Store','Your one-stop shop for adventuring basics.','🏪',NULL);
/*!40000 ALTER TABLE `game_shops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_signature_abilities`
--

DROP TABLE IF EXISTS `game_signature_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_signature_abilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `label` varchar(128) NOT NULL,
  `icon` varchar(16) DEFAULT '⚡',
  `description` text NOT NULL,
  `category` enum('offense','defense','utility','heal') NOT NULL DEFAULT 'offense',
  `effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'what it does: {"stun_turns":1}, {"guard_crush":true}, etc.' CHECK (json_valid(`effects`)),
  `damage_modifier` float NOT NULL DEFAULT 0 COMMENT 'added to damage_pct (-0.10 = -10% damage)',
  `cost_modifier` float NOT NULL DEFAULT 0 COMMENT 'added to cost_pct (+0.04 = +4% cost)',
  `dodge_modifier` float NOT NULL DEFAULT 0 COMMENT 'added to opponent dodge chance',
  `min_level` int(11) NOT NULL DEFAULT 1 COMMENT 'minimum tech level to equip this ability',
  `exclusive_with` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'ability IDs that conflict with this one' CHECK (json_valid(`exclusive_with`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_signature_abilities`
--

LOCK TABLES `game_signature_abilities` WRITE;
/*!40000 ALTER TABLE `game_signature_abilities` DISABLE KEYS */;
INSERT INTO `game_signature_abilities` VALUES
(1,'stun_1','1-Turn Stun','????','Stuns the target for 1 turn on hit.','offense','{\"stun_turns\":1}',-0.1,0,0,3,'[2]','2026-03-18 09:32:21'),
(2,'stun_2','2-Turn Stun','????','Stuns the target for 2 turns on hit. Requires 30%+ damage.','offense','{\"stun_turns\":2}',-0.2,0,0,5,'[1]','2026-03-18 09:32:21'),
(3,'guaranteed_hit','Guaranteed Hit','????','This technique cannot be dodged. Requires 15%+ damage.','offense','{\"guaranteed_hit\":true}',-0.1,0,0,3,'[10]','2026-03-18 09:32:21'),
(4,'guard_crush','Guard Crush','????','Unblockable — ignores block defense entirely.','offense','{\"guard_crush\":true}',0,0.04,0,5,NULL,'2026-03-18 09:32:21'),
(5,'cost_reduction','Cost Reduction','????','Reduces the HP/MP cost of this technique.','utility','{\"cost_reduction\":0.02}',-0.02,-0.02,0,3,NULL,'2026-03-18 09:32:21'),
(6,'bleed_apply','Hemorrhage','????','Applies Moderate Bleed on hit.','offense','{\"bleed_tier\":\"moderate\"}',0,0.03,0,5,NULL,'2026-03-18 09:32:21'),
(7,'multi_hit','Scatter Shot','????','Splits into 3 hits across multiple targets. 1/3 damage each.','offense','{\"multi_hit\":3}',0,0.05,0,8,NULL,'2026-03-18 09:32:21'),
(8,'piercing','Piercing Strike','????️','Ignores 50% of target defense.','offense','{\"piercing\":0.50}',0,0.04,0,5,NULL,'2026-03-18 09:32:21'),
(9,'power_surge','Power Surge','⬆️','Increases damage but gives the opponent extra dodge chance.','offense','{\"damage_bonus\":true}',0.01,0.005,0.015,3,'[3]','2026-03-18 09:32:21'),
(10,'extra_dodge','Reckless Style','????','More damage, but opponent can dodge more easily. Cannot combine with Guaranteed Hit.','offense','{\"damage_bonus\":true}',0.01,0.005,0.015,3,'[3]','2026-03-18 09:32:21'),
(11,'heal_extra_use','Restorative Echo','????','Allows one extra use of this healing technique per day.','heal','{\"extra_daily_use\":1}',0,0.05,0,3,NULL,'2026-03-18 09:32:21'),
(12,'heal_dodge_buff','Invigorating Heal','????️','Target gains +5% dodge for the rest of battle.','heal','{\"dodge_buff\":0.05}',0,0.02,0,5,NULL,'2026-03-18 09:32:21'),
(13,'heal_regen_limb','Mending Touch','????','Can regenerate a disabled limb.','heal','{\"regen_limb\":true}',0,0.05,0,8,NULL,'2026-03-18 09:32:21');
/*!40000 ALTER TABLE `game_signature_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_signature_levels`
--

DROP TABLE IF EXISTS `game_signature_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_signature_levels` (
  `level` int(11) NOT NULL,
  `damage_pct` float NOT NULL COMMENT 'for ki_attack type: % of powerlevel as damage',
  `cost_pct` float NOT NULL COMMENT 'for ki_attack type: % of current HP as cost',
  `heal_pct` float NOT NULL DEFAULT 0 COMMENT 'for ki_heal type: % of target HP healed',
  `ability_slots` int(11) NOT NULL DEFAULT 0 COMMENT 'cumulative special ability slots unlocked at this level',
  `xp_required` int(11) NOT NULL DEFAULT 0 COMMENT 'total XP needed to reach this level',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_signature_levels`
--

LOCK TABLES `game_signature_levels` WRITE;
/*!40000 ALTER TABLE `game_signature_levels` DISABLE KEYS */;
INSERT INTO `game_signature_levels` VALUES
(1,0.1,0.01,0.1,0,0,'Nascent technique. A raw expression of your fighting spirit.'),
(2,0.11,0.02,0.15,0,50,'The form solidifies. Muscle memory begins to take hold.'),
(3,0.12,0.03,0.22,1,150,'First breakthrough — unlock a special ability.'),
(4,0.14,0.04,0.3,1,300,'Growing confidence. The technique flows naturally.'),
(5,0.16,0.05,0.4,2,500,'Second breakthrough — unlock another ability.'),
(6,0.18,0.06,0.5,2,750,'The technique becomes an extension of your will.'),
(7,0.2,0.08,0.6,2,1050,'Masterful control. Opponents begin to fear this move.'),
(8,0.23,0.1,0.7,3,1400,'Third breakthrough — another ability slot opens.'),
(9,0.26,0.12,0.8,3,1800,'Near perfection. The technique defines your legend.'),
(10,0.3,0.14,0.9,4,2500,'Mastered. This technique is uniquely yours — your signature.');
/*!40000 ALTER TABLE `game_signature_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_skills`
--

DROP TABLE IF EXISTS `game_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `battle_text` varchar(255) DEFAULT NULL,
  `type` enum('physical','magic','heal','buff','debuff','special') NOT NULL DEFAULT 'magic',
  `target_type` varchar(32) NOT NULL DEFAULT 'ENEMY',
  `elements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`elements`)),
  `heal_status` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`heal_status`)),
  `icon` varchar(8) DEFAULT '✨',
  `effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`effects`)),
  `combo_chance` float NOT NULL DEFAULT 0,
  `combo_max_chain` int(11) NOT NULL DEFAULT 1,
  `alignment_required` int(11) DEFAULT NULL COMMENT 'min alignment to use (positive = good, negative = evil)',
  `is_nonlethal` tinyint(1) NOT NULL DEFAULT 0,
  `heal_limb` varchar(32) DEFAULT NULL,
  `turn_delay` int(11) NOT NULL DEFAULT 0,
  `cancels_charge` tinyint(1) NOT NULL DEFAULT 0,
  `icon_asset_id` int(11) DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `unlock_level` int(11) NOT NULL DEFAULT 1,
  `magic_school_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_skills`
--

LOCK TABLES `game_skills` WRITE;
/*!40000 ALTER TABLE `game_skills` DISABLE KEYS */;
INSERT INTO `game_skills` VALUES
(1,'Mighty Strike','A powerful physical blow that always ignores Defending.','{name} winds up a devastating strike!','physical','ENEMY',NULL,NULL,'⚔️','{\"damage\":{\"formula\":\"ATK*3-DEF\",\"randomize\":0.1},\"log\":\"{name} strikes hard!\"}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(2,'War Cry','A battle roar that raises your own ATK for 3 turns.','{name} lets out a fearsome war cry!','buff','SELF',NULL,NULL,'📣','{\"set_status\":{\"target\":\"self\",\"statuses\":{\"ATK Up\":3}}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(3,'Blade Rush','Chain of rapid slashes — lower per hit but ignores some DEF.','{name} launches a flurry of blade strikes!','physical','ENEMY',NULL,NULL,'🌀','{\"damage\":{\"formula\":\"ATK*2.5\",\"randomize\":0.2}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(4,'Fireball','A blazing fireball with a chance to inflict Burn.','{name} conjures a roaring fireball!','magic','ENEMY',NULL,NULL,'🔥','{\"damage\":{\"formula\":\"MO*2.5-MD\",\"randomize\":0.1},\"elements\":[\"fire\"],\"set_status\":{\"target\":\"enemy\",\"chance\":30,\"statuses\":{\"Burn\":2}}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(5,'Ice Shard','Shards of ice that slow the target (DEF Down).','{name} launches a volley of ice shards!','magic','ENEMY',NULL,NULL,'❄️','{\"damage\":{\"formula\":\"MO*2-MD\",\"randomize\":0.05},\"elements\":[\"ice\"],\"set_status\":{\"target\":\"enemy\",\"chance\":40,\"statuses\":{\"DEF Down\":2}}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(6,'Thunder Strike','Lightning bolt with a chance to Stun.','{name} calls down a bolt of lightning!','magic','ENEMY',NULL,NULL,'⚡','{\"damage\":{\"formula\":\"MO*3-MD\",\"randomize\":0.15},\"elements\":[\"lightning\"],\"set_status\":{\"target\":\"enemy\",\"chance\":25,\"statuses\":{\"Stun\":1}}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(7,'Arcane Missile','Pure arcane energy — no element, harder to resist.','{name} fires a bolt of pure arcane power!','magic','ENEMY',NULL,NULL,'🔮','{\"damage\":{\"formula\":\"MO*2.2-MD*0.5\",\"randomize\":0.08}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(8,'Backstab','Strikes from the shadows — high crit chance, uses LUCK in formula.','{name} lunges from the shadows!','physical','ENEMY',NULL,NULL,'🗡️','{\"damage\":{\"formula\":\"ATK*2+LUCK*2-DEF\",\"randomize\":0.2}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(9,'Smoke Bomb','Blinds the enemy for 2 turns, cutting their ATK in half.','{name} hurls a smoke bomb!','debuff','ENEMY',NULL,NULL,'💨','{\"set_status\":{\"target\":\"enemy\",\"chance\":90,\"statuses\":{\"Blind\":2}}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(10,'Poison Blade','A venomous strike that poisons the target.','{name} coats their blade in venom!','physical','ENEMY',NULL,NULL,'🟣','{\"damage\":{\"formula\":\"ATK*1.5-DEF\",\"randomize\":0.1},\"set_status\":{\"target\":\"enemy\",\"chance\":75,\"statuses\":{\"Poison\":3}}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(11,'Heal','Restores a moderate amount of your own HP.','{name} channels holy energy!','heal','SELF',NULL,NULL,'💚','{\"heal\":{\"formula\":\"MO*3+50\"}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(12,'Holy Light','A burst of holy light that damages undead and cures Poison.','{name} calls down a ray of holy light!','magic','ENEMY',NULL,NULL,'✨','{\"damage\":{\"formula\":\"MO*2.2-MD\",\"randomize\":0.1},\"elements\":[\"holy\"]}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(13,'Regen','Applies a regeneration buff to yourself for 3 turns.','{name} blesses themselves with regeneration!','buff','SELF',NULL,NULL,'🌿','{\"set_status\":{\"target\":\"self\",\"statuses\":{\"Regen\":3}}}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL),
(14,'Smite','A powerful divine strike — scales with both ATK and MO.','{name} strikes with divine fury!','magic','ENEMY',NULL,NULL,'⚡','{\"damage\":{\"formula\":\"(ATK+MO)*1.5-DEF\",\"randomize\":0.1},\"elements\":[\"holy\"]}',0,1,NULL,0,NULL,0,0,NULL,NULL,1,NULL);
/*!40000 ALTER TABLE `game_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_spawn_waves`
--

DROP TABLE IF EXISTS `game_spawn_waves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_spawn_waves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `spawn_id` int(10) unsigned NOT NULL COMMENT 'links to game_spawns',
  `wave_number` int(11) NOT NULL DEFAULT 1,
  `enemies` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '[{"npc_id":5,"count":3},{"npc_id":8,"count":1}]' CHECK (json_valid(`enemies`)),
  `delay_seconds` int(11) NOT NULL DEFAULT 0 COMMENT 'delay before this wave starts',
  `is_boss_wave` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_spawn` (`spawn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_spawn_waves`
--

LOCK TABLES `game_spawn_waves` WRITE;
/*!40000 ALTER TABLE `game_spawn_waves` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_spawn_waves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_spell_slot_table`
--

DROP TABLE IF EXISTS `game_spell_slot_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_spell_slot_table` (
  `character_level` int(11) NOT NULL,
  `slot_level` int(11) NOT NULL,
  `slot_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`character_level`,`slot_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_spell_slot_table`
--

LOCK TABLES `game_spell_slot_table` WRITE;
/*!40000 ALTER TABLE `game_spell_slot_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_spell_slot_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_spell_tomes`
--

DROP TABLE IF EXISTS `game_spell_tomes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_spell_tomes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `teaches_skill_id` int(10) unsigned NOT NULL COMMENT 'skill permanently learned',
  `item_id` int(10) unsigned DEFAULT NULL COMMENT 'links to game_items (consumed on use)',
  `rarity` enum('uncommon','rare','epic','legendary') NOT NULL DEFAULT 'rare',
  `level_required` int(11) NOT NULL DEFAULT 1,
  `class_required_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_spell_tomes`
--

LOCK TABLES `game_spell_tomes` WRITE;
/*!40000 ALTER TABLE `game_spell_tomes` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_spell_tomes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_stat_caps`
--

DROP TABLE IF EXISTS `game_stat_caps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_stat_caps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stat_key` varchar(32) NOT NULL,
  `tier` int(11) NOT NULL DEFAULT 1 COMMENT '1=first range, 2=second, 3=third',
  `threshold` int(11) NOT NULL COMMENT 'stat value where this tier starts',
  `effectiveness` decimal(3,2) NOT NULL DEFAULT 1.00 COMMENT '1.0=full, 0.5=half, 0.25=quarter',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stat_tier` (`stat_key`,`tier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_stat_caps`
--

LOCK TABLES `game_stat_caps` WRITE;
/*!40000 ALTER TABLE `game_stat_caps` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_stat_caps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_stat_definitions`
--

DROP TABLE IF EXISTS `game_stat_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_stat_definitions` (
  `key_name` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `default_value` int(11) NOT NULL DEFAULT 0,
  `min_value` int(11) NOT NULL DEFAULT 0,
  `max_value` int(11) NOT NULL DEFAULT 9999,
  `icon` varchar(8) DEFAULT '?',
  `display_name` varchar(64) DEFAULT NULL,
  `type` enum('CORE','HIDDEN','META') NOT NULL DEFAULT 'CORE',
  PRIMARY KEY (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_stat_definitions`
--

LOCK TABLES `game_stat_definitions` WRITE;
/*!40000 ALTER TABLE `game_stat_definitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_stat_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_status_combos`
--

DROP TABLE IF EXISTS `game_status_combos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_status_combos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_a` varchar(64) NOT NULL,
  `status_b` varchar(64) NOT NULL,
  `combo_name` varchar(64) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `effect_type` enum('bonus_damage','guaranteed_crit','remove_both','apply_new','heal_block') NOT NULL,
  `effect_value` float NOT NULL DEFAULT 0.5,
  `apply_status` varchar(32) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_combo` (`status_a`,`status_b`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_status_combos`
--

LOCK TABLES `game_status_combos` WRITE;
/*!40000 ALTER TABLE `game_status_combos` DISABLE KEYS */;
INSERT INTO `game_status_combos` VALUES
(1,'Burning','Poison','Toxic Inferno','☠️','bonus_damage',0.5,NULL,'Poison ignites!',1),
(2,'Stun','Stun','Concussion','????','bonus_damage',0.3,NULL,'Double stun — crit window!',1),
(3,'Burning','Bleeding','Cauterize','????','remove_both',0,NULL,'Fire cauterizes the wound!',1),
(4,'Blind','Poison','Miasma','☁️','apply_new',0,'DEF Down','Toxic blindness!',1),
(5,'DEF Down','Burning','Exposed Flame','????','bonus_damage',0.4,NULL,'No defense against flames!',1),
(6,'Stun','Blind','Helpless','????','guaranteed_crit',0,NULL,'Any hit is a critical!',1);
/*!40000 ALTER TABLE `game_status_combos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_status_immunities`
--

DROP TABLE IF EXISTS `game_status_immunities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_status_immunities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source_type` enum('race','class','item') NOT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned NOT NULL COMMENT 'immune to this status effect',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_source_status` (`source_type`,`source_id`,`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_status_immunities`
--

LOCK TABLES `game_status_immunities` WRITE;
/*!40000 ALTER TABLE `game_status_immunities` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_status_immunities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_statuses`
--

DROP TABLE IF EXISTS `game_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '⚡',
  `type` enum('buff','debuff','neutral') NOT NULL DEFAULT 'debuff',
  `default_duration` int(11) NOT NULL DEFAULT 3,
  `permanent` tinyint(1) NOT NULL DEFAULT 0,
  `effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`effects`)),
  `disabled_commands` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`disabled_commands`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_statuses`
--

LOCK TABLES `game_statuses` WRITE;
/*!40000 ALTER TABLE `game_statuses` DISABLE KEYS */;
INSERT INTO `game_statuses` VALUES
(1,'Poison','Drains HP each turn.','🟣','debuff',3,0,'{\"damage_per_turn\":{\"formula\":\"MAXHP*0.05+5\"},\"log\":\"{name} is poisoned for \"}',NULL),
(2,'Defending','Reduces incoming damage by 50% this turn.','🛡️','buff',1,0,'{\"stat_mod\":{\"def\":2}}',NULL),
(3,'Burn','Fire damage each turn — higher but shorter than Poison.','🔥','debuff',2,0,'{\"damage_per_turn\":{\"formula\":\"MAXHP*0.08+8\"},\"log\":\"{name} is burning!\"}',NULL),
(4,'Regen','Restores HP each turn.','💚','buff',3,0,'{\"heal_per_turn\":{\"formula\":\"MAXHP*0.06+10\"},\"log\":\"{name} regenerates.\"}',NULL),
(5,'Blind','Reduced accuracy — halves ATK.','🌑','debuff',2,0,'{\"stat_mod\":{\"atk\":0.5},\"log\":\"{name} is blinded!\"}',NULL),
(6,'Stun','Skip your next turn entirely.','⚡','debuff',1,0,'{\"skip_turn\":true,\"log\":\"{name} is stunned and cannot act!\"}','[-1]'),
(7,'ATK Up','Increases ATK by 50%.','⬆️','buff',3,0,'{\"stat_mod\":{\"atk\":1.5},\"log\":\"{name} is powered up!\"}',NULL),
(8,'DEF Down','Reduces enemy DEF by 40%.','⬇️','debuff',2,0,'{\"stat_mod\":{\"def\":0.6},\"log\":\"{name} defense is weakened!\"}',NULL);
/*!40000 ALTER TABLE `game_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_subclasses`
--

DROP TABLE IF EXISTS `game_subclasses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_subclasses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(10) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '⚔️',
  `unlock_level` int(11) NOT NULL DEFAULT 10,
  `bonus_stats_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"atk":5,"speed":2}' CHECK (json_valid(`bonus_stats_json`)),
  `skills_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[1,2,3] skill IDs unlocked' CHECK (json_valid(`skills_json`)),
  PRIMARY KEY (`id`),
  KEY `idx_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_subclasses`
--

LOCK TABLES `game_subclasses` WRITE;
/*!40000 ALTER TABLE `game_subclasses` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_subclasses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_summons`
--

DROP TABLE IF EXISTS `game_summons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_summons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(8) DEFAULT '?',
  `description` text DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `mp_cost` int(11) NOT NULL DEFAULT 50,
  `duration_turns` int(11) NOT NULL DEFAULT 3,
  `stats_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '{}' COMMENT '{"hp":200,"atk":30,"def":20}' CHECK (json_valid(`stats_json`)),
  `skills_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[cmd_id_1, cmd_id_2]' CHECK (json_valid(`skills_json`)),
  `level_required` int(11) NOT NULL DEFAULT 1,
  `cooldown_battles` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_summons`
--

LOCK TABLES `game_summons` WRITE;
/*!40000 ALTER TABLE `game_summons` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_summons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_templates`
--

DROP TABLE IF EXISTS `game_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `label` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `preview_image` varchar(255) DEFAULT NULL,
  `author` varchar(128) DEFAULT 'Twisted Engine',
  `version` varchar(16) DEFAULT '1.0',
  `terminology_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'overrides for game_terminology' CHECK (json_valid(`terminology_json`)),
  `settings_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'overrides for system_settings' CHECK (json_valid(`settings_json`)),
  `classes_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'array of class definitions' CHECK (json_valid(`classes_json`)),
  `races_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'array of race definitions' CHECK (json_valid(`races_json`)),
  `items_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'starter items' CHECK (json_valid(`items_json`)),
  `skills_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'starter skills' CHECK (json_valid(`skills_json`)),
  `maps_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'starter maps with tiles/events' CHECK (json_valid(`maps_json`)),
  `npcs_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'starter NPCs' CHECK (json_valid(`npcs_json`)),
  `quests_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'starter quests' CHECK (json_valid(`quests_json`)),
  `battle_config_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'which battle features to enable/disable' CHECK (json_valid(`battle_config_json`)),
  `styles_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'fighting styles for this theme' CHECK (json_valid(`styles_json`)),
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `installed` tinyint(1) NOT NULL DEFAULT 0,
  `installed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_templates`
--

LOCK TABLES `game_templates` WRITE;
/*!40000 ALTER TABLE `game_templates` DISABLE KEYS */;
INSERT INTO `game_templates` VALUES
(1,'celtic_fantasy','Dark Celtic Fantasy','🗡️','A dark world of ancient druids, blood oghams, and warring clans. Inspired by Celtic mythology, with twisted creatures lurking in the mists.',NULL,'Twisted Engine','1.0','{\"ki\":{\"display_name\":\"Druidic Spirit\",\"icon\":\"🌀\",\"description\":\"The old power that flows through standing stones.\"},\"mp\":{\"display_name\":\"Mana\",\"icon\":\"💧\",\"description\":\"Magical energy drawn from the ley lines.\"},\"channel_ki\":{\"display_name\":\"Spirit Eruption\",\"icon\":\"🌀\",\"description\":\"Channel the raw energy of the land.\"},\"alignment\":{\"display_name\":\"Druidic Balance\",\"icon\":\"☯️\",\"description\":\"The balance between light and shadow.\"},\"afterlife\":{\"display_name\":\"The Otherworld\",\"icon\":\"🌙\",\"description\":\"Where spirits dwell between lives.\"},\"sig_tech\":{\"display_name\":\"Blood Technique\",\"icon\":\"🩸\",\"description\":\"A technique forged from your own essence.\"},\"spell_slots\":{\"display_name\":\"Ritual Charges\",\"icon\":\"📿\",\"description\":\"Power stored in carved oghams.\"},\"summon\":{\"display_name\":\"Spirit Summon\",\"icon\":\"👻\",\"description\":\"Call a bound spirit from the Otherworld.\"},\"transform\":{\"display_name\":\"Wild Shape\",\"icon\":\"🐺\",\"description\":\"Take the form of a beast or spirit.\"},\"fighting_style\":{\"display_name\":\"War Art\",\"icon\":\"⚔️\",\"description\":\"Ancient combat traditions passed through clans.\"},\"tournament\":{\"display_name\":\"The Great Trial\",\"icon\":\"🏆\",\"description\":\"Prove your worth in ritual combat.\"}}','{\"game_title\":\"Twisted Engine\",\"game_subtitle\":\"Dark Celtic Fantasy RPG\"}','[{\"name\":\"Warrior\",\"icon\":\"⚔️\",\"description\":\"Frontline fighter. High HP and ATK.\",\"base_hp\":120,\"base_mp\":30,\"base_atk\":14,\"base_def\":10,\"base_mo\":3,\"base_md\":5,\"base_speed\":6,\"base_luck\":4},{\"name\":\"Mage\",\"icon\":\"🔮\",\"description\":\"Arcane spellcaster. High MO and MP.\",\"base_hp\":70,\"base_mp\":100,\"base_atk\":4,\"base_def\":4,\"base_mo\":15,\"base_md\":10,\"base_speed\":5,\"base_luck\":6},{\"name\":\"Rogue\",\"icon\":\"🗡️\",\"description\":\"Swift and cunning. High Speed and Luck.\",\"base_hp\":85,\"base_mp\":50,\"base_atk\":10,\"base_def\":6,\"base_mo\":5,\"base_md\":5,\"base_speed\":14,\"base_luck\":10},{\"name\":\"Cleric\",\"icon\":\"✨\",\"description\":\"Holy healer. High MO and MD.\",\"base_hp\":90,\"base_mp\":80,\"base_atk\":6,\"base_def\":8,\"base_mo\":12,\"base_md\":12,\"base_speed\":5,\"base_luck\":7}]','[{\"name\":\"Human\",\"icon\":\"🧑\",\"description\":\"Versatile and adaptive. Balanced stats.\",\"bonus_hp\":5,\"bonus_luck\":3},{\"name\":\"Fae-Touched\",\"icon\":\"🧝\",\"description\":\"Otherworldly grace. High magic, fragile.\",\"bonus_mo\":5,\"bonus_md\":3,\"bonus_hp\":-10,\"bonus_speed\":3},{\"name\":\"Dwarf\",\"icon\":\"⛏️\",\"description\":\"Stout and resilient. High defense.\",\"bonus_hp\":15,\"bonus_def\":5,\"bonus_speed\":-3},{\"name\":\"Woad-Painted\",\"icon\":\"💀\",\"description\":\"Fierce tribal warriors. High ATK, low magic defense.\",\"bonus_atk\":5,\"bonus_speed\":3,\"bonus_md\":-3}]','[{\"name\":\"Iron Sword\",\"icon\":\"🗡️\",\"type\":\"weapon\",\"rarity\":\"common\",\"value\":50,\"equip_slot\":\"weapon\"},{\"name\":\"Oak Staff\",\"icon\":\"🪄\",\"type\":\"weapon\",\"rarity\":\"common\",\"value\":45,\"equip_slot\":\"weapon\"},{\"name\":\"Leather Armor\",\"icon\":\"🧥\",\"type\":\"armor\",\"rarity\":\"common\",\"value\":40,\"equip_slot\":\"body\"},{\"name\":\"Health Potion\",\"icon\":\"🧪\",\"type\":\"consumable\",\"rarity\":\"common\",\"value\":20},{\"name\":\"Mana Tonic\",\"icon\":\"💧\",\"type\":\"consumable\",\"rarity\":\"common\",\"value\":25}]','[]','[{\"name\":\"Tara Village\",\"description\":\"A small settlement at the base of the Hill of Tara.\",\"width\":20,\"height\":20,\"min_level\":1},{\"name\":\"Darkwood Forest\",\"description\":\"Ancient trees twisted by shadow. Beware what lurks.\",\"width\":25,\"height\":25,\"min_level\":3},{\"name\":\"The Standing Stones\",\"description\":\"A circle of power where the veil is thin.\",\"width\":15,\"height\":15,\"min_level\":5}]','[{\"name\":\"Elder Brigid\",\"icon\":\"👵\",\"persona\":\"A wise druid elder who guides newcomers.\",\"is_enemy\":0,\"map_id\":1,\"x\":10,\"y\":10,\"is_master\":1},{\"name\":\"Shadow Wolf\",\"icon\":\"🐺\",\"persona\":\"A corrupted beast prowling the forest edge.\",\"is_enemy\":1,\"map_id\":2,\"x\":12,\"y\":8},{\"name\":\"Merchant Cian\",\"icon\":\"🧔\",\"persona\":\"A traveling merchant with rare wares.\",\"is_enemy\":0,\"map_id\":1,\"x\":7,\"y\":12}]',NULL,'{\"enable_limb_targeting\":\"true\",\"enable_active_defense\":\"true\",\"enable_nonlethal\":\"true\",\"enable_wound_degradation\":\"true\",\"enable_ki_channeling\":\"true\",\"enable_fighting_styles\":\"true\",\"enable_signature_techs\":\"true\",\"enable_rp_descriptions\":\"true\",\"enable_battle_narration\":\"true\",\"enable_rp_commands\":\"true\",\"enable_alignment_system\":\"true\",\"enable_afterlife\":\"true\",\"enable_elemental_reactions\":\"true\",\"enable_boss_phases\":\"true\",\"enable_summons\":\"true\",\"enable_weather_effects\":\"true\",\"enable_stealth\":\"true\",\"enable_transformations\":\"true\"}','[{\"name\":\"iron_fist\",\"label\":\"Iron Fist\",\"icon\":\"👊\",\"style_type\":\"offensive\",\"description\":\"Raw striking power from the war camps.\"},{\"name\":\"shadow_step\",\"label\":\"Shadow Step\",\"icon\":\"💨\",\"style_type\":\"defensive\",\"description\":\"Evasive Fae-touched combat arts.\"}]',1,0,NULL,'2026-03-18 11:07:54'),
(2,'scifi_opera','Sci-Fi Space Opera','🚀','Explore the galaxy, command starships, and master plasma weapons. A space adventure with alien races and cosmic powers.',NULL,'Twisted Engine','1.0','{\"hp\":{\"display_name\":\"Shield Points\",\"icon\":\"🛡️\",\"description\":\"Energy shields protecting you.\"},\"mp\":{\"display_name\":\"Energy\",\"icon\":\"⚡\",\"description\":\"Power cell charge for abilities.\"},\"ki\":{\"display_name\":\"Psi Energy\",\"icon\":\"🧠\",\"description\":\"Psychic energy from neural amplifiers.\"},\"atk\":{\"display_name\":\"Firepower\",\"icon\":\"🔫\",\"description\":\"Weapon damage output.\"},\"def\":{\"display_name\":\"Armor\",\"icon\":\"🛡️\",\"description\":\"Damage absorption rating.\"},\"mo\":{\"display_name\":\"Psi Power\",\"icon\":\"🧠\",\"description\":\"Psychic ability strength.\"},\"md\":{\"display_name\":\"Psi Shield\",\"icon\":\"🔮\",\"description\":\"Psychic defense rating.\"},\"channel_ki\":{\"display_name\":\"Overcharge\",\"icon\":\"⚡\",\"description\":\"Push your reactor to maximum output.\"},\"alignment\":{\"display_name\":\"Faction Standing\",\"icon\":\"⚖️\",\"description\":\"Your reputation across factions.\"},\"afterlife\":{\"display_name\":\"Clone Bay\",\"icon\":\"🧬\",\"description\":\"Where your backup clone activates.\"},\"sig_tech\":{\"display_name\":\"Custom Mod\",\"icon\":\"🔧\",\"description\":\"Your personal weapon modification.\"},\"spell_slots\":{\"display_name\":\"Ammo Clips\",\"icon\":\"🔋\",\"description\":\"Limited special ammunition.\"},\"summon\":{\"display_name\":\"Deploy Drone\",\"icon\":\"🤖\",\"description\":\"Activate a combat drone.\"},\"transform\":{\"display_name\":\"Power Armor\",\"icon\":\"🦾\",\"description\":\"Activate your mech suit.\"},\"fighting_style\":{\"display_name\":\"Combat Protocol\",\"icon\":\"📡\",\"description\":\"Trained combat subroutines.\"},\"tournament\":{\"display_name\":\"Arena Championship\",\"icon\":\"🏟️\",\"description\":\"Galactic combat tournament.\"},\"gold\":{\"display_name\":\"Credits\",\"icon\":\"💳\",\"description\":\"Universal currency.\"},\"experience\":{\"display_name\":\"Data Points\",\"icon\":\"📊\",\"description\":\"Experience accumulated from missions.\"}}','{}','[{\"name\":\"Soldier\",\"icon\":\"🔫\",\"description\":\"Frontline combatant. Heavy armor and firepower.\",\"base_hp\":120,\"base_mp\":40,\"base_atk\":14,\"base_def\":10,\"base_mo\":3,\"base_md\":4,\"base_speed\":6,\"base_luck\":3},{\"name\":\"Engineer\",\"icon\":\"🔧\",\"description\":\"Tech specialist. Drones and gadgets.\",\"base_hp\":90,\"base_mp\":70,\"base_atk\":8,\"base_def\":6,\"base_mo\":10,\"base_md\":8,\"base_speed\":7,\"base_luck\":5},{\"name\":\"Psion\",\"icon\":\"🧠\",\"description\":\"Psychic operative. Mind over matter.\",\"base_hp\":70,\"base_mp\":100,\"base_atk\":4,\"base_def\":4,\"base_mo\":16,\"base_md\":12,\"base_speed\":5,\"base_luck\":6},{\"name\":\"Infiltrator\",\"icon\":\"🥷\",\"description\":\"Stealth specialist. Strike from shadows.\",\"base_hp\":80,\"base_mp\":60,\"base_atk\":12,\"base_def\":5,\"base_mo\":5,\"base_md\":5,\"base_speed\":14,\"base_luck\":10}]','[{\"name\":\"Human\",\"icon\":\"🧑\",\"description\":\"Adaptable colonists. Balanced stats.\",\"bonus_hp\":5,\"bonus_luck\":3},{\"name\":\"Zephyran\",\"icon\":\"👽\",\"description\":\"Tall, elegant aliens with psychic gifts.\",\"bonus_mo\":5,\"bonus_md\":5,\"bonus_hp\":-10},{\"name\":\"Krell\",\"icon\":\"🦎\",\"description\":\"Reptilian warriors. Tough and strong.\",\"bonus_hp\":15,\"bonus_atk\":5,\"bonus_speed\":-3,\"bonus_mo\":-3},{\"name\":\"Synth\",\"icon\":\"🤖\",\"description\":\"Synthetic humanoid. High speed, no magic.\",\"bonus_speed\":8,\"bonus_def\":3,\"bonus_mo\":-5,\"bonus_md\":-5}]','[{\"name\":\"Plasma Pistol\",\"icon\":\"🔫\",\"type\":\"weapon\",\"rarity\":\"common\",\"value\":100,\"equip_slot\":\"weapon\"},{\"name\":\"Energy Shield\",\"icon\":\"🛡️\",\"type\":\"armor\",\"rarity\":\"common\",\"value\":80,\"equip_slot\":\"body\"},{\"name\":\"Medkit\",\"icon\":\"🩹\",\"type\":\"consumable\",\"rarity\":\"common\",\"value\":30},{\"name\":\"Energy Cell\",\"icon\":\"🔋\",\"type\":\"consumable\",\"rarity\":\"common\",\"value\":25}]','[]','[{\"name\":\"Station Alpha\",\"description\":\"A bustling space station on the frontier.\",\"width\":20,\"height\":20,\"min_level\":1},{\"name\":\"Derelict Freighter\",\"description\":\"An abandoned cargo ship. Something still moves inside.\",\"width\":18,\"height\":12,\"min_level\":3},{\"name\":\"Alien Ruins\",\"description\":\"Ancient structures on an uncharted world.\",\"width\":22,\"height\":22,\"min_level\":5}]','[{\"name\":\"Commander Vex\",\"icon\":\"👨‍✈️\",\"persona\":\"Station commander. Gives missions to new recruits.\",\"is_enemy\":0,\"map_id\":1,\"x\":10,\"y\":10,\"is_master\":1},{\"name\":\"Rogue Drone\",\"icon\":\"🤖\",\"persona\":\"A malfunctioning security drone.\",\"is_enemy\":1,\"map_id\":2,\"x\":8,\"y\":5}]',NULL,'{\"enable_limb_targeting\":\"true\",\"enable_active_defense\":\"true\",\"enable_nonlethal\":\"true\",\"enable_spell_slots\":\"true\",\"summon_cost_type\":\"spell_slot\",\"enable_stealth\":\"true\",\"enable_transformations\":\"true\",\"enable_elemental_reactions\":\"false\",\"enable_weather_effects\":\"false\"}','[]',0,0,NULL,'2026-03-18 11:07:54'),
(3,'anime_fighter','Anime Fighter','⚡','Power up, train under masters, and clash in epic battles! Inspired by Dragon Ball Z, Naruto, and classic anime fighters.',NULL,'Twisted Engine (Planet Mado tribute)','1.0','{\"hp\":{\"display_name\":\"Vitality\",\"icon\":\"❤️\",\"description\":\"Your life force.\"},\"mp\":{\"display_name\":\"Ki\",\"icon\":\"🔥\",\"description\":\"Inner energy for powerful techniques.\"},\"ki\":{\"display_name\":\"Ki\",\"icon\":\"🔥\",\"description\":\"The power within all living things.\"},\"atk\":{\"display_name\":\"Power\",\"icon\":\"💪\",\"description\":\"Physical striking force.\"},\"def\":{\"display_name\":\"Endurance\",\"icon\":\"🛡️\",\"description\":\"Ability to withstand hits.\"},\"mo\":{\"display_name\":\"Ki Control\",\"icon\":\"✨\",\"description\":\"Energy blast potency.\"},\"md\":{\"display_name\":\"Ki Defense\",\"icon\":\"🌀\",\"description\":\"Resistance to energy attacks.\"},\"speed\":{\"display_name\":\"Speed\",\"icon\":\"💨\",\"description\":\"Movement and reaction time.\"},\"level\":{\"display_name\":\"Power Level\",\"icon\":\"📊\",\"description\":\"Overall combat rating.\"},\"gold\":{\"display_name\":\"Zeni\",\"icon\":\"💰\",\"description\":\"Money.\"},\"channel_ki\":{\"display_name\":\"Power Up\",\"icon\":\"🔥\",\"description\":\"Unleash your full power!\"},\"alignment\":{\"display_name\":\"Alignment\",\"icon\":\"⚖️\",\"description\":\"Good vs Evil.\"},\"afterlife\":{\"display_name\":\"Other World\",\"icon\":\"☁️\",\"description\":\"Train under King Kai or explore Hell.\"},\"sig_tech\":{\"display_name\":\"Signature Move\",\"icon\":\"⚡\",\"description\":\"Your own unique technique!\"},\"spell_slots\":{\"display_name\":\"Ki Reserves\",\"icon\":\"🔋\",\"description\":\"Stored energy for powerful moves.\"},\"summon\":{\"display_name\":\"Call Ally\",\"icon\":\"📣\",\"description\":\"Call a fighter to your aid.\"},\"transform\":{\"display_name\":\"Transformation\",\"icon\":\"⭐\",\"description\":\"Ascend to a new form!\"},\"fighting_style\":{\"display_name\":\"Martial Art\",\"icon\":\"🥋\",\"description\":\"Your fighting discipline.\"},\"tournament\":{\"display_name\":\"World Tournament\",\"icon\":\"🏆\",\"description\":\"The greatest fighters compete!\"},\"limb_targeting\":{\"display_name\":\"Body Targeting\",\"icon\":\"🎯\",\"description\":\"Aim for specific body parts.\"},\"nonlethal\":{\"display_name\":\"Knock Out\",\"icon\":\"💫\",\"description\":\"Defeat without killing.\"}}','{}','[{\"name\":\"Martial Artist\",\"icon\":\"🥋\",\"description\":\"Master of hand-to-hand combat.\",\"base_hp\":110,\"base_mp\":60,\"base_atk\":12,\"base_def\":8,\"base_mo\":8,\"base_md\":6,\"base_speed\":10,\"base_luck\":5},{\"name\":\"Ki Warrior\",\"icon\":\"🔥\",\"description\":\"Channels devastating energy blasts.\",\"base_hp\":90,\"base_mp\":90,\"base_atk\":8,\"base_def\":6,\"base_mo\":14,\"base_md\":10,\"base_speed\":7,\"base_luck\":5},{\"name\":\"Speed Fighter\",\"icon\":\"💨\",\"description\":\"Too fast to hit. Strikes before you blink.\",\"base_hp\":80,\"base_mp\":50,\"base_atk\":10,\"base_def\":5,\"base_mo\":6,\"base_md\":5,\"base_speed\":16,\"base_luck\":8},{\"name\":\"Tank\",\"icon\":\"🛡️\",\"description\":\"Absorbs everything. Hits like a truck.\",\"base_hp\":150,\"base_mp\":40,\"base_atk\":13,\"base_def\":14,\"base_mo\":4,\"base_md\":8,\"base_speed\":4,\"base_luck\":3}]','[{\"name\":\"Human\",\"icon\":\"🧑\",\"description\":\"Determined fighters. Gain power through sheer will.\",\"bonus_hp\":5,\"bonus_luck\":5},{\"name\":\"Saiyan\",\"icon\":\"🦁\",\"description\":\"Born warriors. Gain power from every defeat.\",\"bonus_atk\":5,\"bonus_speed\":3,\"bonus_hp\":-5},{\"name\":\"Namekian\",\"icon\":\"🐸\",\"description\":\"Wise and regenerative. Can meditate to grow stronger.\",\"bonus_mo\":5,\"bonus_md\":5,\"bonus_hp\":10},{\"name\":\"Android\",\"icon\":\"🤖\",\"description\":\"Infinite energy. Cannot train normally — absorbs power from defeated foes.\",\"bonus_atk\":3,\"bonus_def\":3,\"bonus_speed\":3,\"bonus_mo\":-5}]','[{\"name\":\"Senzu Bean\",\"icon\":\"🫘\",\"type\":\"consumable\",\"rarity\":\"rare\",\"value\":500},{\"name\":\"Weighted Clothing\",\"icon\":\"🏋️\",\"type\":\"armor\",\"rarity\":\"uncommon\",\"value\":200,\"equip_slot\":\"body\"},{\"name\":\"Power Pole\",\"icon\":\"🏑\",\"type\":\"weapon\",\"rarity\":\"rare\",\"value\":300,\"equip_slot\":\"weapon\"},{\"name\":\"Scouter\",\"icon\":\"📡\",\"type\":\"accessory\",\"rarity\":\"uncommon\",\"value\":150,\"equip_slot\":\"amulet\"}]','[]','[{\"name\":\"Kame House Island\",\"description\":\"A small island where legendary masters train warriors.\",\"width\":15,\"height\":15,\"min_level\":1},{\"name\":\"Wasteland Arena\",\"description\":\"A barren landscape perfect for all-out battles.\",\"width\":20,\"height\":20,\"min_level\":3},{\"name\":\"King Kai\'s Planet\",\"description\":\"A tiny planet with 10x gravity. Train here to grow powerful.\",\"width\":10,\"height\":10,\"min_level\":10}]','[{\"name\":\"Master Roshi\",\"icon\":\"👴\",\"persona\":\"An ancient martial arts master. Eccentric but powerful.\",\"is_enemy\":0,\"map_id\":1,\"x\":7,\"y\":7,\"is_master\":1},{\"name\":\"Saibaman\",\"icon\":\"🌱\",\"persona\":\"A plant creature bred for combat.\",\"is_enemy\":1,\"map_id\":2,\"x\":10,\"y\":10},{\"name\":\"King Kai\",\"icon\":\"👑\",\"persona\":\"The lord of the North Galaxy. Trains the worthy.\",\"is_enemy\":0,\"map_id\":3,\"x\":5,\"y\":5,\"is_master\":1}]',NULL,'{\"enable_limb_targeting\":\"true\",\"enable_active_defense\":\"true\",\"enable_nonlethal\":\"true\",\"enable_ki_channeling\":\"true\",\"enable_fighting_styles\":\"true\",\"enable_signature_techs\":\"true\",\"enable_rp_descriptions\":\"true\",\"enable_combo_procs\":\"true\",\"enable_diminishing_returns\":\"true\",\"enable_transformations\":\"true\",\"enable_afterlife\":\"true\",\"enable_tournaments\":\"true\",\"enable_training_system\":\"true\",\"enable_spell_slots\":\"false\",\"summon_cost_type\":\"mp\",\"enable_weather_effects\":\"false\",\"enable_stealth\":\"false\",\"ki_channel_duration\":\"5\",\"ki_channel_crash_pct\":\"0.50\"}','[{\"name\":\"turtle_school\",\"label\":\"Turtle School\",\"icon\":\"🐢\",\"style_type\":\"balanced\",\"description\":\"The foundation of all martial arts.\"},{\"name\":\"crane_school\",\"label\":\"Crane School\",\"icon\":\"🦅\",\"style_type\":\"offensive\",\"description\":\"Aggressive aerial techniques.\"}]',0,0,NULL,'2026-03-18 11:07:54');
/*!40000 ALTER TABLE `game_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_terminology`
--

DROP TABLE IF EXISTS `game_terminology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_terminology` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_key` varchar(64) NOT NULL COMMENT 'internal key: hp, mp, atk, ki, alignment, etc.',
  `display_name` varchar(128) NOT NULL COMMENT 'what the players see',
  `short_name` varchar(32) DEFAULT NULL COMMENT 'abbreviated: HP, MP, ATK',
  `icon` varchar(16) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL COMMENT 'tooltip text',
  `category` varchar(32) NOT NULL DEFAULT 'general' COMMENT 'stats, combat, magic, social, meta',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_key` (`term_key`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_terminology`
--

LOCK TABLES `game_terminology` WRITE;
/*!40000 ALTER TABLE `game_terminology` DISABLE KEYS */;
INSERT INTO `game_terminology` VALUES
(1,'hp','Health Points','HP','❤️','How much damage you can take.','stats','2026-03-18 09:32:06'),
(2,'mp','Mana Points','MP','????','Resource for casting skills.','stats','2026-03-18 09:32:06'),
(3,'atk','Attack','ATK','⚔️','Physical damage power.','stats','2026-03-18 09:32:06'),
(4,'def','Defense','DEF','????️','Physical damage resistance.','stats','2026-03-18 09:32:06'),
(5,'mo','Magic Offense','MO','✨','Magical damage power.','stats','2026-03-18 09:32:06'),
(6,'md','Magic Defense','MD','????','Magical damage resistance.','stats','2026-03-18 09:32:06'),
(7,'speed','Speed','SPD','????','Turn order and dodge chance.','stats','2026-03-18 09:32:06'),
(8,'luck','Luck','LCK','????','Critical hit chance and rare drops.','stats','2026-03-18 09:32:06'),
(9,'level','Level','Lv.','⬆️','Character power tier.','stats','2026-03-18 09:32:06'),
(10,'experience','Experience','XP','????','Points toward next level.','stats','2026-03-18 09:32:06'),
(11,'gold','Gold','G','????','Currency.','stats','2026-03-18 09:32:06'),
(12,'ki','Ki','Ki','????','Inner energy for special techniques.','combat','2026-03-18 09:32:06'),
(13,'limitbreak','Limit Break','LB','⚡','Ultimate ability meter.','combat','2026-03-18 09:32:06'),
(14,'combo','Combo','CMB','????','Chain of rapid attacks.','combat','2026-03-18 09:32:06'),
(15,'crit','Critical Hit','CRIT','????','A strike that deals bonus damage.','combat','2026-03-18 09:32:06'),
(16,'dodge','Dodge','DDG','????','Evade an attack entirely.','combat','2026-03-18 09:32:06'),
(17,'block','Block','BLK','????️','Reduce incoming damage.','combat','2026-03-18 09:32:06'),
(18,'counter','Counter','CTR','↩️','Strike back after defending.','combat','2026-03-18 09:32:06'),
(19,'flee','Flee','FLE','????','Escape from battle.','combat','2026-03-18 09:32:06'),
(20,'taunt','Taunt','TNT','????','Draw enemy attention.','combat','2026-03-18 09:32:06'),
(21,'intimidate','Intimidate','INT','????️','Shake the enemy.','combat','2026-03-18 09:32:06'),
(22,'rally','Rally','RLY','????','Inspire allies.','combat','2026-03-18 09:32:06'),
(23,'stealth','Stealth','STL','????','Hide from enemies.','combat','2026-03-18 09:32:06'),
(24,'limb_targeting','Limb Targeting',NULL,'????','Target specific body parts.','systems','2026-03-18 09:32:06'),
(25,'active_defense','Active Defense',NULL,'????️','Choose how to defend each attack.','systems','2026-03-18 09:32:06'),
(26,'nonlethal','Non-Lethal',NULL,'????','Knock out instead of kill.','systems','2026-03-18 09:32:06'),
(27,'wound_system','Wound System',NULL,'????','Injuries degrade stats as limbs take damage.','systems','2026-03-18 09:32:06'),
(28,'channel_ki','Channel Ki',NULL,'????','Surge to full power temporarily.','systems','2026-03-18 09:32:06'),
(29,'spell_slots','Spell Slots',NULL,'????','Limited-use ability charges.','systems','2026-03-18 09:32:06'),
(30,'summon','Summon',NULL,'????','Call a spirit creature to fight.','systems','2026-03-18 09:32:06'),
(31,'transform','Transform',NULL,'⭐','Change form for a power boost.','systems','2026-03-18 09:32:06'),
(32,'sig_tech','Signature Technique',NULL,'⚡','Your own custom technique.','systems','2026-03-18 09:32:06'),
(33,'flavor_text','Battle Description',NULL,'????','Describe your action for a bonus.','rp','2026-03-18 09:32:06'),
(34,'narration','Battle Narration',NULL,'????','DM-style combat descriptions.','rp','2026-03-18 09:32:06'),
(35,'rp_commands','RP Commands',NULL,'????','Taunt, Intimidate, Rally.','rp','2026-03-18 09:32:06'),
(36,'alignment','Alignment',NULL,'⚖️','Moral compass: good vs evil.','social','2026-03-18 09:32:06'),
(37,'afterlife','Afterlife',NULL,'????','Where you go when you die.','meta','2026-03-18 09:32:06'),
(38,'tournament','Tournament',NULL,'????','Scheduled competitive events.','meta','2026-03-18 09:32:06'),
(39,'fighting_style','Fighting Style',NULL,'????','Martial arts with rank progression.','meta','2026-03-18 09:32:06'),
(40,'weather','Weather',NULL,'????️','Environmental combat effects.','meta','2026-03-18 09:32:06'),
(41,'boss_phase','Boss Phase',NULL,'????','Multi-stage boss encounters.','meta','2026-03-18 09:32:06');
/*!40000 ALTER TABLE `game_terminology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_titles`
--

DROP TABLE IF EXISTS `game_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_titles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `title_type` enum('prefix','suffix') NOT NULL DEFAULT 'suffix',
  `display_text` varchar(32) NOT NULL COMMENT 'e.g. "the Brave", "Shadow", "Master"',
  `color` varchar(7) DEFAULT NULL,
  `stat_bonus_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"luck":3}' CHECK (json_valid(`stat_bonus_json`)),
  `source` enum('achievement','quest','mastery','admin','transformation') NOT NULL DEFAULT 'quest',
  `source_id` int(10) unsigned DEFAULT NULL COMMENT 'achievement_id, quest_id, etc',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_titles`
--

LOCK TABLES `game_titles` WRITE;
/*!40000 ALTER TABLE `game_titles` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_tournament_history`
--

DROP TABLE IF EXISTS `game_tournament_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_tournament_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tournament_id` int(11) NOT NULL,
  `character_id` int(11) NOT NULL,
  `placement` int(11) NOT NULL COMMENT '1=winner, 2=runner-up, 3=third, etc.',
  `prize_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`prize_json`)),
  `recorded_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_char` (`character_id`),
  KEY `idx_tourney` (`tournament_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_tournament_history`
--

LOCK TABLES `game_tournament_history` WRITE;
/*!40000 ALTER TABLE `game_tournament_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_tournament_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_tournament_matches`
--

DROP TABLE IF EXISTS `game_tournament_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_tournament_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tournament_id` int(11) NOT NULL,
  `round_id` int(11) NOT NULL,
  `match_order` int(11) NOT NULL DEFAULT 0,
  `p1_char_id` int(11) DEFAULT NULL,
  `p2_char_id` int(11) DEFAULT NULL,
  `winner_char_id` int(11) DEFAULT NULL,
  `battle_id` int(11) DEFAULT NULL COMMENT 'links to game_battles for replay',
  `status` enum('pending','active','completed','bye') NOT NULL DEFAULT 'pending',
  `scheduled_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `round_id` (`round_id`),
  KEY `idx_tourney_round` (`tournament_id`,`round_id`),
  CONSTRAINT `game_tournament_matches_ibfk_1` FOREIGN KEY (`tournament_id`) REFERENCES `game_tournaments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `game_tournament_matches_ibfk_2` FOREIGN KEY (`round_id`) REFERENCES `game_tournament_rounds` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_tournament_matches`
--

LOCK TABLES `game_tournament_matches` WRITE;
/*!40000 ALTER TABLE `game_tournament_matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_tournament_matches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_tournament_participants`
--

DROP TABLE IF EXISTS `game_tournament_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_tournament_participants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tournament_id` int(11) NOT NULL,
  `character_id` int(11) NOT NULL,
  `seed` int(11) DEFAULT NULL,
  `status` enum('registered','active','eliminated','winner','withdrawn') NOT NULL DEFAULT 'registered',
  `wins` int(11) NOT NULL DEFAULT 0,
  `losses` int(11) NOT NULL DEFAULT 0,
  `registered_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tourney_char` (`tournament_id`,`character_id`),
  KEY `idx_tourney` (`tournament_id`),
  CONSTRAINT `game_tournament_participants_ibfk_1` FOREIGN KEY (`tournament_id`) REFERENCES `game_tournaments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_tournament_participants`
--

LOCK TABLES `game_tournament_participants` WRITE;
/*!40000 ALTER TABLE `game_tournament_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_tournament_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_tournament_rounds`
--

DROP TABLE IF EXISTS `game_tournament_rounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_tournament_rounds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tournament_id` int(11) NOT NULL,
  `round_number` int(11) NOT NULL,
  `round_name` varchar(64) DEFAULT NULL COMMENT 'Quarter-Finals, Semi-Finals, Finals, etc.',
  `status` enum('pending','active','completed') NOT NULL DEFAULT 'pending',
  `started_at` datetime DEFAULT NULL,
  `ended_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tourney_round` (`tournament_id`,`round_number`),
  CONSTRAINT `game_tournament_rounds_ibfk_1` FOREIGN KEY (`tournament_id`) REFERENCES `game_tournaments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_tournament_rounds`
--

LOCK TABLES `game_tournament_rounds` WRITE;
/*!40000 ALTER TABLE `game_tournament_rounds` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_tournament_rounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_tournaments`
--

DROP TABLE IF EXISTS `game_tournaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_tournaments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `arena_id` int(11) DEFAULT NULL,
  `type` enum('SINGLE_ELIM','DOUBLE_ELIM','ROUND_ROBIN','SWISS') NOT NULL DEFAULT 'SINGLE_ELIM',
  `status` enum('DRAFT','SCHEDULED','REGISTRATION','ACTIVE','COMPLETED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  `schedule_type` enum('once','weekly','biweekly','monthly','bimonthly','quarterly','yearly') NOT NULL DEFAULT 'once',
  `schedule_day` int(11) DEFAULT NULL COMMENT 'day of week (0=Sun) or day of month',
  `schedule_time` time DEFAULT '18:00:00',
  `next_occurrence` datetime DEFAULT NULL,
  `auto_create` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'auto-create next tournament on completion',
  `entry_fee` int(11) NOT NULL DEFAULT 0,
  `min_level` int(11) NOT NULL DEFAULT 1,
  `max_level` int(11) NOT NULL DEFAULT 99,
  `max_participants` int(11) NOT NULL DEFAULT 16,
  `level_matching` tinyint(1) NOT NULL DEFAULT 0,
  `force_nonlethal` tinyint(1) NOT NULL DEFAULT 1,
  `allow_sig_techs` tinyint(1) NOT NULL DEFAULT 1,
  `allow_items` tinyint(1) NOT NULL DEFAULT 0,
  `allow_ki_channeling` tinyint(1) NOT NULL DEFAULT 1,
  `heal_between_rounds` tinyint(1) NOT NULL DEFAULT 1,
  `prize_pool_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"1st":{"gold":1000,"items":[]},"2nd":{"gold":500},"3rd":{"gold":250}}' CHECK (json_valid(`prize_pool_json`)),
  `registration_start` datetime DEFAULT NULL,
  `registration_end` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `ended_at` datetime DEFAULT NULL,
  `winner_char_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_next` (`next_occurrence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_tournaments`
--

LOCK TABLES `game_tournaments` WRITE;
/*!40000 ALTER TABLE `game_tournaments` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_tournaments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_training_config`
--

DROP TABLE IF EXISTS `game_training_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_training_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `label` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `training_type` enum('self_train','spar','master_train','meditate') NOT NULL,
  `stat_gains` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`stat_gains`)),
  `stat_costs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`stat_costs`)),
  `daily_limit` int(11) NOT NULL DEFAULT 4,
  `cooldown_minutes` int(11) NOT NULL DEFAULT 0,
  `requires_partner` tinyint(1) NOT NULL DEFAULT 0,
  `requires_master` tinyint(1) NOT NULL DEFAULT 0,
  `min_level` int(11) NOT NULL DEFAULT 1,
  `weighted_clothing_bonus` float NOT NULL DEFAULT 0,
  `gravity_multiplier` tinyint(1) NOT NULL DEFAULT 0,
  `allowed_race_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`allowed_race_ids`)),
  `allowed_class_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`allowed_class_ids`)),
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_training_config`
--

LOCK TABLES `game_training_config` WRITE;
/*!40000 ALTER TABLE `game_training_config` DISABLE KEYS */;
INSERT INTO `game_training_config` VALUES
(1,'self_train','Self Training',NULL,'self_train','{\"max_hp\":0.005,\"atk\":0.003,\"def\":0.003,\"speed\":0.002}','{\"current_hp\":0.01}',4,0,0,0,1,0,0,NULL,NULL,1),
(2,'spar','Spar',NULL,'spar','{\"max_hp\":0.01,\"atk\":0.005,\"def\":0.005,\"speed\":0.004}','{\"current_hp\":0.01}',3,0,0,0,1,0,0,NULL,NULL,1),
(3,'master_train','Train Under Master',NULL,'master_train','{\"max_hp\":0.02,\"atk\":0.008,\"def\":0.008,\"mo\":0.008,\"md\":0.008,\"speed\":0.005}','{\"current_hp\":0.015}',3,0,0,0,1,0,0,NULL,NULL,1),
(4,'meditate','Meditate',NULL,'meditate','{\"max_hp\":0.003,\"mo\":0.005,\"md\":0.005,\"current_hp\":0.01}',NULL,3,0,0,0,1,0,0,NULL,NULL,1);
/*!40000 ALTER TABLE `game_training_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_transformations`
--

DROP TABLE IF EXISTS `game_transformations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_transformations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `race_id` int(11) DEFAULT NULL,
  `trigger_type` enum('manual','hp_threshold','limit_full','turn_count') NOT NULL DEFAULT 'manual',
  `trigger_value` float DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT 5,
  `stat_multipliers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`stat_multipliers`)),
  `grant_skill_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`grant_skill_ids`)),
  `remove_skill_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`remove_skill_ids`)),
  `visual_effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`visual_effects`)),
  `battle_text` text DEFAULT NULL,
  `mp_cost` int(11) NOT NULL DEFAULT 0,
  `hp_cost_pct` float NOT NULL DEFAULT 0,
  `cooldown_battles` int(11) NOT NULL DEFAULT 0,
  `level_required` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `alignment_required` enum('any','good','evil') NOT NULL DEFAULT 'any',
  `alignment_min` int(11) NOT NULL DEFAULT 0 COMMENT 'min alignment score (positive=good, negative=evil)',
  `rp_triggers_required` int(11) NOT NULL DEFAULT 0 COMMENT 'number of qualifying RP moments needed',
  `tier` int(11) NOT NULL DEFAULT 1 COMMENT 'transformation tier (SSJ1=1, SSJ2=2, etc)',
  `prerequisite_transform_id` int(10) unsigned DEFAULT NULL COMMENT 'must have unlocked this form first',
  `form_type` enum('temporary','toggle','permanent') NOT NULL DEFAULT 'temporary',
  `unlock_count` int(11) NOT NULL DEFAULT 3 COMMENT 'times triggered before becoming toggleable',
  `aura_color` varchar(7) DEFAULT NULL COMMENT 'hex color for name/aura glow',
  `quest_required_id` int(10) unsigned DEFAULT NULL COMMENT 'quest that must be completed to unlock',
  `item_required_id` int(10) unsigned DEFAULT NULL COMMENT 'consumable item needed to unlock',
  `kills_required` int(10) unsigned DEFAULT 0 COMMENT 'total kills needed',
  `deaths_required` int(10) unsigned DEFAULT 0 COMMENT 'times died — near-death unlocks',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_transformations`
--

LOCK TABLES `game_transformations` WRITE;
/*!40000 ALTER TABLE `game_transformations` DISABLE KEYS */;
INSERT INTO `game_transformations` VALUES
(1,'Berserker Fury','????','Sacrifice defense for overwhelming attack power.',NULL,NULL,'manual',NULL,5,'{\"atk\":1.5,\"speed\":1.3,\"def\":0.7}',NULL,NULL,NULL,'{name} roars with primal fury!',0,0,0,5,1,'any',0,0,1,NULL,'temporary',3,NULL,NULL,NULL,0,0),
(2,'Fae Form','????','Channel the Otherworld.',NULL,NULL,'manual',NULL,4,'{\"mo\":1.6,\"md\":1.4,\"speed\":1.2,\"atk\":0.6,\"def\":0.5}',NULL,NULL,NULL,'{name} becomes half-light — the Fae Form awakens!',0,0,0,10,1,'any',0,0,1,NULL,'temporary',3,NULL,NULL,NULL,0,0),
(3,'Stone Skin','????','Become nearly invulnerable but unable to move.',NULL,NULL,'manual',NULL,3,'{\"def\":2.0,\"md\":1.5,\"speed\":0.3,\"atk\":0.8}',NULL,NULL,NULL,'{name}\'s skin hardens to living stone!',0,0,0,8,1,'any',0,0,1,NULL,'temporary',3,NULL,NULL,NULL,0,0);
/*!40000 ALTER TABLE `game_transformations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_weapon_triangle`
--

DROP TABLE IF EXISTS `game_weapon_triangle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_weapon_triangle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weapon_type_a` varchar(32) NOT NULL,
  `beats` varchar(32) NOT NULL,
  `bonus_damage` float NOT NULL DEFAULT 0.15,
  `bonus_accuracy` float NOT NULL DEFAULT 0.1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_triangle` (`weapon_type_a`,`beats`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_weapon_triangle`
--

LOCK TABLES `game_weapon_triangle` WRITE;
/*!40000 ALTER TABLE `game_weapon_triangle` DISABLE KEYS */;
INSERT INTO `game_weapon_triangle` VALUES
(1,'sword','axe',0.15,0.1),
(2,'axe','lance',0.15,0.1),
(3,'lance','sword',0.15,0.1),
(4,'bow','staff',0.1,0.15),
(5,'staff','dagger',0.1,0.15),
(6,'dagger','bow',0.1,0.15);
/*!40000 ALTER TABLE `game_weapon_triangle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_weather_effects`
--

DROP TABLE IF EXISTS `game_weather_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_weather_effects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `label` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `combat_effects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`combat_effects`)),
  `terrain_override` varchar(32) DEFAULT NULL,
  `visibility` float NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_weather_effects`
--

LOCK TABLES `game_weather_effects` WRITE;
/*!40000 ALTER TABLE `game_weather_effects` DISABLE KEYS */;
INSERT INTO `game_weather_effects` VALUES
(1,'clear','Clear Skies','☀️',NULL,'{}',NULL,1,1),
(2,'rain','Rain','????️',NULL,'{\"fire_damage\":-0.30,\"lightning_damage\":0.20,\"ranged_accuracy\":-0.05}',NULL,0.8,1),
(3,'storm','Thunderstorm','⛈️',NULL,'{\"lightning_damage\":0.30,\"ranged_accuracy\":-0.15,\"fire_damage\":-0.20}',NULL,0.6,1),
(4,'fog','Dense Fog','????️',NULL,'{\"ranged_accuracy\":-0.25,\"dodge_bonus\":0.10}',NULL,0.4,1),
(5,'snow','Snowfall','❄️',NULL,'{\"ice_damage\":0.20,\"speed\":-0.10,\"fire_damage\":-0.10}',NULL,0.7,1),
(6,'sandstorm','Sandstorm','????️',NULL,'{\"earth_damage\":0.20,\"ranged_accuracy\":-0.20,\"accuracy\":-0.10}',NULL,0.3,1),
(7,'blood_moon','Blood Moon','????',NULL,'{\"dark_damage\":0.25,\"crit_bonus\":0.05,\"heal_reduction\":-0.15}',NULL,0.8,1);
/*!40000 ALTER TABLE `game_weather_effects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_win_conditions`
--

DROP TABLE IF EXISTS `game_win_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_win_conditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `condition_type` varchar(32) NOT NULL DEFAULT 'kill_all',
  `params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`params`)),
  `description` varchar(255) DEFAULT NULL,
  `success_text` varchar(255) DEFAULT NULL,
  `fail_text` varchar(255) DEFAULT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_win_conditions`
--

LOCK TABLES `game_win_conditions` WRITE;
/*!40000 ALTER TABLE `game_win_conditions` DISABLE KEYS */;
INSERT INTO `game_win_conditions` VALUES
(1,'Standard Battle','kill_all','{}','Defeat all enemies.','Victory!','Defeat.',NULL,'2026-03-18 09:50:19');
/*!40000 ALTER TABLE `game_win_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_world_events`
--

DROP TABLE IF EXISTS `game_world_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_world_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(8) DEFAULT '⚡',
  `event_type` enum('timed','flag_triggered','manual') NOT NULL DEFAULT 'timed',
  `trigger_flag` varchar(64) DEFAULT NULL COMMENT 'world flag that activates this event',
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `duration_minutes` int(11) DEFAULT 60,
  `affected_regions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '[1,2,3] or null for all' CHECK (json_valid(`affected_regions`)),
  `stat_modifiers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '{"enemy_atk_mult":1.5}' CHECK (json_valid(`stat_modifiers`)),
  `lore_text` text DEFAULT NULL COMMENT 'shown to players',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `recurring` tinyint(1) NOT NULL DEFAULT 0,
  `recur_interval_hours` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_world_events`
--

LOCK TABLES `game_world_events` WRITE;
/*!40000 ALTER TABLE `game_world_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_world_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_notes`
--

DROP TABLE IF EXISTS `gm_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gm_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `map_id` int(10) unsigned DEFAULT NULL,
  `author_id` int(10) unsigned NOT NULL,
  `author` varchar(64) NOT NULL,
  `body` text NOT NULL,
  `pinned` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gmnotes_map` (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_notes`
--

LOCK TABLES `gm_notes` WRITE;
/*!40000 ALTER TABLE `gm_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_items`
--

DROP TABLE IF EXISTS `guild_bank_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guild_bank_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guild_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `deposited_by` int(10) unsigned NOT NULL COMMENT 'character_id who deposited',
  `deposited_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `note` varchar(256) DEFAULT NULL COMMENT 'Optional note from depositor',
  PRIMARY KEY (`id`),
  KEY `idx_gbi_guild` (`guild_id`),
  KEY `idx_gbi_item` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_items`
--

LOCK TABLES `guild_bank_items` WRITE;
/*!40000 ALTER TABLE `guild_bank_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_log`
--

DROP TABLE IF EXISTS `guild_bank_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guild_bank_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guild_id` int(10) unsigned NOT NULL,
  `character_id` int(10) unsigned NOT NULL,
  `character_name` varchar(64) NOT NULL,
  `action` enum('deposit_gold','withdraw_gold','deposit_item','withdraw_item') NOT NULL,
  `amount` int(11) DEFAULT NULL COMMENT 'Gold amount for gold actions',
  `item_id` int(10) unsigned DEFAULT NULL COMMENT 'Item for item actions',
  `item_qty` int(10) unsigned DEFAULT NULL,
  `item_name` varchar(128) DEFAULT NULL,
  `note` varchar(256) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gbl_guild` (`guild_id`),
  KEY `idx_gbl_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_log`
--

LOCK TABLES `guild_bank_log` WRITE;
/*!40000 ALTER TABLE `guild_bank_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_perms`
--

DROP TABLE IF EXISTS `guild_bank_perms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guild_bank_perms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guild_id` int(10) unsigned NOT NULL,
  `rank` enum('LEADER','OFFICER','MEMBER') NOT NULL DEFAULT 'MEMBER',
  `can_deposit_gold` tinyint(1) NOT NULL DEFAULT 1,
  `can_withdraw_gold` tinyint(1) NOT NULL DEFAULT 0,
  `can_deposit_item` tinyint(1) NOT NULL DEFAULT 1,
  `can_withdraw_item` tinyint(1) NOT NULL DEFAULT 0,
  `gold_withdraw_limit` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Max gold per day. 0=unlimited',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_gp_guild_rank` (`guild_id`,`rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_perms`
--

LOCK TABLES `guild_bank_perms` WRITE;
/*!40000 ALTER TABLE `guild_bank_perms` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_perms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_invites`
--

DROP TABLE IF EXISTS `guild_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guild_invites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guild_id` int(10) unsigned NOT NULL,
  `inviter_id` int(10) unsigned NOT NULL,
  `invitee_id` int(10) unsigned NOT NULL,
  `status` enum('pending','accepted','declined','expired') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NOT NULL DEFAULT (current_timestamp() + interval 48 hour),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_guild_invite` (`guild_id`,`invitee_id`),
  KEY `idx_invites_invitee` (`invitee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_invites`
--

LOCK TABLES `guild_invites` WRITE;
/*!40000 ALTER TABLE `guild_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_members`
--

DROP TABLE IF EXISTS `guild_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guild_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guild_id` int(10) unsigned NOT NULL,
  `character_id` int(10) unsigned NOT NULL,
  `rank` enum('LEADER','OFFICER','MEMBER') NOT NULL DEFAULT 'MEMBER',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `left_at` timestamp NULL DEFAULT NULL,
  `contribution` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_guild_char` (`guild_id`,`character_id`),
  KEY `idx_guild_members_char` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_members`
--

LOCK TABLES `guild_members` WRITE;
/*!40000 ALTER TABLE `guild_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_news`
--

DROP TABLE IF EXISTS `guild_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guild_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guild_id` int(10) unsigned NOT NULL,
  `author_char_id` int(10) unsigned DEFAULT NULL COMMENT 'NULL for system-generated posts',
  `author_name` varchar(64) NOT NULL DEFAULT 'System',
  `title` varchar(128) NOT NULL,
  `body` text NOT NULL COMMENT 'BBCode content',
  `body_html` text NOT NULL COMMENT 'Pre-parsed safe HTML',
  `category` enum('announcement','event','bank','achievement','system') NOT NULL DEFAULT 'announcement',
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gn_guild` (`guild_id`),
  KEY `idx_gn_pinned` (`guild_id`,`is_pinned`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_news`
--

LOCK TABLES `guild_news` WRITE;
/*!40000 ALTER TABLE `guild_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guilds`
--

DROP TABLE IF EXISTS `guilds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guilds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `tag` varchar(6) NOT NULL,
  `description` text DEFAULT NULL,
  `emblem` varchar(8) DEFAULT '⚔️',
  `leader_id` int(10) unsigned NOT NULL,
  `level` int(11) NOT NULL DEFAULT 1,
  `xp` int(11) NOT NULL DEFAULT 0,
  `gold_bank` int(11) NOT NULL DEFAULT 0,
  `motd` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `disbanded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_guilds_leader` (`leader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guilds`
--

LOCK TABLES `guilds` WRITE;
/*!40000 ALTER TABLE `guilds` DISABLE KEYS */;
/*!40000 ALTER TABLE `guilds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legendary_artifacts`
--

DROP TABLE IF EXISTS `legendary_artifacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `legendary_artifacts` (
  `artifact_id` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(40) NOT NULL,
  `rarity` enum('legendary','mythic','cosmic') NOT NULL DEFAULT 'legendary',
  `theme` varchar(60) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `current_wielder_id` int(10) unsigned DEFAULT NULL,
  `total_kills` int(11) NOT NULL DEFAULT 0,
  `kill_streak` int(11) NOT NULL DEFAULT 0,
  `power_multiplier` decimal(6,2) NOT NULL DEFAULT 1.00,
  `decay_rate` decimal(6,2) NOT NULL DEFAULT 0.02,
  `last_bloodshed_at` datetime DEFAULT NULL,
  `last_transfer_at` datetime DEFAULT NULL,
  `is_dormant` tinyint(1) NOT NULL DEFAULT 0,
  `active_curses_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`active_curses_json`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`artifact_id`),
  KEY `idx_artifacts_wielder` (`current_wielder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legendary_artifacts`
--

LOCK TABLES `legendary_artifacts` WRITE;
/*!40000 ALTER TABLE `legendary_artifacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `legendary_artifacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `level_requirements`
--

DROP TABLE IF EXISTS `level_requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `level_requirements` (
  `level` int(10) unsigned NOT NULL,
  `xp_required` int(10) unsigned NOT NULL,
  `total_xp` int(10) unsigned NOT NULL,
  PRIMARY KEY (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `level_requirements`
--

LOCK TABLES `level_requirements` WRITE;
/*!40000 ALTER TABLE `level_requirements` DISABLE KEYS */;
INSERT INTO `level_requirements` VALUES
(1,0,0),
(2,200,200),
(3,457,657),
(4,779,1436),
(5,1172,2608),
(6,1637,4245),
(7,2174,6419),
(8,2785,9204),
(9,3468,12672),
(10,4225,16897),
(11,5055,21952),
(12,5957,27909),
(13,6932,34841),
(14,7979,42820),
(15,9098,51918),
(16,10289,62207),
(17,11551,73758),
(18,12884,86642),
(19,14287,100929),
(20,15761,116690),
(21,17305,133995),
(22,18919,152914),
(23,20602,173516),
(24,22353,195869),
(25,24173,220042),
(26,26061,246103),
(27,28017,274120),
(28,30040,304160),
(29,32130,336290),
(30,34286,370576),
(31,36508,407084),
(32,38796,445880),
(33,41148,487028),
(34,43566,530594),
(35,46048,576642),
(36,48595,625237),
(37,51204,676441),
(38,53877,730318),
(39,56613,786931),
(40,59411,846342),
(41,62271,908613),
(42,65193,973806),
(43,68176,1041982),
(44,71220,1113202),
(45,74325,1187527),
(46,77491,1265018),
(47,80717,1345735),
(48,84002,1429737),
(49,87348,1517085),
(50,90752,1607837),
(51,100000,1707837),
(52,110000,1817837),
(53,121000,1938837),
(54,133100,2071937),
(55,146410,2218347),
(56,161051,2379398),
(57,177156,2556554),
(58,194871,2751425),
(59,214358,2965783),
(60,999999,3965782);
/*!40000 ALTER TABLE `level_requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lfp_listings`
--

DROP TABLE IF EXISTS `lfp_listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lfp_listings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(10) unsigned NOT NULL,
  `character_name` varchar(64) NOT NULL,
  `level` int(10) unsigned NOT NULL,
  `class_name` varchar(64) NOT NULL,
  `role` enum('DPS','Tank','Healer','Support','Any') NOT NULL DEFAULT 'Any',
  `note` varchar(255) DEFAULT NULL COMMENT 'What they are looking for',
  `content_type` varchar(64) DEFAULT NULL COMMENT 'e.g. Dungeons, PvP, Quests, Guild',
  `expires_at` timestamp NOT NULL DEFAULT (current_timestamp() + interval 4 hour),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `character_id` (`character_id`),
  KEY `idx_lfp_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lfp_listings`
--

LOCK TABLES `lfp_listings` WRITE;
/*!40000 ALTER TABLE `lfp_listings` DISABLE KEYS */;
/*!40000 ALTER TABLE `lfp_listings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npc_factions`
--

DROP TABLE IF EXISTS `npc_factions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `npc_factions` (
  `npc_id` int(10) unsigned NOT NULL,
  `faction_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`npc_id`,`faction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `npc_factions`
--

LOCK TABLES `npc_factions` WRITE;
/*!40000 ALTER TABLE `npc_factions` DISABLE KEYS */;
/*!40000 ALTER TABLE `npc_factions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npc_memories`
--

DROP TABLE IF EXISTS `npc_memories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `npc_memories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `npc_name` varchar(128) NOT NULL,
  `facts_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`facts_json`)),
  `reputation` int(11) NOT NULL DEFAULT 0,
  `last_seen` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_mem` (`char_id`,`npc_name`),
  KEY `idx_mem_char` (`char_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `npc_memories`
--

LOCK TABLES `npc_memories` WRITE;
/*!40000 ALTER TABLE `npc_memories` DISABLE KEYS */;
/*!40000 ALTER TABLE `npc_memories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npc_rumors`
--

DROP TABLE IF EXISTS `npc_rumors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `npc_rumors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `char_name` varchar(128) NOT NULL,
  `rumor_text` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `spread_count` int(11) NOT NULL DEFAULT 0,
  `max_spread` int(11) NOT NULL DEFAULT 8,
  PRIMARY KEY (`id`),
  KEY `idx_rumors_char` (`char_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `npc_rumors`
--

LOCK TABLES `npc_rumors` WRITE;
/*!40000 ALTER TABLE `npc_rumors` DISABLE KEYS */;
/*!40000 ALTER TABLE `npc_rumors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_appeals`
--

DROP TABLE IF EXISTS `player_appeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_appeals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `username` varchar(64) NOT NULL,
  `appeal_text` text NOT NULL,
  `status` enum('pending','accepted','denied') NOT NULL DEFAULT 'pending',
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `review_notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `reviewed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_appeals`
--

LOCK TABLES `player_appeals` WRITE;
/*!40000 ALTER TABLE `player_appeals` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_appeals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_faction_rep`
--

DROP TABLE IF EXISTS `player_faction_rep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_faction_rep` (
  `char_id` int(10) unsigned NOT NULL,
  `faction_id` int(10) unsigned NOT NULL,
  `reputation` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`char_id`,`faction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_faction_rep`
--

LOCK TABLES `player_faction_rep` WRITE;
/*!40000 ALTER TABLE `player_faction_rep` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_faction_rep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_reports`
--

DROP TABLE IF EXISTS `player_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reporter_char_id` int(10) unsigned NOT NULL,
  `reporter_name` varchar(64) NOT NULL,
  `reported_char_id` int(10) unsigned NOT NULL,
  `reported_name` varchar(64) NOT NULL,
  `reason` enum('harassment','cheating','spam','offensive_name','bug_abuse','other') NOT NULL,
  `details` varchar(500) DEFAULT NULL,
  `status` enum('open','reviewed','dismissed','actioned') NOT NULL DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_reported` (`reported_char_id`),
  KEY `idx_reports_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_reports`
--

LOCK TABLES `player_reports` WRITE;
/*!40000 ALTER TABLE `player_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_warnings`
--

DROP TABLE IF EXISTS `player_warnings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_warnings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `warned_by` int(10) unsigned NOT NULL,
  `warned_by_name` varchar(64) NOT NULL,
  `warning_level` int(11) NOT NULL DEFAULT 1,
  `reason` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_warnings`
--

LOCK TABLES `player_warnings` WRITE;
/*!40000 ALTER TABLE `player_warnings` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_warnings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_guestbook`
--

DROP TABLE IF EXISTS `profile_guestbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile_guestbook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profile_char_id` int(10) unsigned NOT NULL COMMENT 'Whose profile this comment is on',
  `author_char_id` int(10) unsigned NOT NULL COMMENT 'Who wrote it',
  `author_name` varchar(64) NOT NULL COMMENT 'Name at time of posting (denormalized)',
  `author_title` varchar(64) DEFAULT NULL COMMENT 'Title at time of posting',
  `author_color` varchar(7) DEFAULT NULL COMMENT 'Accent color at time of posting',
  `message` text NOT NULL COMMENT 'BBCode-lite content',
  `message_html` text NOT NULL COMMENT 'Pre-parsed safe HTML',
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gb_profile` (`profile_char_id`),
  KEY `idx_gb_author` (`author_char_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_guestbook`
--

LOCK TABLES `profile_guestbook` WRITE;
/*!40000 ALTER TABLE `profile_guestbook` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile_guestbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_viewers`
--

DROP TABLE IF EXISTS `profile_viewers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile_viewers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profile_char_id` int(10) unsigned NOT NULL,
  `viewer_char_id` int(10) unsigned NOT NULL,
  `viewer_name` varchar(64) NOT NULL,
  `viewer_color` varchar(7) DEFAULT NULL,
  `viewer_title` varchar(64) DEFAULT NULL,
  `viewed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_view` (`profile_char_id`,`viewer_char_id`),
  KEY `idx_pv_profile` (`profile_char_id`),
  KEY `idx_pv_viewed` (`viewed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_viewers`
--

LOCK TABLES `profile_viewers` WRITE;
/*!40000 ALTER TABLE `profile_viewers` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile_viewers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `progression_config`
--

DROP TABLE IF EXISTS `progression_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `progression_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key_name` varchar(64) NOT NULL,
  `value_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`value_json`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `progression_config`
--

LOCK TABLES `progression_config` WRITE;
/*!40000 ALTER TABLE `progression_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `progression_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quest_definitions`
--

DROP TABLE IF EXISTS `quest_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quest_definitions` (
  `quest_id` varchar(64) NOT NULL,
  `title` varchar(120) NOT NULL,
  `description` text DEFAULT NULL,
  `quest_type` varchar(40) NOT NULL DEFAULT 'side',
  `category` varchar(60) DEFAULT NULL,
  `required_level` int(11) NOT NULL DEFAULT 1,
  `is_repeatable` tinyint(1) NOT NULL DEFAULT 0,
  `repeat_cooldown_hours` int(11) NOT NULL DEFAULT 0,
  `max_completions` int(11) DEFAULT NULL,
  `objectives_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`objectives_json`)),
  `rewards_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`rewards_json`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `condition_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'e.g. {"min_region_danger":2, "requires_flags":["siege_active"], "region_id":3}' CHECK (json_valid(`condition_json`)),
  `region_id` int(10) unsigned DEFAULT NULL COMMENT 'If set, quest is only offered by NPCs in this region',
  PRIMARY KEY (`quest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quest_definitions`
--

LOCK TABLES `quest_definitions` WRITE;
/*!40000 ALTER TABLE `quest_definitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `quest_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int(11) unsigned NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('0y6kJGao1tkz8kxQacVIkYhSSohWNQwv',1774847875,'{\"cookie\":{\"originalMaxAge\":604800000,\"expires\":\"2026-03-26T04:44:23.446Z\",\"secure\":true,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"userId\":1,\"username\":\"Admin\",\"role\":\"OWNER\"}'),
('SbRrNmJOO6iOKVFJMzZ8EvcT1t9zMUmQ',1774901845,'{\"cookie\":{\"originalMaxAge\":604800000,\"expires\":\"2026-03-25T22:04:43.302Z\",\"secure\":true,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"userId\":1,\"username\":\"Admin\",\"role\":\"OWNER\"}'),
('ZYJryTj55lVbraxBOXY2GH6Gba0tCqu6',1774854189,'{\"cookie\":{\"originalMaxAge\":604800000,\"expires\":\"2026-03-26T09:58:53.842Z\",\"secure\":true,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"userId\":1,\"username\":\"Admin\",\"role\":\"OWNER\"}'),
('cvSuxF0Mb9tmMRWMhYaCPU9gJWuGuMHl',1774996094,'{\"cookie\":{\"originalMaxAge\":604800000,\"expires\":\"2026-03-26T13:25:19.752Z\",\"secure\":true,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"userId\":1,\"username\":\"Admin\",\"role\":\"OWNER\"}'),
('jhmNGuIGXiWbE77jCTpaRkvyYu7PuTz9',1774427728,'{\"cookie\":{\"originalMaxAge\":604800000,\"expires\":\"2026-03-25T08:28:19.728Z\",\"secure\":true,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"userId\":4,\"username\":\"zergsliver\",\"role\":\"PLAYER\"}'),
('yivaPi59ZSdL8nVcqvQjamD2lCyuQovK',1774427176,'{\"cookie\":{\"originalMaxAge\":604800000,\"expires\":\"2026-03-25T08:24:23.604Z\",\"secure\":true,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"userId\":4,\"username\":\"zergsliver\",\"role\":\"PLAYER\"}'),
('zQBqnI50RLTCKgFPjCzilQYCnUwJrDum',1774903693,'{\"cookie\":{\"originalMaxAge\":604800000,\"expires\":\"2026-03-26T09:30:48.834Z\",\"secure\":true,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"userId\":5,\"username\":\"AllenSam\",\"role\":\"ADMIN\"}');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings_change_log`
--

DROP TABLE IF EXISTS `settings_change_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_change_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(128) NOT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `changed_by` int(10) unsigned DEFAULT NULL,
  `changed_by_name` varchar(64) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_key` (`setting_key`),
  KEY `idx_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings_change_log`
--

LOCK TABLES `settings_change_log` WRITE;
/*!40000 ALTER TABLE `settings_change_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings_change_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_activity_log`
--

DROP TABLE IF EXISTS `staff_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `username` varchar(64) NOT NULL,
  `action_type` varchar(32) NOT NULL COMMENT 'ban, give_gold, edit_npc, etc',
  `detail` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_activity_log`
--

LOCK TABLES `staff_activity_log` WRITE;
/*!40000 ALTER TABLE `staff_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_audit_log`
--

DROP TABLE IF EXISTS `staff_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `username` varchar(64) NOT NULL,
  `action` varchar(64) NOT NULL,
  `entity_type` varchar(32) DEFAULT NULL,
  `entity_id` varchar(64) DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_audit_log`
--

LOCK TABLES `staff_audit_log` WRITE;
/*!40000 ALTER TABLE `staff_audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_broadcast_templates`
--

DROP TABLE IF EXISTS `staff_broadcast_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_broadcast_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `template_text` text NOT NULL COMMENT 'Server restart in {minutes} minutes',
  `style` enum('info','warning','danger') NOT NULL DEFAULT 'info',
  `variables_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '["minutes","event_name"]' CHECK (json_valid(`variables_json`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_broadcast_templates`
--

LOCK TABLES `staff_broadcast_templates` WRITE;
/*!40000 ALTER TABLE `staff_broadcast_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_broadcast_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_messages`
--

DROP TABLE IF EXISTS `staff_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(10) unsigned NOT NULL,
  `sender_name` varchar(64) NOT NULL,
  `sender_role` varchar(16) NOT NULL DEFAULT 'STAFF',
  `channel` varchar(32) NOT NULL DEFAULT 'general',
  `body` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_channel_created` (`channel`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_messages`
--

LOCK TABLES `staff_messages` WRITE;
/*!40000 ALTER TABLE `staff_messages` DISABLE KEYS */;
INSERT INTO `staff_messages` VALUES
(1,1,'Admin','OWNER','dm:1:5','Hey bud','2026-03-19 11:13:15');
/*!40000 ALTER TABLE `staff_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_permissions`
--

DROP TABLE IF EXISTS `staff_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role` varchar(16) NOT NULL,
  `permission_key` varchar(64) NOT NULL,
  `allowed` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_perm` (`role`,`permission_key`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_permissions`
--

LOCK TABLES `staff_permissions` WRITE;
/*!40000 ALTER TABLE `staff_permissions` DISABLE KEYS */;
INSERT INTO `staff_permissions` VALUES
(1,'ADMIN','ban',1),
(2,'OWNER','ban',1),
(3,'GM','ban',1),
(4,'MOD','ban',1),
(5,'ADMIN','unban',1),
(6,'OWNER','unban',1),
(7,'GM','unban',1),
(8,'MOD','unban',1),
(9,'ADMIN','kick',1),
(10,'OWNER','kick',1),
(11,'GM','kick',1),
(12,'MOD','kick',1),
(13,'ADMIN','give_gold',1),
(14,'OWNER','give_gold',1),
(15,'GM','give_gold',1),
(16,'MOD','give_gold',0),
(17,'ADMIN','give_item',1),
(18,'OWNER','give_item',1),
(19,'GM','give_item',1),
(20,'MOD','give_item',0),
(21,'ADMIN','edit_npc',1),
(22,'OWNER','edit_npc',1),
(23,'GM','edit_npc',1),
(24,'MOD','edit_npc',0),
(25,'ADMIN','edit_map',1),
(26,'OWNER','edit_map',1),
(27,'GM','edit_map',1),
(28,'MOD','edit_map',0),
(29,'ADMIN','edit_quest',1),
(30,'OWNER','edit_quest',1),
(31,'GM','edit_quest',1),
(32,'MOD','edit_quest',0),
(33,'ADMIN','change_role',1),
(34,'OWNER','change_role',1),
(35,'GM','change_role',0),
(36,'MOD','change_role',0),
(37,'ADMIN','delete_char',1),
(38,'OWNER','delete_char',1),
(39,'GM','delete_char',0),
(40,'MOD','delete_char',0),
(41,'ADMIN','server_announce',1),
(42,'OWNER','server_announce',1),
(43,'GM','server_announce',1),
(44,'MOD','server_announce',0),
(45,'ADMIN','edit_settings',1),
(46,'OWNER','edit_settings',1),
(47,'GM','edit_settings',0),
(48,'MOD','edit_settings',0),
(49,'ADMIN','install_template',1),
(50,'OWNER','install_template',1),
(51,'GM','install_template',0),
(52,'MOD','install_template',0);
/*!40000 ALTER TABLE `staff_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_shift_notes`
--

DROP TABLE IF EXISTS `staff_shift_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_shift_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(10) unsigned NOT NULL,
  `author_name` varchar(64) NOT NULL,
  `body` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_shift_notes`
--

LOCK TABLES `staff_shift_notes` WRITE;
/*!40000 ALTER TABLE `staff_shift_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_shift_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `setting_key` varchar(128) NOT NULL,
  `setting_value` varchar(512) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES
('ability_point_budget','27',NULL,'2026-03-19 00:42:28'),
('action_command_show_timing','true',NULL,'2026-03-18 11:33:44'),
('active_template','celtic_fantasy',NULL,'2026-03-18 11:07:53'),
('aggro_decay_per_turn','10',NULL,'2026-03-19 08:21:57'),
('ai_api_key','AIzaSyDnl63Qt8nDee9wnk5nu8QXEzrx1PBIyr0','API key for Gemini, Anthropic, or OpenAI. Store securely.','2026-03-17 11:52:05'),
('ai_base_url','','Base URL for Ollama or OpenAI-compatible endpoints','2026-03-15 19:50:10'),
('ai_max_tokens','300','Max tokens per NPC reply. 256 = 1-3 sentences.','2026-03-17 11:52:05'),
('ai_model','gemini-2.0-flash','Model name override. Leave blank to use provider default.','2026-03-17 12:26:19'),
('ai_provider','gemini','NPC AI provider: disabled | gemini | anthropic | openai | ollama','2026-03-17 11:52:05'),
('ai_system_prompt','','World context injected into every NPC prompt. Blank = Celtic dark fantasy default.','2026-03-15 19:50:10'),
('ai_temperature','0.85','AI creativity 0.0 (robotic) to 1.0 (chaotic). 0.85 recommended.','2026-03-15 19:50:10'),
('alignment_affects_shops','true',NULL,'2026-03-18 09:32:21'),
('alignment_affects_skills','true',NULL,'2026-03-18 09:32:21'),
('alignment_affects_stats','true',NULL,'2026-03-18 09:32:21'),
('alignment_max','100',NULL,'2026-03-18 09:32:21'),
('alignment_min','-100',NULL,'2026-03-18 09:32:21'),
('allowed_audio_types','audio/mpeg,audio/ogg,audio/wav',NULL,'2026-03-18 12:23:38'),
('allowed_image_types','image/png,image/gif,image/webp,image/jpeg',NULL,'2026-03-18 12:23:38'),
('allow_player_speed_toggle','true',NULL,'2026-03-19 08:06:37'),
('auction_duration_hours','48','Default listing duration in hours','2026-03-15 19:50:10'),
('auction_enabled','true','Enable the auction house','2026-03-15 19:50:10'),
('auction_listing_fee_pct','5','Percentage of buyout price charged to list an item (non-refundable)','2026-03-15 19:50:10'),
('auction_max_listings','10','Max active listings per character','2026-03-15 19:50:10'),
('auction_sale_tax_pct','5','Percentage taken from sale price when item sells','2026-03-15 19:50:10'),
('auto_battle_disable_in_boss','true',NULL,'2026-03-19 08:06:37'),
('auto_battle_disable_in_pvp','true',NULL,'2026-03-19 08:06:37'),
('back_row_damage_reduction','30',NULL,'2026-03-19 08:06:37'),
('back_row_melee_penalty','50',NULL,'2026-03-19 08:06:37'),
('baton_pass_damage_bonus','0.25',NULL,'2026-03-18 11:48:28'),
('battle_turn_delay_ms','1000',NULL,'2026-03-19 08:06:37'),
('beam_clash_damage_mult','3.0',NULL,'2026-03-19 08:21:57'),
('beam_clash_formula','ATK+1d20',NULL,'2026-03-19 08:21:57'),
('block_die_sides','6',NULL,'2026-03-18 09:36:54'),
('block_one_arm_reduction','0.25',NULL,'2026-03-18 09:36:54'),
('block_stun_die_sides','12',NULL,'2026-03-18 09:36:54'),
('block_success_numbers','[1,2]',NULL,'2026-03-18 09:36:54'),
('block_two_arm_reduction','0.50',NULL,'2026-03-18 09:36:54'),
('break_damage_bonus','0.50',NULL,'2026-03-18 11:48:28'),
('break_stun_turns','1',NULL,'2026-03-18 11:48:28'),
('called_shot_penalty_arms','0.10',NULL,'2026-03-18 09:36:54'),
('called_shot_penalty_head','0.20',NULL,'2026-03-18 09:36:54'),
('called_shot_penalty_legs','0.10',NULL,'2026-03-18 09:36:54'),
('combo_ap_regen_per_turn','3',NULL,'2026-03-18 11:33:44'),
('combo_chain_decay','0.50',NULL,'2026-03-18 09:32:21'),
('combo_crit_chance','0.03',NULL,'2026-03-18 09:32:21'),
('combo_individual_hit_damage','0.5',NULL,'2026-03-18 11:33:44'),
('combo_miss_on_wrong_input','false',NULL,'2026-03-18 11:33:44'),
('counter_base_chance','0.25',NULL,'2026-03-18 09:36:54'),
('counter_charge_bonus','0.25',NULL,'2026-03-18 09:36:54'),
('counter_dex_scaling','0.5',NULL,'2026-03-19 08:06:37'),
('counter_max_chance','0.90',NULL,'2026-03-18 09:36:54'),
('defense_prompt_timeout_ms','10000',NULL,'2026-03-18 09:36:54'),
('dice_attack_formula','1d20+ATK',NULL,'2026-03-19 08:21:57'),
('dice_crit_threshold','18',NULL,'2026-03-19 08:21:57'),
('dice_defense_formula','1d20+DEF',NULL,'2026-03-19 08:21:57'),
('dice_dodge_formula','1d20+SPEED',NULL,'2026-03-19 08:21:57'),
('dice_show_rolls_in_chat','true',NULL,'2026-03-19 08:21:57'),
('diminishing_returns_max','0.15',NULL,'2026-03-18 09:36:54'),
('diminishing_returns_per_repeat','0.05',NULL,'2026-03-18 09:36:54'),
('dodge_base_chance','0.15',NULL,'2026-03-18 09:36:54'),
('dodge_max_chance','0.90',NULL,'2026-03-18 09:36:54'),
('dodge_speed_factor','0.35',NULL,'2026-03-18 09:36:54'),
('dual_class_enabled','false',NULL,'2026-03-19 07:00:49'),
('dual_class_level','20',NULL,'2026-03-19 07:00:49'),
('dual_class_skill_penalty','30',NULL,'2026-03-19 07:00:49'),
('enable_action_commands','true',NULL,'2026-03-18 11:33:44'),
('enable_active_defense','true',NULL,'2026-03-18 09:36:54'),
('enable_advantage_system','true',NULL,'2026-03-18 11:48:28'),
('enable_aggro_system','false',NULL,'2026-03-19 08:21:57'),
('enable_alignment_system','true',NULL,'2026-03-18 09:32:21'),
('enable_autotiling','true',NULL,'2026-03-18 13:23:09'),
('enable_auto_battle','true',NULL,'2026-03-19 08:06:37'),
('enable_backgrounds','true','Show background selection on character creation','2026-03-15 19:50:09'),
('enable_battle_rules','true',NULL,'2026-03-18 09:32:21'),
('enable_beam_clash','false',NULL,'2026-03-19 08:21:57'),
('enable_break_shield','true',NULL,'2026-03-18 11:48:28'),
('enable_called_shot_penalty','true',NULL,'2026-03-18 09:36:54'),
('enable_combo_input','true',NULL,'2026-03-18 11:33:44'),
('enable_combo_procs','true',NULL,'2026-03-18 09:32:21'),
('enable_counter_attacks','true',NULL,'2026-03-19 08:06:37'),
('enable_custom_assets','true',NULL,'2026-03-18 12:23:38'),
('enable_custom_win_conditions','false',NULL,'2026-03-18 09:59:13'),
('enable_dice_rolls','false',NULL,'2026-03-19 08:21:57'),
('enable_diminishing_returns','true',NULL,'2026-03-18 09:36:54'),
('enable_feats','true','Show feat selection on character creation','2026-03-15 19:50:09'),
('enable_flavor_text','true',NULL,'2026-03-18 09:32:21'),
('enable_formations','false',NULL,'2026-03-19 08:06:37'),
('enable_greet_system','false','When true, player names are hidden until they greet each other (Planet Mado style)','2026-03-23 09:30:45'),
('enable_interrupts','false',NULL,'2026-03-19 08:30:08'),
('enable_ki_channeling','true',NULL,'2026-03-18 09:32:21'),
('enable_limb_targeting','true',NULL,'2026-03-21 10:06:12'),
('enable_magic_duels','false',NULL,'2026-03-19 09:22:21'),
('enable_mentor_system','false',NULL,'2026-03-19 08:21:57'),
('enable_nonlethal','true',NULL,'2026-03-18 09:36:54'),
('enable_one_more','true',NULL,'2026-03-18 11:48:28'),
('enable_party_swap','true',NULL,'2026-03-18 11:48:28'),
('enable_passive_abilities','true',NULL,'2026-03-18 11:48:28'),
('enable_pvp','true','Allow PvP battles between players','2026-03-15 19:50:09'),
('enable_rage_meter','false',NULL,'2026-03-19 08:06:37'),
('enable_rolling_hp','false',NULL,'2026-03-18 11:48:28'),
('enable_rp_commands','false',NULL,'2026-03-18 09:58:13'),
('enable_rp_descriptions','false',NULL,'2026-03-21 10:08:05'),
('enable_signature_techs','true',NULL,'2026-03-18 09:32:21'),
('enable_stagger_system','true',NULL,'2026-03-18 12:03:40'),
('enable_tournaments','true',NULL,'2026-03-18 09:32:21'),
('enable_turn_manipulation','true',NULL,'2026-03-18 11:48:28'),
('enable_weapon_triangle','true',NULL,'2026-03-18 11:48:28'),
('enable_wound_degradation','true',NULL,'2026-03-18 09:36:54'),
('enemy_scaling_factor','0.3',NULL,'2026-03-17 10:14:11'),
('flavor_text_base_bonus','0.05',NULL,'2026-03-18 09:32:21'),
('flavor_text_keyword_bonus','0.02',NULL,'2026-03-18 09:32:21'),
('flavor_text_keyword_max','3',NULL,'2026-03-18 09:32:21'),
('flavor_text_max_bonus','0.10',NULL,'2026-03-18 09:32:21'),
('flavor_text_min_length','20',NULL,'2026-03-18 09:32:21'),
('gold_multiplier','1','Global gold gain multiplier','2026-03-15 19:50:09'),
('interrupt_chance_formula','SPEED_DIFF*5',NULL,'2026-03-19 08:30:08'),
('interrupt_speed_threshold','5',NULL,'2026-03-19 08:30:08'),
('ki_channel_crash_pct','0.50',NULL,'2026-03-18 09:32:21'),
('ki_channel_duration','5',NULL,'2026-03-18 09:32:21'),
('ki_channel_uses_per_battle','1',NULL,'2026-03-18 09:32:21'),
('ki_equals_hp','false',NULL,'2026-03-19 08:21:57'),
('ki_label','Ki',NULL,'2026-03-19 08:21:57'),
('ki_moves_use_hp','false',NULL,'2026-03-19 08:21:57'),
('ki_ranged_dodge_bonus','0.15',NULL,'2026-03-18 09:32:21'),
('ko_interrogate_base_chance','0.60',NULL,'2026-03-18 09:36:54'),
('limb_bleed_through_default','0.60',NULL,'2026-03-18 09:36:54'),
('magic_duel_counter_spell_chance','30',NULL,'2026-03-19 09:22:21'),
('magic_duel_element_mult','2.0',NULL,'2026-03-19 09:22:21'),
('max_active_party','4',NULL,'2026-03-18 11:48:28'),
('max_characters_per_user','3','How many characters each player can create','2026-03-15 19:50:09'),
('max_guild_size','50','Maximum members in a guild','2026-03-15 19:50:09'),
('max_party_size','4','Maximum players in a party','2026-03-15 19:50:09'),
('max_passive_slots','3',NULL,'2026-03-18 11:48:28'),
('max_reserve_party','4',NULL,'2026-03-18 11:48:28'),
('max_upload_size_mb','10',NULL,'2026-03-18 12:23:38'),
('mentor_level_gap','10',NULL,'2026-03-19 08:21:57'),
('mentor_stat_scale_pct','50',NULL,'2026-03-19 08:21:57'),
('mentor_xp_bonus_pct','25',NULL,'2026-03-19 08:21:57'),
('movement_cooldown_ms','250',NULL,'2026-03-19 02:59:32'),
('movement_limit_amount','1000',NULL,'2026-03-19 02:59:32'),
('movement_limit_enabled','false',NULL,'2026-03-19 02:59:32'),
('movement_limit_type','daily',NULL,'2026-03-19 02:59:32'),
('nonlethal_rep_bonus_release','5',NULL,'2026-03-18 09:36:54'),
('nonlethal_rep_penalty_finish','-10',NULL,'2026-03-18 09:36:54'),
('npc_dialogue_mode','script_then_ai',NULL,'2026-03-19 06:14:27'),
('ogham_sockets_by_rarity','{\"common\":0,\"uncommon\":1,\"rare\":2,\"epic\":3,\"legendary\":3}',NULL,'2026-03-19 09:11:41'),
('one_more_on_crit','true',NULL,'2026-03-18 11:48:28'),
('party_swap_costs_turn','true',NULL,'2026-03-18 11:48:28'),
('rage_build_on_hit','5',NULL,'2026-03-19 08:06:37'),
('rage_build_on_take_damage','10',NULL,'2026-03-19 08:06:37'),
('rage_decay_per_turn','3',NULL,'2026-03-19 08:06:37'),
('rage_max','100',NULL,'2026-03-19 08:06:37'),
('referral_enabled','true',NULL,'2026-03-19 09:41:55'),
('referral_qualify_level','3',NULL,'2026-03-19 09:41:55'),
('referral_referred_bonus_gold','100',NULL,'2026-03-19 09:41:55'),
('referral_reward_gold','500',NULL,'2026-03-19 09:41:55'),
('referral_reward_item_id','0',NULL,'2026-03-19 09:41:55'),
('referral_reward_xp','0',NULL,'2026-03-19 09:41:55'),
('respec_cooldown_hours','24',NULL,'2026-03-19 06:50:16'),
('respec_enabled','true',NULL,'2026-03-19 06:50:16'),
('respec_gold_cost','500',NULL,'2026-03-19 06:50:16'),
('respec_item_id','0',NULL,'2026-03-19 06:50:16'),
('rolling_hp_damage_per_tick','5',NULL,'2026-03-18 11:48:28'),
('rolling_hp_tick_rate_ms','100',NULL,'2026-03-18 11:48:28'),
('server_name','Twisted Engine','Display name shown on the site','2026-03-15 19:50:09'),
('sig_tech_discovery_threshold','10',NULL,'2026-03-18 09:32:21'),
('sig_tech_max_per_character','3',NULL,'2026-03-18 09:32:21'),
('sig_tech_min_flavor_length','15',NULL,'2026-03-18 09:32:21'),
('sig_tech_xp_per_use','10',NULL,'2026-03-18 09:32:21'),
('stagger_base_increase','5',NULL,'2026-03-18 12:03:40'),
('stagger_decay_per_turn','10',NULL,'2026-03-18 12:03:40'),
('starting_gold','100','Gold given to new users on register','2026-03-15 19:50:09'),
('taunt_duration_turns','3',NULL,'2026-03-19 08:21:57'),
('template_installed','false',NULL,'2026-03-18 11:07:53'),
('tournament_announce_channel','global',NULL,'2026-03-18 09:32:21'),
('tournament_auto_schedule','true',NULL,'2026-03-18 09:32:21'),
('wound_threshold_disable','0.00',NULL,'2026-03-18 09:36:54'),
('wound_threshold_heavy','0.50',NULL,'2026-03-18 09:36:54'),
('wound_threshold_light','0.75',NULL,'2026-03-18 09:36:54'),
('xp_multiplier','1','Global XP gain multiplier','2026-03-15 19:50:09');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('PLAYER','MOD','GM','ADMIN','OWNER') NOT NULL DEFAULT 'PLAYER',
  `currency` int(10) unsigned NOT NULL DEFAULT 100,
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `email_verified` tinyint(1) NOT NULL DEFAULT 1,
  `email_verify_token` varchar(128) DEFAULT NULL,
  `email_verify_expires` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  `login_streak` int(10) unsigned NOT NULL DEFAULT 0,
  `last_login_date` date DEFAULT NULL,
  `invite_code` varchar(16) DEFAULT NULL COMMENT 'This user invite code',
  `referred_by` int(10) unsigned DEFAULT NULL COMMENT 'user.id of who referred them',
  `referral_paid` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 once referral reward was given',
  `spotify_access_token` text DEFAULT NULL,
  `spotify_refresh_token` text DEFAULT NULL,
  `spotify_expires_at` bigint(20) DEFAULT NULL,
  `chat_color` varchar(7) DEFAULT NULL,
  `ban_reason` varchar(255) DEFAULT NULL,
  `referral_code` varchar(16) DEFAULT NULL,
  `referred_by_code` varchar(16) DEFAULT NULL,
  `referral_count` int(10) unsigned NOT NULL DEFAULT 0,
  `warning_level` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `invite_code` (`invite_code`),
  UNIQUE KEY `idx_users_invite_code` (`invite_code`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_verify_token` (`email_verify_token`),
  KEY `idx_users_referral_code` (`referral_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Admin','gooserob@gmail.com','$2a$10$j9bc0rq5InAmnB5QlazswOIxXcWzGNYjsVJf7Y7ZMllRxdtXLXolW','OWNER',300,0,1,'30b4b1cacfee18517df3adfcce1638e643de78180bbfb2e770ab7da574c7dbab','2026-03-17 10:56:43','2026-03-16 10:56:43','2026-03-19 21:57:45',1,'2026-03-19','D6C7172B',NULL,0,NULL,NULL,NULL,'#4ade80',NULL,NULL,NULL,0,0),
(2,'mdorty','mattdorty@gmail.com','$2a$10$GxHUo6ZkkyLrFM6Qb2Beruvs9XoEB82daTivLIYi3ZiAHIXMff0I.','ADMIN',250,0,1,'d4e9b5d284d98113b464e2a0936aa1cf5f8ea59e6b6f060be8f18814cf2f57c9','2026-03-17 21:43:31','2026-03-16 21:43:31','2026-03-17 15:07:50',2,'2026-03-17','8E36B6FD',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),
(3,'RonnieGabagool','asapfroggy@gmail.com','$2a$10$8VlREG3OOTKvrqnVZuZ3VO8HJSPXh.w1GbUOWByvh2ts2hElxuHEW','PLAYER',150,0,1,'3480b9cd04d8600b4cebb6610b4a740e68fbd612672262c8db20424c199db083','2026-03-17 21:51:34','2026-03-16 21:51:34','2026-03-16 21:54:45',1,'2026-03-16','6C0EB269',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),
(4,'zergsliver','mtnsliver@yahoo.com','$2a$10$6qKmbAeKOzv4lXZjzeICzuXP4uqLzeEIl.gU.R9jz6N1W.FR6yFRO','PLAYER',150,0,1,'c6db29a99d1a8fd9143123316e759896f944c7727322d35c664dca3d8820619c','2026-03-19 08:24:23','2026-03-18 08:24:23','2026-03-18 08:28:19',1,'2026-03-18','7BAF86B8',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),
(5,'AllenSam','allensam85@gmail.com','$2a$10$OIAX8v4e8JXoDM91NAtBCO1Yxi1fdD8sifqqNcT95VfzHa0hclROm','ADMIN',150,0,1,'6dd3fb24ea45d0aec759f4dd803b67bfa1f437c07732023204c60a366503929d','2026-03-19 21:13:31','2026-03-18 21:13:31','2026-03-18 21:13:32',1,'2026-03-18','A14E2892',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `world_flags`
--

DROP TABLE IF EXISTS `world_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `world_flags` (
  `flag_key` varchar(128) NOT NULL,
  `flag_value` text NOT NULL DEFAULT 'true',
  `set_by` varchar(128) DEFAULT NULL,
  `set_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`flag_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `world_flags`
--

LOCK TABLES `world_flags` WRITE;
/*!40000 ALTER TABLE `world_flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `world_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'twisted_rpg'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-25  5:51:23
